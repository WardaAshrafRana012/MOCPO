import { calculateConsultancyTotals, calculateFinalEstimate, calculateScopeTotals } from "@/lib/calculations";
import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import type { ProjectRecord, ProposalSectionKey, ProposalVersion } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";

export const PLAN_A_SCOPE_LABEL = "Plan A (Optimal Scope)";
export const PLAN_B_SCOPE_LABEL = "Plan B (Buffered Scope)";

export type ProposalSummaryCard = {
  key: "consultancyFee" | "planA" | "planB" | "finalEstimate";
  label: string;
  value: string;
};

function isVisibleSection(project: ProjectRecord, version: ProposalVersion, section: ProposalSectionKey) {
  const workspaceState = version.workspaceSections[section];

  return (
    isProposalSectionRenderable(project, version, section) &&
    !workspaceState.hidden &&
    !workspaceState.deleted
  );
}

export function getProposalSummaryCards(project: ProjectRecord, version: ProposalVersion): ProposalSummaryCard[] {
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const finalEstimate = calculateFinalEstimate(version.executionSection);
  const showConsultancy = isVisibleSection(project, version, "consultancyFee");
  const showScope = (["workScope", "negativeList", "optimalList", "bufferedOptimalList"] as const).some((section) =>
    isVisibleSection(project, version, section),
  );
  const showPlanA = showScope && (version.executionSection.selectedPlan === "optimal" || version.executionSection.selectedPlan === "both");
  const showPlanB = showScope && (version.executionSection.selectedPlan === "buffered" || version.executionSection.selectedPlan === "both");
  const cards: ProposalSummaryCard[] = [];

  if (showConsultancy) {
    cards.push({
      key: "consultancyFee",
      label: "Consultancy Fee",
      value: formatCurrency(consultancyTotals.servicesTotalWithTax),
    });
  }

  if (showPlanA) {
    cards.push({
      key: "planA",
      label: PLAN_A_SCOPE_LABEL,
      value: formatCurrency(scopeTotals.optimalGrandTotal),
    });
  }

  if (showPlanB) {
    cards.push({
      key: "planB",
      label: PLAN_B_SCOPE_LABEL,
      value: formatCurrency(scopeTotals.bufferedGrandTotal),
    });
  }

  if (showConsultancy && (showPlanA || showPlanB)) {
    cards.push({
      key: "finalEstimate",
      label: "Final Estimate",
      value: formatCurrency(finalEstimate),
    });
  }

  return cards;
}
