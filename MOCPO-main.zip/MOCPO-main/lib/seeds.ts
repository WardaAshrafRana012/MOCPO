import { addDays, formatISO } from "date-fns";

import type {
  ConsultancyDiscipline,
  ConsultancyRow,
  DisciplineName,
  ExecutionBudgetPlan,
  ExecutionBudgetRow,
  ExecutionSection,
  ScopeCategory,
  ScopeItem,
  TimelineRow,
} from "@/lib/types";
import { createId } from "@/lib/utils";

const consultancyDeliverables: Record<
  DisciplineName,
  {
    rateLabel: string;
    inputLabel: string;
    usesProjectDuration?: boolean;
    rows: { phaseLabel: string; deliverable: string; rate: number; defaultInput?: number }[];
    notes?: string[];
  }
> = {
  Architecture: {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "ONE",
        deliverable: "- PROJECT INITIATION\n1. Site Inspection\n2. Survey & Analysis\n3. Timeline & High Level Budget",
        rate: 12,
      },
      {
        phaseLabel: "TWO",
        deliverable: "- CONCEPT DESIGN\n1. Planning & Schematic layout\n2. Concept Moodboards & References",
        rate: 18,
      },
      {
        phaseLabel: "THREE",
        deliverable: "- DESIGN DEVELOPMENT\n1. Exterior Elevations & Finishes\n2. 2D Sections\n3. 3D Design & Renders",
        rate: 36,
      },
      {
        phaseLabel: "FOUR",
        deliverable: "- DRAWING DEVELOPMENT\n1. Architecture Working Drawings (Plans, Sections, Elevations, Details)",
        rate: 36,
      },
      {
        phaseLabel: "FIVE",
        deliverable: "- BOQ DEVELOPMENT\n1. Architecture",
        rate: 18,
      },
    ],
  },
  Interior: {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "ONE",
        deliverable: "- CONCEPT DESIGN\n1. Planning & Schematic layout\n2. Concept Mood Boards & References",
        rate: 40,
      },
      {
        phaseLabel: "TWO",
        deliverable:
          "- DESIGN DEVELOPMENT - INTERIOR\n1. Interior Elevations\n2. 2D Interior Sections\n3. 3D Design Modelling\n4. Detail Design & Renders\n5. Selection of Finishes & Materials\n6. Furniture Layout Plan, Design & Finishes",
        rate: 90,
      },
      {
        phaseLabel: "THREE",
        deliverable: "- DRAWING DEVELOPMENT\n1. Interior Working Drawings (Plans, Sections, Elevations, Details)",
        rate: 75,
      },
      {
        phaseLabel: "FOUR",
        deliverable: "- BOQ DEVELOPMENT\n1. Interior\n2. Furniture",
        rate: 45,
      },
    ],
  },
  "MEP Design": {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "FIVE",
        deliverable: "- DESIGN PACKAGE\n1. Electrical Drawings\n2. Plumbing Drawings\n3. Fire Fighting Drawings\n4. AC Drawings",
        rate: 36,
      },
      {
        phaseLabel: "SIX",
        deliverable: "- BOQ DEVELOPMENT\n1. MEP",
        rate: 24,
      },
    ],
  },
  Structure: {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "ONE",
        deliverable:
          "- PROJECT INITIATION\n1. Site Inspection\n2. Survey & Analysis\n3. Timeline & High Level Budget\n4. Seismic considerations based on area data",
        rate: 4.6,
      },
      {
        phaseLabel: "ONE",
        deliverable:
          "- DRAWING DEVELOPMENT\n1. Structure Drawings with BIM Model (Plans, Sections, Elevations, Details)\n2. Structure design based on seismic building codes compliance.",
        rate: 29.6,
      },
      {
        phaseLabel: "TWO",
        deliverable: "- BOQ DEVELOPMENT\n1. Structure",
        rate: 14.6,
      },
    ],
  },
  "Facade Engineering": {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "ONE",
        deliverable: "- PROJECT INITIATION\n1. Site Inspection\n2. Survey & Analysis\n3. Timeline & High Level Budget",
        rate: 7.5,
      },
      {
        phaseLabel: "TWO",
        deliverable: "- CONCEPT DESIGN\n1. Planning & Schematic layout\n2. Concept Moodboards & References",
        rate: 17.5,
      },
      {
        phaseLabel: "THREE",
        deliverable: "- DESIGN DEVELOPMENT\n1. Exterior Elevations & Finishes\n2. 2D Sections\n3. 3D Design & Renders",
        rate: 43.75,
      },
      {
        phaseLabel: "FOUR",
        deliverable: "- DRAWING DEVELOPMENT\n1. Architecture Working Drawings (Plans, Sections, Elevations, Details)",
        rate: 48,
      },
      {
        phaseLabel: "FIVE",
        deliverable: "- BOQ DEVELOPMENT\n1. Architecture",
        rate: 15,
      },
    ],
  },
  Landscaping: {
    rateLabel: "Rate / PKR / SQ.FT",
    inputLabel: "Area / SQ.FT Input",
    rows: [
      {
        phaseLabel: "ONE",
        deliverable: "- PROJECT INITIATION\n1. Site Inspection\n2. Survey & Analysis\n3. Timeline & High Level Budget",
        rate: 0,
      },
      {
        phaseLabel: "TWO",
        deliverable: "- CONCEPT DESIGN\n1. Landscape Master Plan\n2. Concept Moodboards & References\n3. Softscape / Hardscape Strategy",
        rate: 0,
      },
      {
        phaseLabel: "THREE",
        deliverable: "- DESIGN DEVELOPMENT\n1. Planting Plans\n2. Hardscape Details\n3. Irrigation & Drainage Concept\n4. 3D Visualisation",
        rate: 0,
      },
      {
        phaseLabel: "FOUR",
        deliverable: "- DRAWING DEVELOPMENT\n1. Landscape Working Drawings (Plans, Sections, Details)\n2. Planting Schedules\n3. Irrigation Layouts",
        rate: 0,
      },
      {
        phaseLabel: "FIVE",
        deliverable: "- BOQ DEVELOPMENT\n1. Landscape\n2. Hardscape & Softscape",
        rate: 0,
      },
    ],
  },
  "Top Supervision": {
    rateLabel: "Rate per Visit (PKR)",
    inputLabel: "No. of Visits",
    rows: [
      { phaseLabel: "1", deliverable: "Principal Architect - Site Visits", rate: 0, defaultInput: 0 },
      { phaseLabel: "2", deliverable: "Senior Structural Engineer - Site Visits", rate: 0, defaultInput: 0 },
      { phaseLabel: "3", deliverable: "Senior MEP Engineer - Site Visits", rate: 0, defaultInput: 0 },
      { phaseLabel: "4", deliverable: "Senior Interior Designer - Site Visits", rate: 0, defaultInput: 0 },
      { phaseLabel: "5", deliverable: "Senior Landscape Architect - Site Visits", rate: 0, defaultInput: 0 },
      { phaseLabel: "6", deliverable: "Senior Facade Engineer - Site Visits", rate: 0, defaultInput: 0 },
    ],
    notes: [
      "Review and approval of contractor shop drawings and method statements.",
      "Review of material submittals, mock-ups and finish samples for conformance with design intent.",
      "Responses to contractor RFIs within agreed turnaround times.",
      "Issuance of design clarifications, site instructions and field change orders.",
      "Coordinated multi-discipline drawing reviews and site visit reports.",
      "Final close-out review, snag monitoring, and completion report support.",
    ],
  },
  "Resident Engineering & Supervision Team": {
    rateLabel: "Monthly Cost per Person (PKR)",
    inputLabel: "No. of Personnel",
    usesProjectDuration: true,
    rows: [
      { phaseLabel: "1", deliverable: "Resident Project Manager", rate: 0, defaultInput: 1 },
      { phaseLabel: "2", deliverable: "Resident Architect", rate: 0, defaultInput: 1 },
      { phaseLabel: "3", deliverable: "Resident Civil / Structural Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "4", deliverable: "Resident Electrical Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "5", deliverable: "Resident Mechanical / HVAC Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "6", deliverable: "Resident Plumbing & Fire-Fighting Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "7", deliverable: "Resident Quantity Surveyor / Billing Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "8", deliverable: "Resident Interior Coordinator", rate: 0, defaultInput: 1 },
      { phaseLabel: "9", deliverable: "Resident Landscape Coordinator", rate: 0, defaultInput: 1 },
      { phaseLabel: "10", deliverable: "Resident Facade Engineer", rate: 0, defaultInput: 1 },
      { phaseLabel: "11", deliverable: "Site Inspector - Civil", rate: 0, defaultInput: 2 },
      { phaseLabel: "12", deliverable: "Site Inspector - MEP", rate: 0, defaultInput: 2 },
      { phaseLabel: "13", deliverable: "Health, Safety & Environment (HSE) Officer", rate: 0, defaultInput: 1 },
      { phaseLabel: "14", deliverable: "Document Controller", rate: 0, defaultInput: 1 },
      { phaseLabel: "15", deliverable: "Office Support / Admin", rate: 0, defaultInput: 1 },
    ],
    notes: [
      "Total Cost = No. of Personnel x Monthly Cost x Project Duration.",
      "Project duration comes from the Project Parameters block on this tab.",
    ],
  },
};

const scopeSeeds: Record<string, { itemDescription: string; unit: string; quantity: number; optimalRate: number; bufferedRate: number; remarks?: string }[]> =
  {
    "Civil Work": [
      { itemDescription: "Masonry", unit: "SQ.FT", quantity: 2400, optimalRate: 180, bufferedRate: 205 },
      { itemDescription: "Flooring", unit: "SQ.FT", quantity: 2200, optimalRate: 260, bufferedRate: 295 },
      { itemDescription: "Ceiling", unit: "SQ.FT", quantity: 1800, optimalRate: 145, bufferedRate: 168 },
      { itemDescription: "Gypsum Work", unit: "SQ.FT", quantity: 1300, optimalRate: 120, bufferedRate: 138 },
      { itemDescription: "Paint", unit: "SQ.FT", quantity: 2600, optimalRate: 55, bufferedRate: 66 },
    ],
    "Interior Work": [
      { itemDescription: "Partitions", unit: "SQ.FT", quantity: 900, optimalRate: 320, bufferedRate: 355 },
      { itemDescription: "Feature Wall Cladding", unit: "SQ.FT", quantity: 420, optimalRate: 470, bufferedRate: 520 },
      { itemDescription: "Reception Counter", unit: "LS", quantity: 1, optimalRate: 180000, bufferedRate: 205000 },
    ],
    HVAC: [
      { itemDescription: "Ducting", unit: "RFT", quantity: 620, optimalRate: 240, bufferedRate: 270 },
      { itemDescription: "Diffusers & Grilles", unit: "Nos", quantity: 34, optimalRate: 9800, bufferedRate: 11200 },
      { itemDescription: "Insulation", unit: "SQ.FT", quantity: 1150, optimalRate: 90, bufferedRate: 106 },
    ],
    Electrical: [
      { itemDescription: "Power Cabling", unit: "RFT", quantity: 1400, optimalRate: 78, bufferedRate: 88 },
      { itemDescription: "Light Fixtures", unit: "Nos", quantity: 95, optimalRate: 8400, bufferedRate: 9300 },
      { itemDescription: "DB & Protection", unit: "LS", quantity: 1, optimalRate: 265000, bufferedRate: 298000 },
    ],
    Plumbing: [
      { itemDescription: "Water Supply Piping", unit: "RFT", quantity: 560, optimalRate: 210, bufferedRate: 235 },
      { itemDescription: "Drainage Piping", unit: "RFT", quantity: 420, optimalRate: 195, bufferedRate: 220 },
      { itemDescription: "Fixtures Installation", unit: "Nos", quantity: 18, optimalRate: 16000, bufferedRate: 18200 },
    ],
    Furniture: [
      { itemDescription: "Workstations", unit: "Nos", quantity: 40, optimalRate: 42000, bufferedRate: 46500 },
      { itemDescription: "Meeting Tables", unit: "Nos", quantity: 6, optimalRate: 78000, bufferedRate: 86000 },
      { itemDescription: "Storage Units", unit: "Nos", quantity: 12, optimalRate: 28500, bufferedRate: 31800 },
    ],
    Ceiling: [
      { itemDescription: "Grid Ceiling", unit: "SQ.FT", quantity: 1500, optimalRate: 125, bufferedRate: 142 },
      { itemDescription: "Feature Bulkheads", unit: "RFT", quantity: 280, optimalRate: 320, bufferedRate: 360 },
    ],
    Paint: [
      { itemDescription: "Primer & Putty", unit: "SQ.FT", quantity: 2600, optimalRate: 24, bufferedRate: 30 },
      { itemDescription: "Top Coat", unit: "SQ.FT", quantity: 2600, optimalRate: 38, bufferedRate: 45 },
    ],
    Networking: [
      { itemDescription: "Data Points", unit: "Nos", quantity: 72, optimalRate: 7200, bufferedRate: 8100 },
      { itemDescription: "Rack & Patch Panels", unit: "LS", quantity: 1, optimalRate: 198000, bufferedRate: 225000 },
    ],
    "Security System": [
      { itemDescription: "CCTV Cameras", unit: "Nos", quantity: 22, optimalRate: 13800, bufferedRate: 15400 },
      { itemDescription: "Access Control Points", unit: "Nos", quantity: 8, optimalRate: 26500, bufferedRate: 29400 },
    ],
    Miscellaneous: [
      { itemDescription: "Signage", unit: "LS", quantity: 1, optimalRate: 125000, bufferedRate: 146000 },
      { itemDescription: "Contingency Support", unit: "%", quantity: 1, optimalRate: 175000, bufferedRate: 220000 },
    ],
  };

const timelineSeed: { activity: string; days: number; remarks: string }[] = [
  { activity: "Design Process", days: 14, remarks: "Core design coordination" },
  { activity: "Submission of Documents for Legal Approvals / NOCs", days: 10, remarks: "Approvals subject to authority review" },
  { activity: "Construction Execution Tendering Process", days: 12, remarks: "Bid review and vendor alignment" },
  { activity: "Construction Commencement", days: 7, remarks: "Site mobilization and handover" },
  { activity: "Idle Days Due to Inclement Weather Conditions", days: 5, remarks: "Reserved schedule buffer" },
  { activity: "Interior Finishes", days: 18, remarks: "Final finishes and closeout" },
];

export const standardTimelineActivities = timelineSeed.map((item) => item.activity);

export const standardDisciplineOrder: DisciplineName[] = [
  "Architecture",
  "Interior",
  "MEP Design",
  "Structure",
  "Facade Engineering",
  "Landscaping",
  "Top Supervision",
  "Resident Engineering & Supervision Team",
];

export const standardScopeCategories = Object.keys(scopeSeeds);

export function createConsultancyRows(discipline: DisciplineName, area: number): ConsultancyRow[] {
  const safeArea = Math.max(0, area);

  return consultancyDeliverables[discipline].rows.map((item) => ({
    id: createId("consultancy-row"),
    phaseLabel: item.phaseLabel,
    deliverable: item.deliverable,
    rate: item.rate,
    area: item.defaultInput ?? safeArea,
    totalCost: item.rate * (item.defaultInput ?? safeArea),
  }));
}

export function createConsultancyDiscipline(discipline: DisciplineName, area: number): ConsultancyDiscipline {
  const seed = consultancyDeliverables[discipline];
  const rows = createConsultancyRows(discipline, area);

  return {
    name: discipline,
    rows,
    isLocked: true,
    estimatedAmount: rows.reduce((sum, row) => sum + row.totalCost, 0),
    rateLabel: seed.rateLabel,
    inputLabel: seed.inputLabel,
    usesProjectDuration: seed.usesProjectDuration ?? false,
    notes: seed.notes ?? [],
  };
}

export function createScopeCategory(name: string): ScopeCategory {
  const rows: ScopeItem[] = (scopeSeeds[name] ?? []).map((item) => ({
    id: createId("scope-row"),
    itemDescription: item.itemDescription,
    unit: item.unit,
    quantity: item.quantity,
    optimalRate: item.optimalRate,
    optimalAmount: item.quantity * item.optimalRate,
    bufferedRate: item.bufferedRate,
    bufferedAmount: item.quantity * item.bufferedRate,
    remarks: item.remarks ?? "",
  }));

  return {
    id: createId("scope-category"),
    name,
    rows,
    isLocked: true,
    isStandard: true,
  };
}

export function createCustomScopeCategory(name = "Custom Category"): ScopeCategory {
  return {
    id: createId("scope-category"),
    name,
    rows: [
      {
        id: createId("scope-row"),
        itemDescription: "New scope item",
        unit: "LS",
        quantity: 1,
        optimalRate: 0,
        optimalAmount: 0,
        bufferedRate: 0,
        bufferedAmount: 0,
        remarks: "",
      },
    ],
    isLocked: false,
    isStandard: false,
  };
}

export function createTimelineRows(startDate?: string): TimelineRow[] {
  const initialDate = startDate ? new Date(startDate) : new Date();

  return timelineSeed.map((item, index) => {
    const rowStart = addDays(initialDate, index * 7);
    const rowEnd = addDays(rowStart, item.days);

    return {
      id: createId("timeline-row"),
      activity: item.activity,
      days: item.days,
      startDate: formatISO(rowStart, { representation: "date" }),
      endDate: formatISO(rowEnd, { representation: "date" }),
      remarks: item.remarks,
    };
  });
}

export function createTimelineTemplateRows(): TimelineRow[] {
  return timelineSeed.map((item) => ({
    id: createId("timeline-row"),
    activity: item.activity,
    days: 0,
    startDate: "",
    endDate: "",
    remarks: item.remarks,
  }));
}

export function createDistributedTimelineRows(totalDays: number, startDate?: string): TimelineRow[] {
  const rows = createTimelineTemplateRows();
  const safeTotalDays = Math.max(0, Math.round(totalDays || 0));
  const baseDays = rows.length > 0 ? Math.floor(safeTotalDays / rows.length) : 0;
  let remainder = rows.length > 0 ? safeTotalDays % rows.length : 0;
  let nextStartDate = startDate ?? "";

  return rows.map((row, index) => {
    const days = baseDays + (remainder > 0 ? 1 : 0);
    remainder = Math.max(0, remainder - 1);
    const currentStartDate = nextStartDate;
    const endDate = currentStartDate ? formatISO(addDays(new Date(currentStartDate), days), { representation: "date" }) : "";
    nextStartDate = endDate;

    return {
      ...row,
      activity: row.activity || standardTimelineActivities[index] || `Activity ${index + 1}`,
      days,
      startDate: currentStartDate,
      endDate,
    };
  });
}

export function createExecutionBudgetRow(description = "New cost item"): ExecutionBudgetRow {
  return {
    id: createId("execution-budget-row"),
    description,
    quantity: 0,
    rate: 0,
    totalAmount: 0,
    remarks: "",
  };
}

export function createExecutionBudgetPlan(kind: "budget-a" | "budget-b" | "custom"): ExecutionBudgetPlan {
  const defaults =
    kind === "budget-a"
      ? { title: "Budget A", optionLabel: "Standard Option" }
      : kind === "budget-b"
        ? { title: "Budget B", optionLabel: "Premium Option" }
        : { title: "Custom Budget", optionLabel: "Custom Option" };

  return {
    id: createId("execution-budget-plan"),
    key: kind,
    title: defaults.title,
    optionLabel: defaults.optionLabel,
    rows: [createExecutionBudgetRow()],
  };
}

export function createExecutionSection(): ExecutionSection {
  return {
    importedConsultancyFee: 0,
    importedOptimalCost: 0,
    importedBufferedCost: 0,
    selectedPlan: "both",
    totalProjectDurationDays: 66,
    timelineRows: createTimelineRows(),
    budgetPlans: [createExecutionBudgetPlan("budget-a"), createExecutionBudgetPlan("budget-b")],
    isLocked: true,
    importedAt: null,
  };
}

export function createBlankExecutionSection(): ExecutionSection {
  return {
    importedConsultancyFee: 0,
    importedOptimalCost: 0,
    importedBufferedCost: 0,
    selectedPlan: null,
    totalProjectDurationDays: 0,
    timelineRows: [],
    budgetPlans: [],
    isLocked: false,
    importedAt: null,
  };
}
