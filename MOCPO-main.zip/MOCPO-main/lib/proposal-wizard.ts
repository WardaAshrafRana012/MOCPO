export const proposalWizardSteps = [
  "project",
  "consultancy",
  "scope",
  "execution",
  "preview",
] as const;

export type ProposalWizardStep = (typeof proposalWizardSteps)[number];

export const proposalWizardStepMeta: Record<
  ProposalWizardStep,
  {
    index: number;
    label: string;
    title: string;
  }
> = {
  project: {
    index: 0,
    label: "Step 1",
    title: "Basic Project Information",
  },
  consultancy: {
    index: 1,
    label: "Step 2",
    title: "Consultancy Fee",
  },
  scope: {
    index: 2,
    label: "Step 3",
    title: "Work Scope Breakup",
  },
  execution: {
    index: 3,
    label: "Step 4",
    title: "Execution Estimate",
  },
  preview: {
    index: 4,
    label: "Step 5",
    title: "Preview Proposal",
  },
};

export function isProposalWizardStep(value: string | null | undefined): value is ProposalWizardStep {
  return proposalWizardSteps.includes((value ?? "") as ProposalWizardStep);
}
