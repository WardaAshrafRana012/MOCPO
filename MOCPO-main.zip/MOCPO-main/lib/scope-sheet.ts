import type { ScopeSection, ScopeSheetRow } from "@/lib/types";
import { createId } from "@/lib/utils";

type ScopeRowSeed = Omit<ScopeSheetRow, "id" | "leftAmount" | "rightAmount">;

export type StandardScopeGroup = {
  id: string;
  name: string;
  rows: ScopeRowSeed[];
};

const standardScopeGroups: StandardScopeGroup[] = [
  {
    id: "id-scope",
    name: "ID Scope",
    rows: [
      {
        kind: "groupHeader",
        groupId: "id-scope",
        groupName: "ID Scope",
        leftSerial: "1",
        leftScope: "ID Scope",
        leftSft: null,
        leftRate: null,
        leftValueRowSpan: null,
        rightSerial: "1",
        rightScope: "ID Scope",
        rightSft: null,
        rightRate: null,
        rightValueRowSpan: null,
      },
      {
        kind: "line",
        groupId: "id-scope",
        groupName: "ID Scope",
        leftSerial: "i",
        leftScope: "Façade Protection Partitions",
        leftSft: 5150,
        leftRate: 5500,
        leftValueRowSpan: 17,
        rightSerial: "i",
        rightScope: "Façade Protection Partitions",
        rightSft: 5150,
        rightRate: 6500,
        rightValueRowSpan: 22,
      },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "ii", leftScope: "Dismantling Scope", leftSft: null, leftRate: null, rightSerial: "ii", rightScope: "Dismantling Scope", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "iii", leftScope: "Partitioning Scope; MDF", leftSft: null, leftRate: null, rightSerial: "iii", rightScope: "Partitioning Scope; Cement Board", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "iv", leftScope: "Glass Partitions", leftSft: null, leftRate: null, rightSerial: "iv", rightScope: "Glass Partitions", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "v", leftScope: "Levelling of Floor", leftSft: null, leftRate: null, rightSerial: "v", rightScope: "Levelling of Floor", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "vi", leftScope: "Conceiled Ceiling + 2\"x2'", leftSft: null, leftRate: null, rightSerial: "vi", rightScope: "Industrial Ceiling + Conceiled", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "vii", leftScope: "Flooring\nTiling Scope 2' x 4'\nBase rate 3000/mtr", leftSft: null, leftRate: null, rightSerial: "vii", rightScope: "Flooring\nTiling Scope 2' x 4'\nBase rate 4000/mtr", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "", leftScope: "", leftSft: null, leftRate: null, rightSerial: "", rightScope: "Carpet", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "viii", leftScope: "Fire Exit Door", leftSft: null, leftRate: null, rightSerial: "viii", rightScope: "Fire Exit Door", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "ix", leftScope: "Doors", leftSft: null, leftRate: null, rightSerial: "ix", rightScope: "Doors", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "x", leftScope: "Paint Scope; water Matt paint", leftSft: null, leftRate: null, rightSerial: "x", rightScope: "Paint Scope; Texture & water Matt paint", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xi", leftScope: "Lindapters", leftSft: null, leftRate: null, rightSerial: "xi", rightScope: "Lindapters", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xii", leftScope: "Drop down Ceiling", leftSft: null, leftRate: null, rightSerial: "xii", rightScope: "Drop down Ceiling", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xiii", leftScope: "Blinds Pelemts", leftSft: null, leftRate: null, rightSerial: "xiii", rightScope: "Blinds Pelemts", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xiv", leftScope: "Blinds", leftSft: null, leftRate: null, rightSerial: "xiv", rightScope: "Blinds", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xv", leftScope: "Sealing of Edging( Façade)", leftSft: null, leftRate: null, rightSerial: "xv", rightScope: "Sealing of Edging( Façade)", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xvi", leftScope: "Plumbing\nSanitary fixtures: Porta or Equivalent", leftSft: null, leftRate: null, rightSerial: "xvi", rightScope: "Plumbing\nSanitary fixtures: Porta or Equivalent", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xv", leftScope: "Metal deck paint", leftSft: null, leftRate: null, rightSerial: "xv", rightScope: "Metal deck paint", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xvi", leftScope: "Feature Walls", leftSft: null, leftRate: null, rightSerial: "xvi", rightScope: "Feature Walls", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "xvii", leftScope: "Wall cladding", leftSft: null, leftRate: null, rightSerial: "xvii", rightScope: "Wall cladding", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "", leftScope: "", leftSft: null, leftRate: null, rightSerial: "xx", rightScope: "Basic branding", rightSft: null, rightRate: null },
      { kind: "line", groupId: "id-scope", groupName: "ID Scope", leftSerial: "", leftScope: "", leftSft: null, leftRate: null, rightSerial: "", rightScope: "Customized lighting", rightSft: null, rightRate: null },
    ],
  },
  {
    id: "design-scope",
    name: "Design Scope",
    rows: [
      {
        kind: "groupHeader",
        groupId: "design-scope",
        groupName: "Design Scope",
        leftSerial: "2",
        leftScope: "Design Scope",
        leftSft: null,
        leftRate: null,
        leftValueRowSpan: null,
        rightSerial: "2",
        rightScope: "Design Scope",
        rightSft: null,
        rightRate: null,
        rightValueRowSpan: null,
      },
      {
        kind: "line",
        groupId: "design-scope",
        groupName: "Design Scope",
        leftSerial: "i",
        leftScope: "Design Scope",
        leftSft: 5150,
        leftRate: 350,
        leftValueRowSpan: 4,
        rightSerial: "i",
        rightScope: "Design Scope",
        rightSft: 5150,
        rightRate: 450,
        rightValueRowSpan: 4,
      },
      { kind: "line", groupId: "design-scope", groupName: "Design Scope", leftSerial: "ii", leftScope: "Coordination Scope", leftSft: null, leftRate: null, rightSerial: "ii", rightScope: "Coordination Scope", rightSft: null, rightRate: null },
      { kind: "line", groupId: "design-scope", groupName: "Design Scope", leftSerial: "iii", leftScope: "Authority Submission Scope", leftSft: null, leftRate: null, rightSerial: "iii", rightScope: "Authority Submission Scope", rightSft: null, rightRate: null },
      { kind: "line", groupId: "design-scope", groupName: "Design Scope", leftSerial: "iv", leftScope: "Site Support Scope", leftSft: null, leftRate: null, rightSerial: "iv", rightScope: "Site Support Scope", rightSft: null, rightRate: null },
    ],
  },
  {
    id: "hvac",
    name: "HVAC /Air Conditioning",
    rows: [
      {
        kind: "groupHeader",
        groupId: "hvac",
        groupName: "HVAC /Air Conditioning",
        leftSerial: "3",
        leftScope: "HVAC /Air Conditioning",
        leftSft: null,
        leftRate: null,
        leftValueRowSpan: null,
        rightSerial: "3",
        rightScope: "HVAC /Air Conditioning",
        rightSft: null,
        rightRate: null,
        rightValueRowSpan: null,
      },
      {
        kind: "line",
        groupId: "hvac",
        groupName: "HVAC /Air Conditioning",
        leftSerial: "i",
        leftScope: "Air Supply Ductings",
        leftSft: 5150,
        leftRate: 2500,
        leftValueRowSpan: 8,
        rightSerial: "i",
        rightScope: "Air Supply Ductings",
        rightSft: 5150,
        rightRate: 2500,
        rightValueRowSpan: 8,
      },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "ii", leftScope: "Open return", leftSft: null, leftRate: null, rightSerial: "ii", rightScope: "Open return", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "iii", leftScope: "Dampers", leftSft: null, leftRate: null, rightSerial: "iii", rightScope: "Dampers", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "iv", leftScope: "Supply Air Diffusers", leftSft: null, leftRate: null, rightSerial: "iv", rightScope: "Supply Air Diffusers", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "v", leftScope: "Return Air Diffusers", leftSft: null, leftRate: null, rightSerial: "v", rightScope: "Return Air Diffusers", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "vi", leftScope: "VAV & V.C.D (Volume control damper)", leftSft: null, leftRate: null, rightSerial: "vi", rightScope: "VAV & V.C.D (Volume control damper)", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "vii", leftScope: "Piping for Fire fighting system", leftSft: null, leftRate: null, rightSerial: "vii", rightScope: "Piping for Fire fighting system", rightSft: null, rightRate: null },
      { kind: "line", groupId: "hvac", groupName: "HVAC /Air Conditioning", leftSerial: "viii", leftScope: "Sprinklers", leftSft: null, leftRate: null, rightSerial: "viii", rightScope: "Sprinklers", rightSft: null, rightRate: null },
    ],
  },
  {
    id: "electrical",
    name: "MEP Scope",
    rows: [
      {
        kind: "groupHeader",
        groupId: "electrical",
        groupName: "MEP Scope",
        leftSerial: "4",
        leftScope: "MEP Scope",
        leftSft: null,
        leftRate: null,
        leftValueRowSpan: null,
        rightSerial: "4",
        rightScope: "MEP Scope",
        rightSft: null,
        rightRate: null,
        rightValueRowSpan: null,
      },
      {
        kind: "line",
        groupId: "electrical",
        groupName: "MEP Scope",
        leftSerial: "i",
        leftScope:
          "Raceways (PAk Arab / Equivalent)\nRaw Power Wiring (Pakistan Cables)\nData Wiring (3M)\nVoice Wiring (3M)\nBasic Lighting\nFA Scope with integration of LL system\nPA System\nFace Plates (Schneider)\nMulti Sockets (Schneider)\nCCTV Scope (Hik Vision or Equivalent)\nDate / Voice Termination\nSuply and Termination of Distribution Panels",
        leftSft: 5150,
        leftRate: 2500,
        leftValueRowSpan: 2,
        rightSerial: "i",
        rightScope:
          "Raceways (PAk Arab / Equivalent)\nRaw Power Wiring (Pakistan Cables)\nData Wiring (3M)\nVoice Wiring (3M)\nBasic Lighting\nFA Scope with integration of LL system\nPA System\nFace Plates (Schneider)\nMulti Sockets (Schneider)\nCCTV Scope (Hik Vision or Equivalent)\nDate / Voice Termination\nSuply and Termination of Distribution Panels",
        rightSft: 5150,
        rightRate: 2500,
        rightValueRowSpan: 2,
      },
      { kind: "line", groupId: "electrical", groupName: "MEP Scope", leftSerial: "ii", leftScope: "Cable Trays", leftSft: null, leftRate: null, rightSerial: "ii", rightScope: "Cable Trays", rightSft: null, rightRate: null },
    ],
  },
  {
    id: "furniture",
    name: "Furniture Scope",
    rows: [
      {
        kind: "groupHeader",
        groupId: "furniture",
        groupName: "Furniture Scope",
        leftSerial: "5",
        leftScope: "Furniture Scope",
        leftSft: 5150,
        leftRate: 2000,
        leftValueRowSpan: 1,
        rightSerial: "5",
        rightScope: "Furniture Scope",
        rightSft: 5150,
        rightRate: 2500,
        rightValueRowSpan: 1,
      },
    ],
  },
];

export const standardScopeGroupOptions = standardScopeGroups.map((group) => ({
  id: group.id,
  name: group.name,
}));

export const defaultStandardScopeGroupIds = standardScopeGroups.map((group) => group.id);

function calculateAmount(sft: number | null, rate: number | null) {
  if (sft === null || rate === null) return null;
  return roundAmount(sft * rate);
}

function spreadGroupBudgetValues(rows: ScopeRowSeed[], areaSqFt?: number) {
  const sharedArea = areaSqFt && areaSqFt > 0 ? areaSqFt : null;

  return rows.map((row) => {
    if (row.kind !== "line") {
      return row;
    }

    return {
      ...row,
      leftSft: row.leftSft !== null && sharedArea ? sharedArea : row.leftSft,
      rightSft: row.rightSft !== null && sharedArea ? sharedArea : row.rightSft,
    };
  });
}

function createRowFromSeed(row: ScopeRowSeed): ScopeSheetRow {
  return {
    ...row,
    id: createId("scope-sheet-row"),
    leftAmount: calculateAmount(row.leftSft, row.leftRate),
    rightAmount: calculateAmount(row.rightSft, row.rightRate),
  };
}

export function createStandardScopeGroupRows(groupId: string, areaSqFt?: number) {
  const group = standardScopeGroups.find((item) => item.id === groupId);
  return group ? spreadGroupBudgetValues(group.rows, areaSqFt).map(createRowFromSeed) : [];
}

export function getStandardScopeGroupName(groupId: string) {
  return standardScopeGroups.find((group) => group.id === groupId)?.name ?? groupId;
}

function hasFinancialValues(row: ScopeSheetRow) {
  return (
    row.leftSft !== null ||
    row.leftRate !== null ||
    row.leftAmount !== null ||
    row.rightSft !== null ||
    row.rightRate !== null ||
    row.rightAmount !== null
  );
}

function hasSameBudgetValues(left: ScopeSheetRow, right: ScopeSheetRow) {
  return (
    left.leftSft === right.leftSft &&
    left.leftRate === right.leftRate &&
    left.leftAmount === right.leftAmount &&
    left.rightSft === right.rightSft &&
    left.rightRate === right.rightRate &&
    left.rightAmount === right.rightAmount
  );
}

export function getScopeRowsForTotals(rows: ScopeSheetRow[]) {
  return rows.filter((row, index) => {
    if (!hasFinancialValues(row)) {
      return false;
    }

    const previousRow = rows[index - 1];
    const isRepeatedBudgetRow =
      row.kind === "line" &&
      previousRow?.kind === "line" &&
      previousRow.groupId === row.groupId &&
      hasSameBudgetValues(previousRow, row);

    return !isRepeatedBudgetRow;
  });
}

export function syncScopeSheetRows(rows: ScopeSheetRow[]) {
  return rows.map((row) => ({
    ...row,
    leftAmount: calculateAmount(row.leftSft, row.leftRate),
    rightAmount: calculateAmount(row.rightSft, row.rightRate),
  }));
}

export function createScopeSection(areaSqFt = 5000, initialGroupIds: string[] = []): ScopeSection {
  return {
    sheetTitle: "Lidl & Kaufland Services Pte. Limited (Pakistan Liaison office)",
    optimalLabel: "OPTIMAL",
    bufferedLabel: "BUFFERED OPTIMAL",
    rows: initialGroupIds.flatMap((groupId) => createStandardScopeGroupRows(groupId, areaSqFt)),
    lockedGroupIds: [...initialGroupIds],
    planMode: "optimal",
    totalLabel: "Total Value of Overall scope excluding taxes",
    exclusionsTitle: "Negative List",
    optimalExclusions: "",
    bufferedExclusions: "",
    note:
      "NOTE\n- The above execution cost breakdown is for your internal review, showing the Standard, Medium, and Premium specification options side by side.\n- This table is intended to give the client a realistic budgeting range, not a fixed commercial quote.\n- At this stage, the figures represent indicative cost bands based on current market rates and typical material/specification scenarios.\n- The final turnkey project cost can only be confirmed once final requirements are frozen, the design is completed, and the full BOQ is approved for execution.\n- Once that stage is reached, a formal quotation will be issued, including value-engineering options if required.\n- For budgeting purposes, we recommend planning against the midpoint of the range, as this reflects the most practical balance between specifications, compliance requirements, and execution realities.",
    gstTaxRate: 18,
    planANetTotal: 0,
    planATaxAmount: 0,
    planATotalWithTax: 0,
    planBNetTotal: 0,
    planBTaxAmount: 0,
    planBTotalWithTax: 0,
  };
}

export function calculateScopeSheetSummary(rows: ScopeSheetRow[]) {
  const countedRows = getScopeRowsForTotals(rows);
  const optimalRateTotal = roundAmount(countedRows.reduce((sum, row) => sum + (row.leftRate ?? 0), 0));
  const bufferedRateTotal = roundAmount(countedRows.reduce((sum, row) => sum + (row.rightRate ?? 0), 0));
  const optimalAmountTotal = roundAmount(countedRows.reduce((sum, row) => sum + (row.leftAmount ?? 0), 0));
  const bufferedAmountTotal = roundAmount(countedRows.reduce((sum, row) => sum + (row.rightAmount ?? 0), 0));

  return {
    optimalRateTotal,
    bufferedRateTotal,
    optimalAmountTotal,
    bufferedAmountTotal,
  };
}

function roundAmount(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

