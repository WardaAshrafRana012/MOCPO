import { format } from "date-fns";
import * as XLSX from "xlsx";

import {
  calculateConsultancyTotals,
  calculateFinalEstimate,
  calculateScopeTotals,
  calculateTimelineTotals,
  createFileName,
  getExecutionBudgetTotals,
  getExecutionPlanLabel,
  getProposalWarnings,
} from "@/lib/calculations";
import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import { PLAN_A_SCOPE_LABEL, PLAN_B_SCOPE_LABEL } from "@/lib/proposal-summary-cards";
import { calculateScopeSheetSummary, getScopeRowsForTotals } from "@/lib/scope-sheet";
import type { ProjectRecord, ProposalSummaryPayload, ProposalVersion } from "@/lib/types";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/utils";
import { buildConfiguredProposalPdf } from "@/lib/pdf-options-template";
import { createDefaultPdfOptions, type ProposalPdfOptions } from "@/lib/pdf-options";

function renderRows(version: ProposalVersion) {
  return version.consultancySection.disciplines
    .map(
      (discipline) => `
        <section class="section">
          <h3>${discipline.name}</h3>
          <table>
            <thead>
              <tr>
                <th>Deliverable</th>
                <th>${discipline.rateLabel.replace("Rate / ", "").replace("Rate ", "")}</th>
                <th>${discipline.inputLabel}</th>
                <th>Total Cost</th>
              </tr>
            </thead>
            <tbody>
              ${discipline.rows
                .map(
                  (row) => `
                    <tr>
                      <td>${row.deliverable}</td>
                      <td>${formatNumber(row.rate)}</td>
                      <td>${formatNumber(row.area)}</td>
                      <td>${formatCurrency(row.totalCost)}</td>
                    </tr>`,
                )
                .join("")}
            </tbody>
          </table>
        </section>
      `,
    )
    .join("");
}

function escapeHtml(value: string) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("\n", "<br />");
}

function renderScopeBreakupHtml(version: ProposalVersion) {
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const sheetSummary = calculateScopeSheetSummary(version.scopeSection.rows);

  return `
    <table class="scope-table">
      <thead>
        <tr class="scope-title">
          <th colspan="11">${escapeHtml(version.scopeSection.sheetTitle)}</th>
        </tr>
        <tr class="scope-plan-row">
          <th colspan="5">${escapeHtml(version.scopeSection.optimalLabel)}</th>
          <th class="scope-gap"></th>
          <th colspan="5">${escapeHtml(version.scopeSection.bufferedLabel)}</th>
        </tr>
        <tr>
          <th>S.No</th>
          <th>Scope</th>
          <th>Sft</th>
          <th>Rate</th>
          <th>Amount</th>
          <th class="scope-gap"></th>
          <th>S.No</th>
          <th>Scope</th>
          <th>Sft</th>
          <th>Rate</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>
        ${version.scopeSection.rows
          .map((row) => {
            if (row.kind === "spacer") {
              return `<tr class="scope-spacer"><td colspan="11"></td></tr>`;
            }

            return `
              <tr class="${row.kind === "groupHeader" ? "scope-group" : ""}">
                <td>${escapeHtml(row.leftSerial)}</td>
                <td>${escapeHtml(row.leftScope)}</td>
                ${
                  row.leftValueRowSpan
                    ? `<td rowspan="${row.leftValueRowSpan}" class="numeric">${row.leftSft === null ? "" : formatNumber(row.leftSft)}</td>
                       <td rowspan="${row.leftValueRowSpan}" class="numeric">${row.leftRate === null ? "" : formatNumber(row.leftRate)}</td>
                       <td rowspan="${row.leftValueRowSpan}" class="numeric">${row.leftAmount === null ? "" : formatCurrency(row.leftAmount)}</td>`
                    : ""
                }
                <td class="scope-gap"></td>
                <td>${escapeHtml(row.rightSerial)}</td>
                <td>${escapeHtml(row.rightScope)}</td>
                ${
                  row.rightValueRowSpan
                    ? `<td rowspan="${row.rightValueRowSpan}" class="numeric">${row.rightSft === null ? "" : formatNumber(row.rightSft)}</td>
                       <td rowspan="${row.rightValueRowSpan}" class="numeric">${row.rightRate === null ? "" : formatNumber(row.rightRate)}</td>
                       <td rowspan="${row.rightValueRowSpan}" class="numeric">${row.rightAmount === null ? "" : formatCurrency(row.rightAmount)}</td>`
                    : ""
                }
              </tr>
            `;
          })
          .join("")}
        <tr class="scope-total">
          <td></td>
          <td>${escapeHtml(version.scopeSection.totalLabel)}</td>
          <td></td>
          <td class="numeric">${formatNumber(sheetSummary.optimalRateTotal)}</td>
          <td class="numeric">${formatCurrency(scopeTotals.optimalTotal)}</td>
          <td class="scope-gap"></td>
          <td></td>
          <td>${escapeHtml(version.scopeSection.totalLabel)}</td>
          <td></td>
          <td class="numeric">${formatNumber(sheetSummary.bufferedRateTotal)}</td>
          <td class="numeric">${formatCurrency(scopeTotals.bufferedTotal)}</td>
        </tr>
      </tbody>
    </table>
  `;
}

export function renderProposalHtml(project: ProjectRecord, version: ProposalVersion) {
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const warnings = getProposalWarnings(project, version);
  const finalEstimate = calculateFinalEstimate(version.executionSection);
  const selectedPlanLabel = getExecutionPlanLabel(version.executionSection.selectedPlan);
  const { budgetA, budgetB, budgetATotal, budgetBTotal } = getExecutionBudgetTotals(version.executionSection);
  const workScopeRows = getScopeRowsForTotals(version.scopeSection.rows);
  const generatedOn = format(new Date(), "dd MMM yyyy, hh:mm a");
  const showConsultancyFee = isProposalSectionRenderable(project, version, "consultancyFee");
  const showWorkScope = isProposalSectionRenderable(project, version, "workScope");
  const showNegativeList = isProposalSectionRenderable(project, version, "negativeList");
  const showOptimalList = isProposalSectionRenderable(project, version, "optimalList");
  const showBufferedOptimalList = isProposalSectionRenderable(project, version, "bufferedOptimalList");
  const showExecutionEstimate = isProposalSectionRenderable(project, version, "executionEstimate");
  const showTimeline = isProposalSectionRenderable(project, version, "timeline");
  const showBudgetComparison = isProposalSectionRenderable(project, version, "budgetComparison");

  return `
    <!DOCTYPE html>
    <html lang="en">
      <head>
        <meta charset="utf-8" />
        <title>${project.projectName} Proposal ${version.versionLabel}</title>
        <style>
          body {
            font-family: Inter, Arial, sans-serif;
            color: #0f172a;
            margin: 0;
            padding: 32px;
            background: #f8fafc;
          }
          .page {
            background: white;
            padding: 36px;
            border-radius: 18px;
            box-shadow: 0 20px 50px rgba(15, 23, 42, 0.08);
          }
          .hero, .meta-grid, .summary-grid {
            display: grid;
            gap: 16px;
          }
          .hero {
            grid-template-columns: 1.6fr 1fr;
            margin-bottom: 28px;
          }
          .brand {
            padding: 24px;
            border-radius: 18px;
            background: linear-gradient(135deg, #0f172a, #1e3a8a);
            color: white;
          }
          .brand p, .brand h1 { margin: 0 0 12px 0; }
          .meta-card {
            padding: 24px;
            border-radius: 18px;
            background: #fff7ed;
            border: 1px solid rgba(251, 146, 60, 0.25);
          }
          .meta-grid, .summary-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
            margin-bottom: 24px;
          }
          .meta-item, .summary-item {
            padding: 18px;
            border: 1px solid #e2e8f0;
            border-radius: 16px;
            background: #fff;
          }
          .summary-item strong, .meta-item strong {
            display: block;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: #64748b;
            margin-bottom: 10px;
          }
          .section {
            margin-bottom: 28px;
          }
          .section h2, .section h3 {
            margin: 0 0 14px 0;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
          }
          th, td {
            border-bottom: 1px solid #e2e8f0;
            padding: 10px 8px;
            text-align: left;
          }
          th {
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: #475569;
            background: #f8fafc;
          }
          .footer {
            margin-top: 36px;
            padding-top: 16px;
            border-top: 1px solid #e2e8f0;
            font-size: 12px;
            color: #64748b;
            display: flex;
            justify-content: space-between;
          }
          .scope-table th, .scope-table td {
            border: 1px solid #cbd5e1;
            vertical-align: top;
          }
          .scope-title th {
            background: #0f172a;
            color: white;
            font-size: 14px;
            text-transform: none;
          }
          .scope-plan-row th {
            background: #fef3c7;
            color: #0f172a;
          }
          .scope-gap {
            background: #f8fafc;
            min-width: 8px;
            width: 8px;
          }
          .scope-group td {
            background: #fffbeb;
            font-weight: 700;
          }
          .scope-total td {
            background: #fffbeb;
            font-weight: 700;
          }
          .scope-notes-title td {
            background: #0f172a;
            color: white;
            font-weight: 700;
          }
          .scope-note td {
            background: #f8fafc;
            white-space: pre-wrap;
          }
          .scope-spacer td {
            height: 10px;
            background: #f8fafc;
          }
          .numeric {
            text-align: right;
            white-space: nowrap;
          }
          .signature-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
            margin-top: 24px;
          }
          .signature-box {
            min-height: 90px;
            border: 1px dashed #cbd5e1;
            border-radius: 14px;
            padding: 16px;
          }
          ul { margin: 0; padding-left: 18px; }
        </style>
      </head>
      <body>
        <div class="page">
          <div class="hero">
            <div class="brand">
              <p>${project.brandProfile.companyName}</p>
              <h1>${project.projectName || "Untitled Project"}</h1>
              <p>Client proposal prepared for ${project.clientName || "Client"}.</p>
              <p>${project.location || "Location pending"} | ${formatNumber(project.areaSqFt)} SQ.FT</p>
            </div>
            <div class="meta-card">
              <p><strong>Proposal ${version.versionLabel}</strong></p>
              <p>Prepared by: ${project.brandProfile.preparedBy}</p>
              <p>Generated on: ${generatedOn}</p>
            </div>
          </div>

          <div class="meta-grid">
            <div class="meta-item"><strong>Client</strong>${project.clientName || "Not set"}</div>
            <div class="meta-item"><strong>Last edited</strong>${formatDateTime(project.lastEditedAt)}</div>
            <div class="meta-item"><strong>Notes</strong>${project.notes || "No notes added."}</div>
          </div>

          <section class="section">
            <h2>Executive Summary</h2>
            <div class="summary-grid">
              <div class="summary-item"><strong>Consultancy Grand Total</strong>${formatCurrency(consultancyTotals.grandTotal)}</div>
              <div class="summary-item"><strong>Services Subtotal</strong>${formatCurrency(consultancyTotals.servicesSubtotal)}</div>
              <div class="summary-item"><strong>SST (${consultancyTotals.sstRate}%)</strong>${formatCurrency(consultancyTotals.sstAmount)}</div>
              <div class="summary-item"><strong>Plan A Goods + GST</strong>${formatCurrency(scopeTotals.optimalGrandTotal)}</div>
              <div class="summary-item"><strong>Plan B Goods + GST</strong>${formatCurrency(scopeTotals.bufferedGrandTotal)}</div>
              <div class="summary-item"><strong>Budget A Total</strong>${formatCurrency(budgetATotal)}</div>
              <div class="summary-item"><strong>Budget B Total</strong>${formatCurrency(budgetBTotal)}</div>
              <div class="summary-item"><strong>Execution Cost</strong>${formatCurrency(calculateFinalEstimate({ ...version.executionSection, importedConsultancyFee: 0 }))}</div>
              <div class="summary-item"><strong>Final Estimate</strong>${formatCurrency(finalEstimate)}</div>
              <div class="summary-item"><strong>Selected Budget</strong>${selectedPlanLabel}</div>
              <div class="summary-item"><strong>Activities</strong>${version.executionSection.timelineRows.length}</div>
            </div>
          </section>

          ${showConsultancyFee ? `<section class="section">
            <h2>Consultancy Fee Proposal</h2>
            ${renderRows(version)}
          </section>` : ""}

          ${showWorkScope ? `<section class="section">
            <h2>Scope Breakup Sheet</h2>
            ${renderScopeBreakupHtml(version)}
          </section>` : ""}

          ${showWorkScope ? `<section class="section">
            <h2>Work Scope</h2>
            <div class="meta-grid">
              ${
                workScopeRows.length > 0
                  ? workScopeRows
                      .map(
                        (row) => `
                          <div class="meta-item">
                            <strong>${escapeHtml(row.groupName ?? "Scope")}</strong>
                            ${escapeHtml(row.leftScope || row.rightScope || "-")}
                          </div>`,
                      )
                      .join("")
                  : `<div class="meta-item"><strong>Work Scope</strong>No work scope loaded yet.</div>`
              }
            </div>
          </section>` : ""}

          ${(showExecutionEstimate || showBudgetComparison || showTimeline) ? `<section class="section">
            <h2>Execution Estimate & Timeline</h2>
            ${
              showBudgetComparison && budgetA && budgetB
                ? `
                  <table style="margin-bottom:16px;">
                    <thead>
                      <tr>
                        <th>S.No</th>
                        <th>Description</th>
                        <th>Budget A Qty</th>
                        <th>Budget A Rate</th>
                        <th>Budget A Amount</th>
                        <th>Budget B Qty</th>
                        <th>Budget B Rate</th>
                        <th>Budget B Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      ${Array.from({ length: Math.max(budgetA.rows.length, budgetB.rows.length) })
                        .map((_, index) => {
                          const rowA = budgetA.rows[index];
                          const rowB = budgetB.rows[index];
                          return `
                            <tr>
                              <td>${index + 1}</td>
                              <td>${escapeHtml(rowA?.description || rowB?.description || "-")}</td>
                              <td>${rowA ? formatNumber(rowA.quantity) : "-"}</td>
                              <td>${rowA ? formatCurrency(rowA.rate) : "-"}</td>
                              <td>${rowA ? formatCurrency(rowA.totalAmount) : "-"}</td>
                              <td>${rowB ? formatNumber(rowB.quantity) : "-"}</td>
                              <td>${rowB ? formatCurrency(rowB.rate) : "-"}</td>
                              <td>${rowB ? formatCurrency(rowB.totalAmount) : "-"}</td>
                            </tr>`;
                        })
                        .join("")}
                      <tr>
                        <td colspan="4"><strong>Budget A Total</strong></td>
                        <td><strong>${formatCurrency(budgetATotal)}</strong></td>
                        <td colspan="2"><strong>Budget B Total</strong></td>
                        <td><strong>${formatCurrency(budgetBTotal)}</strong></td>
                      </tr>
                    </tbody>
                  </table>`
                : ""
            }
            ${showTimeline ? `<table>
              <thead>
                <tr>
                  <th>Activity</th>
                  <th>Days</th>
                  <th>Start Date</th>
                  <th>End Date</th>
                  <th>Remarks</th>
                </tr>
              </thead>
              <tbody>
                ${version.executionSection.timelineRows
                  .map(
                    (row) => `
                      <tr>
                        <td>${row.activity}</td>
                        <td>${row.days}</td>
                        <td>${row.startDate}</td>
                        <td>${row.endDate}</td>
                        <td>${row.remarks || "-"}</td>
                      </tr>`,
                  )
                  .join("")}
              </tbody>
            </table>
            <div class="summary-grid" style="margin-top:16px;">
              <div class="summary-item"><strong>Total Days</strong>${timelineTotals.totalDays}</div>
              <div class="summary-item"><strong>Total Months</strong>${timelineTotals.totalMonths}</div>
              <div class="summary-item"><strong>Selected Plan</strong>${selectedPlanLabel}</div>
            </div>
            ` : ""}
            ${showExecutionEstimate ? `<div class="summary-grid" style="margin-top:16px;">
              <div class="summary-item"><strong>Selected Budget</strong>${selectedPlanLabel}</div>
              <div class="summary-item"><strong>Execution Cost</strong>${formatCurrency(version.executionSection.selectedPlan === "buffered" ? budgetBTotal : budgetATotal)}</div>
              <div class="summary-item"><strong>Final Estimate</strong>${formatCurrency(finalEstimate)}</div>
            </div>` : ""}
          </section>` : ""}

          ${(showNegativeList || showOptimalList || showBufferedOptimalList) ? `<section class="section">
            <h2>Negative List & Notes</h2>
            <div class="meta-grid">
              ${showNegativeList ? `<div class="meta-item"><strong>${escapeHtml(version.scopeSection.exclusionsTitle)}</strong>${escapeHtml(version.scopeSection.note || "No notes added.")}</div>` : ""}
              ${showOptimalList ? `<div class="meta-item"><strong>Optimal List</strong>${escapeHtml(version.scopeSection.optimalExclusions || "No optimal list entries.")}</div>` : ""}
              ${showBufferedOptimalList ? `<div class="meta-item"><strong>Buffered Optimal List</strong>${escapeHtml(version.scopeSection.bufferedExclusions || "No buffered list entries.")}</div>` : ""}
            </div>
          </section>` : ""}

          <section class="section">
            <h2>Validation Notes</h2>
            ${warnings.length > 0 ? `<ul>${warnings.map((warning) => `<li>${warning}</li>`).join("")}</ul>` : "<p>All major sections are complete.</p>"}
          </section>

          <div class="signature-grid">
            <div class="signature-box">
              <strong>${project.brandProfile.signatureName}</strong><br />
              ${project.brandProfile.signatureTitle}
            </div>
            <div class="signature-box">
              <strong>Client Approval</strong><br />
              Name, signature, and date
            </div>
          </div>

          <div class="footer">
            <span>${project.brandProfile.footerText}</span>
            <span>Proposal ${version.versionLabel}</span>
          </div>
        </div>
      </body>
    </html>
  `;
}

export function buildWorkbook(project: ProjectRecord, version: ProposalVersion) {
  const workbook = XLSX.utils.book_new();
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const finalEstimate = calculateFinalEstimate(version.executionSection);
  const selectedPlanLabel = getExecutionPlanLabel(version.executionSection.selectedPlan);
  const { budgetATotal, budgetBTotal } = getExecutionBudgetTotals(version.executionSection);

  const summarySheet = XLSX.utils.aoa_to_sheet([
    ["Project", project.projectName],
    ["Client", project.clientName],
    ["Location", project.location],
    ["Area SQ.FT", project.areaSqFt],
    ["Version", version.versionLabel],
    [],
    ["Consultancy Grand Total", consultancyTotals.grandTotal],
    ["Services Subtotal", consultancyTotals.servicesSubtotal],
    ["SST", consultancyTotals.sstAmount],
    ["Plan A Goods + GST", scopeTotals.optimalGrandTotal],
    ["Plan B Goods + GST", scopeTotals.bufferedGrandTotal],
    ["Budget A Total", budgetATotal],
    ["Budget B Total", budgetBTotal],
    ["Selected Plan", selectedPlanLabel],
    ["Final Estimate", finalEstimate],
    ["Total Days", timelineTotals.totalDays],
    ["Approximate Months", timelineTotals.totalMonths],
  ]);
  summarySheet["!cols"] = [{ wch: 28 }, { wch: 24 }];

  const consultancyRows = version.consultancySection.disciplines.flatMap((discipline) => [
    [discipline.name, "", "", ""],
    ["Deliverable", "Rate / Input", "Quantity / Input", "Total Cost"],
    ...discipline.rows.map((row) => [row.deliverable, row.rate, row.area, { f: `B${0}+0`, v: row.totalCost }]),
    [],
  ]);
  const consultancySheet = XLSX.utils.aoa_to_sheet(consultancyRows);
  consultancySheet["!cols"] = [{ wch: 36 }, { wch: 18 }, { wch: 18 }, { wch: 20 }];

  const sheetSummary = calculateScopeSheetSummary(version.scopeSection.rows);
  const showNegativeList = isProposalSectionRenderable(project, version, "negativeList");
  const showOptimalList = isProposalSectionRenderable(project, version, "optimalList");
  const showBufferedOptimalList = isProposalSectionRenderable(project, version, "bufferedOptimalList");
  const scopeRows = [
    [version.scopeSection.sheetTitle, "", "", "", "", "", "", "", "", "", ""],
    [version.scopeSection.optimalLabel, "", "", "", "", "", version.scopeSection.bufferedLabel, "", "", "", ""],
    ["S.No", "Scope", "Sft", "Rate", "Amount", "", "S.No", "Scope", "Sft", "Rate", "Amount"],
    ...version.scopeSection.rows.map((row) => [
      row.leftSerial,
      row.leftScope,
      row.leftSft ?? "",
      row.leftRate ?? "",
      row.leftAmount ?? "",
      "",
      row.rightSerial,
      row.rightScope,
      row.rightSft ?? "",
      row.rightRate ?? "",
      row.rightAmount ?? "",
    ]),
    ["", version.scopeSection.totalLabel, "", sheetSummary.optimalRateTotal, scopeTotals.optimalTotal, "", "", version.scopeSection.totalLabel, "", sheetSummary.bufferedRateTotal, scopeTotals.bufferedTotal],
    [showNegativeList || showOptimalList || showBufferedOptimalList ? version.scopeSection.exclusionsTitle : "", "", "", "", "", "", "", "", "", "", ""],
    [showOptimalList ? version.scopeSection.optimalExclusions : "", "", "", "", "", "", showBufferedOptimalList ? version.scopeSection.bufferedExclusions : "", "", "", "", ""],
    [showNegativeList ? version.scopeSection.note : "", "", "", "", "", "", "", "", "", "", ""],
  ];
  const scopeSheet = XLSX.utils.aoa_to_sheet(scopeRows);
  scopeSheet["!cols"] = [
    { wch: 10 },
    { wch: 36 },
    { wch: 12 },
    { wch: 14 },
    { wch: 18 },
    { wch: 4 },
    { wch: 10 },
    { wch: 36 },
    { wch: 12 },
    { wch: 14 },
    { wch: 18 },
  ];

  // Apply merges to match printed layout: title across all columns, plan labels across left/right blocks,
  // exclusions and notes merged across full width.
  const merges: XLSX.Range[] = [];
  // title row (row 0) A1:K1
  merges.push({ s: { r: 0, c: 0 }, e: { r: 0, c: 10 } });
  // plan labels row (row 1): A2:E2 and G2:K2
  merges.push({ s: { r: 1, c: 0 }, e: { r: 1, c: 4 } });
  merges.push({ s: { r: 1, c: 6 }, e: { r: 1, c: 10 } });

  // exclusions title and note rows are near the end — calculate indexes
  const exclusionsTitleRowIndex = scopeRows.findIndex((r) => r[0] === version.scopeSection.exclusionsTitle && version.scopeSection.exclusionsTitle !== "");
  if (exclusionsTitleRowIndex !== -1) {
    merges.push({ s: { r: exclusionsTitleRowIndex, c: 0 }, e: { r: exclusionsTitleRowIndex, c: 10 } });
    // following optimal/buffered exclusions: merge left and right blocks separately
    merges.push({ s: { r: exclusionsTitleRowIndex + 1, c: 0 }, e: { r: exclusionsTitleRowIndex + 1, c: 4 } });
    merges.push({ s: { r: exclusionsTitleRowIndex + 1, c: 6 }, e: { r: exclusionsTitleRowIndex + 1, c: 10 } });
  }

  // note row (usually last)
  const noteRowIndex = scopeRows.findIndex((r) => r[0] === version.scopeSection.note && version.scopeSection.note !== "");
  if (noteRowIndex !== -1) {
    merges.push({ s: { r: noteRowIndex, c: 0 }, e: { r: noteRowIndex, c: 10 } });
  }

  scopeSheet["!merges"] = merges;

  // Apply number formats: Sft (cols 2 and 8), Rate (cols 3 and 9), Amount (cols 4 and 10)
  const currencyFormat = "#,##0.00";
  const numberFormat = "0";
  for (let r = 0; r < scopeRows.length; r++) {
    // left Sft (col 2)
    const leftSftAddr = XLSX.utils.encode_cell({ r, c: 2 });
    const leftRateAddr = XLSX.utils.encode_cell({ r, c: 3 });
    const leftAmountAddr = XLSX.utils.encode_cell({ r, c: 4 });
    const rightSftAddr = XLSX.utils.encode_cell({ r, c: 8 });
    const rightRateAddr = XLSX.utils.encode_cell({ r, c: 9 });
    const rightAmountAddr = XLSX.utils.encode_cell({ r, c: 10 });

    const leftSftCell = scopeSheet[leftSftAddr];
    const leftRateCell = scopeSheet[leftRateAddr];
    const leftAmountCell = scopeSheet[leftAmountAddr];
    const rightSftCell = scopeSheet[rightSftAddr];
    const rightRateCell = scopeSheet[rightRateAddr];
    const rightAmountCell = scopeSheet[rightAmountAddr];

    if (leftSftCell && typeof leftSftCell.v === "number") leftSftCell.z = numberFormat;
    if (leftRateCell && typeof leftRateCell.v === "number") leftRateCell.z = numberFormat;
    if (leftAmountCell && typeof leftAmountCell.v === "number") leftAmountCell.z = currencyFormat;
    if (rightSftCell && typeof rightSftCell.v === "number") rightSftCell.z = numberFormat;
    if (rightRateCell && typeof rightRateCell.v === "number") rightRateCell.z = numberFormat;
    if (rightAmountCell && typeof rightAmountCell.v === "number") rightAmountCell.z = currencyFormat;
  }

  const timelineSheet = XLSX.utils.json_to_sheet(
    version.executionSection.timelineRows.map((row) => ({
      Activity: row.activity,
      Days: row.days,
      "Start Date": row.startDate,
      "End Date": row.endDate,
      Remarks: row.remarks,
    })),
  );
  timelineSheet["!cols"] = [{ wch: 40 }, { wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 30 }];

  const metadataSheet = XLSX.utils.aoa_to_sheet([
    ["Saved Versions", project.versions.length],
    ["Active Version", project.activeVersionId],
    ["Last Edited", project.lastEditedAt],
    ["Warnings", getProposalWarnings(project, version).join(" | ") || "None"],
    ["Generated By", project.brandProfile.preparedBy],
    ["Download Name", createFileName(project.projectName, version.versionLabel, "xlsx")],
    [`${PLAN_A_SCOPE_LABEL} Total`, scopeTotals.optimalTotal],
    [`${PLAN_B_SCOPE_LABEL} Total`, scopeTotals.bufferedTotal],
  ]);

  const showConsultancyFee = isProposalSectionRenderable(project, version, "consultancyFee");
  const showScope =
    isProposalSectionRenderable(project, version, "workScope") ||
    isProposalSectionRenderable(project, version, "negativeList") ||
    isProposalSectionRenderable(project, version, "optimalList") ||
    isProposalSectionRenderable(project, version, "bufferedOptimalList");
  const showTimeline =
    isProposalSectionRenderable(project, version, "timeline") ||
    isProposalSectionRenderable(project, version, "executionEstimate") ||
    isProposalSectionRenderable(project, version, "budgetComparison");

  XLSX.utils.book_append_sheet(workbook, summarySheet, "Summary");
  if (showConsultancyFee) XLSX.utils.book_append_sheet(workbook, consultancySheet, "Consultancy Fee");
  if (showScope) XLSX.utils.book_append_sheet(workbook, scopeSheet, "Scope Breakup");
  if (showTimeline) XLSX.utils.book_append_sheet(workbook, timelineSheet, "Timeline");
  XLSX.utils.book_append_sheet(workbook, metadataSheet, "Version Metadata");

  return workbook;
}

export function createDraftPdfBlob(payload: ProposalSummaryPayload, options?: ProposalPdfOptions) {
  if (options) {
    return buildConfiguredProposalPdf(payload, options);
  }
  return buildConfiguredProposalPdf(payload, createDefaultPdfOptions(payload.project));
}







