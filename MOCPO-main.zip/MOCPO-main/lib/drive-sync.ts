import type { ProposalSummaryPayload } from "@/lib/types";

export interface DriveClient {
  name: string;
  folderId: string;
}

export interface DriveProject {
  name: string;
  folderId: string;
}

export interface DriveVersion {
  name: string;
  versionNumber: number;
  folderId: string;
}

interface JsonLikeResponse {
  ok?: boolean;
  success?: boolean;
  mongoSaved?: boolean;
  driveSaved?: boolean;
  message?: string;
  error?: string;
  projectFolderUrl?: string;
}

function getAppsScriptUrl(): string {
  const url = process.env.NEXT_PUBLIC_APPS_SCRIPT_URL;
  if (!url) {
    console.warn(
      "NEXT_PUBLIC_APPS_SCRIPT_URL not configured. Drive sync disabled. Set it in .env.local to enable."
    );
    return "";
  }
  return url;
}

async function parseJsonResponse(response: Response, label: string): Promise<JsonLikeResponse> {
  const text = await response.text();
  const contentType = response.headers.get("content-type") || "";
  const safeUrl = response.url || label;
  const preview = text.replace(/\s+/g, " ").trim().slice(0, 300);

  if (!response.ok) {
    throw new Error(`${label} failed with HTTP ${response.status} from ${safeUrl}. Response preview: ${preview || "<empty>"}`);
  }

  if (!contentType.toLowerCase().includes("application/json")) {
    throw new Error(
      `${label} returned ${contentType || "non-JSON content"} from ${safeUrl}. Response preview: ${preview || "<empty>"}`,
    );
  }

  if (!text.trim()) {
    throw new Error(`${label} returned an empty JSON response from ${safeUrl}.`);
  }

  try {
    return JSON.parse(text) as JsonLikeResponse;
  } catch {
    throw new Error(`${label} returned invalid JSON from ${safeUrl}. Response preview: ${preview || "<empty>"}`);
  }
}

export function isDriveSyncEnabled(): boolean {
  return Boolean(getAppsScriptUrl());
}

export async function saveVersionToDrive(
  payload: ProposalSummaryPayload
): Promise<{ success: boolean; mongoSaved: boolean; driveSaved: boolean; message: string; projectFolderUrl?: string }> {
  try {
    const apiUrl = "/api/google/drive/save-version";
    console.info(`[drive-sync] saveProposalFiles -> ${apiUrl}`);

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    const result = await parseJsonResponse(response, "Drive sync API");

    return {
      success: Boolean(result.ok ?? result.success),
      mongoSaved: Boolean(result.mongoSaved),
      driveSaved: Boolean(result.driveSaved),
      message: result.message || result.error || "Unknown error",
      projectFolderUrl: result.projectFolderUrl,
    };
  } catch (error) {
    return {
      success: false,
      mongoSaved: false,
      driveSaved: false,
      message: `Drive sync failed: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

export async function listClientsFromDrive(): Promise<DriveClient[]> {
  const url = getAppsScriptUrl();
  if (!url) {
    return [];
  }

  try {
    const targetUrl = `${url}?action=listClients`;
    console.info(`[drive-sync] listClients -> ${targetUrl}`);
    const response = await fetch(targetUrl);
    const result = await parseJsonResponse(response, "Drive clients") as JsonLikeResponse & { clients?: DriveClient[] };
    return result.success ? result.clients || [] : [];
  } catch (error) {
    console.error("Failed to list clients from Drive:", error);
    return [];
  }
}

export async function listProjectsFromDrive(
  clientName: string
): Promise<DriveProject[]> {
  const url = getAppsScriptUrl();
  if (!url) {
    return [];
  }

  try {
    const params = new URLSearchParams({
      action: "listProjects",
      clientName,
    });
    const targetUrl = `${url}?${params}`;
    console.info(`[drive-sync] listProjects -> ${targetUrl}`);
    const response = await fetch(targetUrl);
    const result = await parseJsonResponse(response, "Drive projects") as JsonLikeResponse & { projects?: DriveProject[] };
    return result.success ? result.projects || [] : [];
  } catch (error) {
    console.error("Failed to list projects from Drive:", error);
    return [];
  }
}

export async function listVersionsFromDrive(
  clientName: string,
  projectName: string
): Promise<DriveVersion[]> {
  const url = getAppsScriptUrl();
  if (!url) {
    return [];
  }

  try {
    const params = new URLSearchParams({
      action: "listVersions",
      clientName,
      projectName,
    });
    const targetUrl = `${url}?${params}`;
    console.info(`[drive-sync] listVersions -> ${targetUrl}`);
    const response = await fetch(targetUrl);
    const result = await parseJsonResponse(response, "Drive versions") as JsonLikeResponse & { versions?: DriveVersion[] };
    return result.success ? result.versions || [] : [];
  } catch (error) {
    console.error("Failed to list versions from Drive:", error);
    return [];
  }
}

export async function getVersionDataFromDrive(
  clientName: string,
  projectName: string,
  versionNumber: number
): Promise<unknown | null> {
  const url = getAppsScriptUrl();
  if (!url) {
    return null;
  }

  try {
    const params = new URLSearchParams({
      action: "getVersionData",
      clientName,
      projectName,
      versionNumber: versionNumber.toString(),
    });
    const targetUrl = `${url}?${params}`;
    console.info(`[drive-sync] getVersionData -> ${targetUrl}`);
    const response = await fetch(targetUrl);
    const result = await parseJsonResponse(response, "Drive version data") as JsonLikeResponse & { data?: unknown };
    return result.success ? result.data ?? null : null;
  } catch (error) {
    console.error("Failed to get version data from Drive:", error);
    return null;
  }
}
