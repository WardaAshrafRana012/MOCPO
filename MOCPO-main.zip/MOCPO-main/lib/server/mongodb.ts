import { MongoClient, ServerApiVersion } from "mongodb";

import type { ProjectRecord, ProposalSummaryPayload } from "@/lib/types";

const DEFAULT_COLLECTION_NAME = "proposal_records";

type GlobalMongoCache = {
  mongoClientPromise?: Promise<MongoClient>;
};

const globalForMongo = globalThis as typeof globalThis & GlobalMongoCache;

function getMongoConfig() {
  return {
    uri: process.env.MONGODB_URI || "",
    dbName: process.env.MONGODB_DB_NAME || "mocpo",
    collectionName: process.env.MONGODB_COLLECTION_NAME || DEFAULT_COLLECTION_NAME,
  };
}

export function isMongoConfigured(): boolean {
  const { uri } = getMongoConfig();
  return Boolean(uri);
}

async function getMongoClient(): Promise<MongoClient> {
  const { uri } = getMongoConfig();

  if (!uri) {
    throw new Error("MongoDB is not configured. MONGODB_URI is missing.");
  }

  if (!globalForMongo.mongoClientPromise) {
    const client = new MongoClient(uri, {
      serverApi: {
        version: ServerApiVersion.v1,
        strict: true,
        deprecationErrors: true,
      },
    });

    globalForMongo.mongoClientPromise = client.connect();
  }

  return globalForMongo.mongoClientPromise;
}

export interface ProposalMongoSyncMetadata {
  driveSyncStatus: "pending" | "success" | "failed" | "skipped";
  driveMessage?: string;
  projectFolderUrl?: string;
  files?: Array<{ type?: string; fileName?: string; fileUrl?: string }>;
}

export async function saveProposalPayloadToMongo(
  payload: ProposalSummaryPayload,
  metadata: ProposalMongoSyncMetadata,
): Promise<{ enabled: boolean; saved: boolean }> {
  if (!isMongoConfigured()) {
    return { enabled: false, saved: false };
  }

  const client = await getMongoClient();
  const { dbName, collectionName } = getMongoConfig();
  const collection = client.db(dbName).collection(collectionName);
  const now = new Date().toISOString();

  await collection.updateOne(
    {
      projectId: payload.project.projectId,
      versionId: payload.version.id,
    },
    {
      $set: {
        projectId: payload.project.projectId,
        versionId: payload.version.id,
        versionLabel: payload.version.versionLabel,
        projectName: payload.project.projectName,
        clientName: payload.project.clientName,
        proposalStatus: payload.project.proposalStatus,
        activeVersionId: payload.project.activeVersionId,
        currentDraftVersionId: payload.project.currentDraftVersionId,
        lastEditedAt: payload.project.lastEditedAt,
        savedAt: payload.version.savedAt || now,
        updatedAt: now,
        driveSync: {
          status: metadata.driveSyncStatus,
          message: metadata.driveMessage || "",
          projectFolderUrl: metadata.projectFolderUrl || "",
          files: metadata.files || [],
          updatedAt: now,
        },
        payload,
      },
      $setOnInsert: {
        createdAt: now,
      },
    },
    { upsert: true },
  );

  return { enabled: true, saved: true };
}

export async function listLatestProjectsFromMongo(): Promise<ProjectRecord[]> {
  if (!isMongoConfigured()) {
    return [];
  }

  const client = await getMongoClient();
  const { dbName, collectionName } = getMongoConfig();
  const collection = client.db(dbName).collection(collectionName);

  const docs = await collection
    .find({}, { projection: { payload: 1, updatedAt: 1 } })
    .sort({ updatedAt: -1 })
    .toArray();

  const seen = new Set<string>();
  const projects: ProjectRecord[] = [];

  for (const doc of docs) {
    const payload = doc.payload as ProposalSummaryPayload | undefined;
    const project = payload?.project;

    if (!project?.projectId || seen.has(project.projectId)) {
      continue;
    }

    seen.add(project.projectId);
    projects.push(project);
  }

  return projects;
}
