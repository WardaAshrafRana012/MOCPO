﻿import ExcelJS from "exceljs";

import {
  calculateConsultancyTotals,
  calculateFinalEstimate,
  calculatePaymentScheduleSummary,
  calculateScopeTotals,
  getExecutionBudgetTotals,
  getExecutionPlanLabel,
  getSelectedExecutionCost,
} from "@/lib/calculations";
import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";
import type { ExecutionBudgetPlan, ProjectRecord, ProposalVersion, ScopeSheetRow, TimelineRow } from "@/lib/types";

const COLORS = {
  navy: "0F172A",
  gold: "FEF3C7",
  soft: "F8FAFC",
  slate: "CBD5E1",
  white: "FFFFFF",
};

const thinBorder = {
  top: { style: "thin" as const, color: { argb: COLORS.slate } },
  left: { style: "thin" as const, color: { argb: COLORS.slate } },
  bottom: { style: "thin" as const, color: { argb: COLORS.slate } },
  right: { style: "thin" as const, color: { argb: COLORS.slate } },
};

function styleCell(cell: ExcelJS.Cell, options: Partial<ExcelJS.Style>) {
  cell.style = {
    ...cell.style,
    ...options,
  };
}

function applyTableHeader(row: ExcelJS.Row) {
  row.eachCell((cell) => {
    styleCell(cell, {
      font: { bold: true, color: { argb: COLORS.white }, size: 11 },
      fill: { type: "pattern", pattern: "solid", fgColor: { argb: COLORS.navy } },
      alignment: { vertical: "middle", horizontal: "center", wrapText: true },
      border: thinBorder,
    });
  });
}

function applyBodyRow(row: ExcelJS.Row) {
  row.eachCell((cell) => {
    styleCell(cell, {
      border: thinBorder,
      alignment: { vertical: "top", wrapText: true },
      font: { size: 10, color: { argb: COLORS.navy } },
    });
  });
}

function applyLabelValueRow(sheet: ExcelJS.Worksheet, label: string, value: string | number) {
  const row = sheet.addRow([label, value]);
  applyBodyRow(row);
  styleCell(row.getCell(1), {
    font: { bold: true, color: { argb: COLORS.navy } },
    fill: { type: "pattern", pattern: "solid", fgColor: { argb: COLORS.soft } },
  });
  return row;
}

function applyCurrencyCell(cell: ExcelJS.Cell) {
  styleCell(cell, {
    numFmt: "#,##0.00",
    font: { bold: true, color: { argb: COLORS.navy }, size: 10 },
  });
}

function applySectionTitle(sheet: ExcelJS.Worksheet, title: string, width = 6) {
  const row = sheet.addRow([title, ...Array.from({ length: Math.max(width - 1, 0) }, () => "")]);
  row.eachCell((cell) => {
    styleCell(cell, {
      font: { bold: true, color: { argb: COLORS.navy }, size: 11 },
      fill: { type: "pattern", pattern: "solid", fgColor: { argb: COLORS.gold } },
      border: thinBorder,
    });
  });
  return row;
}

function buildTextSection(sheet: ExcelJS.Worksheet, title: string, value: string, width = 6) {
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return;
  }

  applySectionTitle(sheet, title, width);
  const row = sheet.addRow([trimmedValue, ...Array.from({ length: Math.max(width - 1, 0) }, () => "")]);
  applyBodyRow(row);
  sheet.addRow([]);
}

function hasMeaningfulTimelineRow(row: TimelineRow) {
  return Boolean(row.activity.trim() || row.days > 0 || row.startDate || row.endDate || row.remarks.trim());
}

function getMeaningfulBudgetRows(plan?: ExecutionBudgetPlan) {
  return (plan?.rows ?? []).filter((row) =>
    Boolean(
      (row.description.trim() && row.description.trim() !== "New cost item") ||
        row.quantity > 0 ||
        row.rate > 0 ||
        row.totalAmount > 0 ||
        row.remarks.trim(),
    ),
  );
}

function buildConsultancySheet(workbook: ExcelJS.Workbook, project: ProjectRecord, version: ProposalVersion) {
  if (!isProposalSectionRenderable(project, version, "consultancyFee")) {
    return;
  }

  const sheet = workbook.addWorksheet("Consultancy Fee");
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );

  sheet.columns = [
    { width: 18 },
    { width: 54 },
    { width: 16 },
    { width: 16 },
    { width: 18 },
  ];

  applyLabelValueRow(sheet, "Project Name", project.projectName || "-");
  applyLabelValueRow(sheet, "Client Name", project.clientName || "-");
  sheet.addRow([]);

  const header = sheet.addRow(["Phase / S.No", "Design Deliverable / Consultancies", "Rate", "Input", "Total Cost PKR"]);
  applyTableHeader(header);

  for (const discipline of version.consultancySection.disciplines) {
    const titleRow = sheet.addRow([discipline.name, "", "", "", ""]);
    titleRow.eachCell((cell) => {
      styleCell(cell, {
        font: { bold: true, color: { argb: COLORS.navy }, size: 11 },
        fill: { type: "pattern", pattern: "solid", fgColor: { argb: COLORS.gold } },
        border: thinBorder,
      });
    });

    for (const row of discipline.rows) {
      const dataRow = sheet.addRow([row.phaseLabel, row.deliverable, row.rate, row.area, row.totalCost]);
      applyBodyRow(dataRow);
      applyCurrencyCell(dataRow.getCell(5));
    }
  }

  sheet.addRow([]);
  const subtotalRow = applyLabelValueRow(sheet, "Services Subtotal", consultancyTotals.servicesSubtotal);
  applyCurrencyCell(subtotalRow.getCell(2));
  const taxRow = applyLabelValueRow(sheet, `SST ${consultancyTotals.sstRate}%`, consultancyTotals.sstAmount);
  applyCurrencyCell(taxRow.getCell(2));
  const totalRow = applyLabelValueRow(sheet, "Consultancy Grand Total", consultancyTotals.servicesTotalWithTax);
  applyCurrencyCell(totalRow.getCell(2));
}

function buildScopePlanTable(
  sheet: ExcelJS.Worksheet,
  title: string,
  rows: ScopeSheetRow[],
  selector: "left" | "right",
  subtotal: number,
  gstRate: number,
  gstAmount: number,
  grandTotal: number,
) {
  applySectionTitle(sheet, title, 6);

  const header = sheet.addRow(["Group", "S.No", "Scope", "Sft", "Rate", "Amount"]);
  applyTableHeader(header);

  for (const row of rows) {
    const groupName = row.groupName || "Scope";
    const serial = selector === "left" ? row.leftSerial : row.rightSerial;
    const scope = selector === "left" ? row.leftScope : row.rightScope;
    const sft = selector === "left" ? row.leftSft : row.rightSft;
    const rate = selector === "left" ? row.leftRate : row.rightRate;
    const amount = selector === "left" ? row.leftAmount : row.rightAmount;
    if (!scope && !amount) {
      continue;
    }
    const dataRow = sheet.addRow([groupName, serial, scope, sft ?? "", rate ?? "", amount ?? 0]);
    applyBodyRow(dataRow);
    applyCurrencyCell(dataRow.getCell(6));
  }

  const subtotalLabel = title.includes("Plan B") ? "Plan B Net Total" : "Plan A Net Total";
  const taxLabel = title.includes("Plan B") ? `Plan B Tax @ GST ${gstRate}%` : `Plan A Tax @ GST ${gstRate}%`;
  const totalLabel = title.includes("Plan B") ? "Plan B Total Amount With Tax" : "Plan A Total Amount With Tax";

  const subtotalRow = applyLabelValueRow(sheet, subtotalLabel, subtotal);
  applyCurrencyCell(subtotalRow.getCell(2));
  const taxRow = applyLabelValueRow(sheet, taxLabel, gstAmount);
  applyCurrencyCell(taxRow.getCell(2));
  const totalRow = applyLabelValueRow(sheet, totalLabel, grandTotal);
  applyCurrencyCell(totalRow.getCell(2));
  sheet.addRow([]);
}

function buildScopeSheet(workbook: ExcelJS.Workbook, project: ProjectRecord, version: ProposalVersion) {
  const showWorkScope = isProposalSectionRenderable(project, version, "workScope");
  const showNegativeList = isProposalSectionRenderable(project, version, "negativeList");
  const showOptimalList = isProposalSectionRenderable(project, version, "optimalList");
  const showBufferedOptimalList = isProposalSectionRenderable(project, version, "bufferedOptimalList");

  if (!showWorkScope && !showNegativeList && !showOptimalList && !showBufferedOptimalList) {
    return;
  }

  const rows = getScopeRowsForTotals(version.scopeSection.rows);
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const hasPlanARows = rows.some((row) => (row.leftAmount ?? 0) > 0 || Boolean(row.leftScope));
  const hasPlanBRows = rows.some((row) => (row.rightAmount ?? 0) > 0 || Boolean(row.rightScope));
  const hasVisibleContent =
    (showWorkScope && (hasPlanARows || hasPlanBRows)) ||
    (showNegativeList && version.scopeSection.note.trim()) ||
    (showOptimalList && version.scopeSection.optimalExclusions.trim()) ||
    (showBufferedOptimalList && version.scopeSection.bufferedExclusions.trim());

  if (!hasVisibleContent) {
    return;
  }

  const sheet = workbook.addWorksheet("Workscope Break-up");
  sheet.columns = [
    { width: 24 },
    { width: 12 },
    { width: 48 },
    { width: 12 },
    { width: 14 },
    { width: 18 },
  ];

  applyLabelValueRow(sheet, "Project Name", project.projectName || "-");
  sheet.addRow([]);

  if (showWorkScope) {
    const planARows = rows.filter((row) => (row.leftAmount ?? 0) > 0 || Boolean(row.leftScope));
    const planBRows = rows.filter((row) => (row.rightAmount ?? 0) > 0 || Boolean(row.rightScope));

    if (planARows.length > 0) {
      buildScopePlanTable(
        sheet,
        version.scopeSection.optimalLabel || "Plan A",
        planARows,
        "left",
        scopeTotals.planANetTotal,
        scopeTotals.gstRate,
        scopeTotals.planATaxAmount,
        scopeTotals.planATotalWithTax,
      );
    }

    if (planBRows.length > 0) {
      buildScopePlanTable(
        sheet,
        version.scopeSection.bufferedLabel || "Plan B",
        planBRows,
        "right",
        scopeTotals.planBNetTotal,
        scopeTotals.gstRate,
        scopeTotals.planBTaxAmount,
        scopeTotals.planBTotalWithTax,
      );
    }
  }

  if (showNegativeList) {
    buildTextSection(sheet, version.scopeSection.exclusionsTitle || "Negative List", version.scopeSection.note, 6);
  }

  if (showOptimalList) {
    buildTextSection(sheet, "Optimal List", version.scopeSection.optimalExclusions, 6);
  }

  if (showBufferedOptimalList) {
    buildTextSection(sheet, "Buffered Optimal List", version.scopeSection.bufferedExclusions, 6);
  }
}

function buildExecutionSummary(sheet: ExcelJS.Worksheet, version: ProposalVersion) {
  applySectionTitle(sheet, "Execution Estimate", 2);
  applyLabelValueRow(sheet, "Selected Plan", getExecutionPlanLabel(version.executionSection.selectedPlan));
  const executionCostRow = applyLabelValueRow(sheet, "Execution Cost", getSelectedExecutionCost(version.executionSection));
  applyCurrencyCell(executionCostRow.getCell(2));
  const finalEstimateRow = applyLabelValueRow(sheet, "Final Estimate", calculateFinalEstimate(version.executionSection));
  applyCurrencyCell(finalEstimateRow.getCell(2));
  sheet.addRow([]);
}

function buildTimelineSection(sheet: ExcelJS.Worksheet, timelineRows: TimelineRow[]) {
  applySectionTitle(sheet, "Timeline", 5);
  const timelineHeader = sheet.addRow(["Activity", "Days", "Start Date", "End Date", "Remarks"]);
  applyTableHeader(timelineHeader);
  for (const row of timelineRows) {
    const dataRow = sheet.addRow([row.activity, row.days, row.startDate, row.endDate, row.remarks]);
    applyBodyRow(dataRow);
  }
  sheet.addRow([]);
}

function buildBudgetPlanSection(sheet: ExcelJS.Worksheet, title: string, rows: ReturnType<typeof getMeaningfulBudgetRows>) {
  if (rows.length === 0) {
    return;
  }

  applySectionTitle(sheet, title, 5);
  const header = sheet.addRow(["Description", "Quantity", "Rate", "Amount", "Remarks"]);
  applyTableHeader(header);
  for (const row of rows) {
    const dataRow = sheet.addRow([row.description, row.quantity, row.rate, row.totalAmount, row.remarks]);
    applyBodyRow(dataRow);
    applyCurrencyCell(dataRow.getCell(4));
  }
  sheet.addRow([]);
}

function buildExecutionSheet(workbook: ExcelJS.Workbook, project: ProjectRecord, version: ProposalVersion) {
  const showExecutionEstimate = isProposalSectionRenderable(project, version, "executionEstimate");
  const showTimeline = isProposalSectionRenderable(project, version, "timeline");
  const showBudgetComparison = isProposalSectionRenderable(project, version, "budgetComparison");

  if (!showExecutionEstimate && !showTimeline && !showBudgetComparison) {
    return;
  }

  const timelineRows = version.executionSection.timelineRows.filter(hasMeaningfulTimelineRow);
  const { budgetA, budgetB } = getExecutionBudgetTotals(version.executionSection);
  const planARows = getMeaningfulBudgetRows(budgetA);
  const planBRows = getMeaningfulBudgetRows(budgetB);
  const hasVisibleContent =
    showExecutionEstimate ||
    (showTimeline && timelineRows.length > 0) ||
    (showBudgetComparison && (planARows.length > 0 || planBRows.length > 0));

  if (!hasVisibleContent) {
    return;
  }

  const sheet = workbook.addWorksheet("Execution Estimate");
  sheet.columns = [
    { width: 28 },
    { width: 14 },
    { width: 16 },
    { width: 16 },
    { width: 28 },
  ];

  if (showExecutionEstimate) {
    buildExecutionSummary(sheet, version);
  }

  if (showTimeline && timelineRows.length > 0) {
    buildTimelineSection(sheet, timelineRows);
  }

  if (showBudgetComparison) {
    buildBudgetPlanSection(sheet, "Plan A", planARows);
    buildBudgetPlanSection(sheet, "Plan B", planBRows);
  }
}

function buildPaymentScheduleSheet(workbook: ExcelJS.Workbook, project: ProjectRecord, version: ProposalVersion) {
  if (!isProposalSectionRenderable(project, version, "paymentSchedule")) {
    return;
  }

  const sheet = workbook.addWorksheet("Payment Schedule");
  sheet.columns = [
    { width: 26 },
    { width: 14 },
    { width: 18 },
    { width: 16 },
    { width: 52 },
  ];

  applyLabelValueRow(sheet, "Project Name", project.projectName || "-");
  applyLabelValueRow(sheet, "Client Name", project.clientName || "-");
  const totalRow = applyLabelValueRow(sheet, "Proposal Grand Total", version.paymentSchedule.grandTotal);
  applyCurrencyCell(totalRow.getCell(2));
  sheet.addRow([]);

  const header = sheet.addRow(["Installment", "Percentage", "Amount", "Due Date", "Description / Milestone"]);
  applyTableHeader(header);

  for (const row of version.paymentSchedule.rows) {
    const dataRow = sheet.addRow([row.name, row.percentage, row.amount, row.dueDate, row.description]);
    applyBodyRow(dataRow);
    applyCurrencyCell(dataRow.getCell(3));
  }

  const summary = calculatePaymentScheduleSummary(version.paymentSchedule);
  sheet.addRow([]);
  applyLabelValueRow(sheet, "Total Percentage", summary.allocatedPercentage + "%");
  const amountSummaryRow = applyLabelValueRow(sheet, "Total Amount", summary.totalAmount);
  applyCurrencyCell(amountSummaryRow.getCell(2));
  if (version.paymentSchedule.notes.trim()) {
    buildTextSection(sheet, "Payment Notes", version.paymentSchedule.notes, 5);
  }
}

export async function buildProposalWorkbookBuffer(project: ProjectRecord, version: ProposalVersion) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = project.brandProfile.companyName;
  workbook.company = project.brandProfile.companyName;
  workbook.created = new Date();

  buildConsultancySheet(workbook, project, version);
  buildScopeSheet(workbook, project, version);
  buildExecutionSheet(workbook, project, version);
  buildPaymentScheduleSheet(workbook, project, version);

  return Buffer.from(await workbook.xlsx.writeBuffer());
}
