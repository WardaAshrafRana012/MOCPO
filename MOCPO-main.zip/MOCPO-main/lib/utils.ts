import { type ClassValue, clsx } from "clsx";
import { format } from "date-fns";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(value: number) {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    maximumFractionDigits: 0,
  }).format(Number.isFinite(value) ? value : 0);
}

export function formatNumber(value: number) {
  return new Intl.NumberFormat("en-PK", {
    maximumFractionDigits: 2,
  }).format(Number.isFinite(value) ? value : 0);
}

export function getEditableNumberInputValue(value?: number | null): string | number {
  if (!Number.isFinite(value) || value === 0) return "";
  return Number(value);
}

export function formatDateTime(value?: string | null) {
  if (!value) return "Not saved yet";

  try {
    return format(new Date(value), "dd MMM yyyy, hh:mm a");
  } catch {
    return value;
  }
}

export function sanitizeFileNamePart(value: string) {
  const cleaned = value.trim().replace(/[^a-zA-Z0-9-_]+/g, "_");
  return cleaned.length > 0 ? cleaned : "Project";
}

export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export function createId(prefix: string) {
  return `${prefix}-${crypto.randomUUID()}`;
}
