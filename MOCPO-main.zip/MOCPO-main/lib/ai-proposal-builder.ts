import { createDefaultProposalSectionVisibility, createDefaultWorkspaceSections } from "@/lib/proposal-sections";
import { createBlankExecutionSection, createConsultancyDiscipline, createDistributedTimelineRows, createExecutionSection } from "@/lib/seeds";
import { createScopeSection } from "@/lib/scope-sheet";
import { createEmptyPaymentSchedule } from "@/lib/payment-schedule";
import type { AIProposalDraft, DisciplineName, ExecutionPlan, ProjectRecord, ProposalVersion } from "@/lib/types";

const deliverableMap: Array<{ match: RegExp; discipline: DisciplineName }> = [
  { match: /architect/i, discipline: "Architecture" },
  { match: /interior/i, discipline: "Interior" },
  { match: /mep|electrical|mechanical|plumbing/i, discipline: "MEP Design" },
  { match: /structur/i, discipline: "Structure" },
  { match: /facade|fa[cç]ade/i, discipline: "Facade Engineering" },
  { match: /landscape/i, discipline: "Landscaping" },
  { match: /site coordination|top supervision|supervision/i, discipline: "Top Supervision" },
  { match: /resident engineering|resident supervision/i, discipline: "Resident Engineering & Supervision Team" },
];

const scopeMap: Array<{ match: RegExp; groupId: string }> = [
  { match: /architecture|interior|category:\s*architecture|category:\s*interior/i, groupId: "id-scope" },
  { match: /design/i, groupId: "design-scope" },
  { match: /hvac|mep|mechanical/i, groupId: "hvac" },
  { match: /electrical|power|lighting/i, groupId: "electrical" },
  { match: /furniture|landscape|turnkey/i, groupId: "furniture" },
];

const projectDefaults: Array<{
  match: RegExp;
  projectName: string;
  areaSqFt: number;
  timelineDays: number;
}> = [
  { match: /residential villa|luxury villa|villa/i, projectName: "Residential Villa", areaSqFt: 5000, timelineDays: 150 },
  { match: /apartment/i, projectName: "Apartment", areaSqFt: 2500, timelineDays: 90 },
  { match: /corporate office|office/i, projectName: "Corporate Office", areaSqFt: 6000, timelineDays: 120 },
  { match: /retail/i, projectName: "Retail Project", areaSqFt: 3000, timelineDays: 90 },
  { match: /hospitality/i, projectName: "Hospitality Project", areaSqFt: 3500, timelineDays: 100 },
  { match: /hotel/i, projectName: "Hotel Project", areaSqFt: 10000, timelineDays: 180 },
  { match: /healthcare|hospital|clinic/i, projectName: "Healthcare Project", areaSqFt: 8000, timelineDays: 150 },
  { match: /educational|school|college|university/i, projectName: "Educational Project", areaSqFt: 12000, timelineDays: 180 },
  { match: /industrial|factory|warehouse/i, projectName: "Industrial Project", areaSqFt: 20000, timelineDays: 180 },
];

function readField(prompt: string, label: string) {
  const regex = new RegExp(`${label}\\s*:\\s*(.+?)(?:\\.|\\n|$)`, "i");
  const match = prompt.match(regex);
  return match?.[1]?.trim() ?? "";
}

function readNaturalLanguageField(prompt: string, pattern: RegExp) {
  return prompt.match(pattern)?.[1]?.trim() ?? "";
}

function cleanExtractedValue(value: string) {
  return value
    .replace(/^[\s,:-]+|[\s,:-]+$/g, "")
    .replace(/[.,;:]+$/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function titleCaseWords(value: string) {
  return value
    .split(/\s+/)
    .filter(Boolean)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

function readFlexibleField(prompt: string, patterns: RegExp[]) {
  for (const pattern of patterns) {
    const match = prompt.match(pattern);
    if (match?.[1]) {
      return cleanExtractedValue(match[1]);
    }
  }

  return "";
}

function getProjectDefaults(prompt: string) {
  return projectDefaults.find((item) => item.match.test(prompt));
}

function parseSelectedPlan(prompt: string): ExecutionPlan {
  if (/plan\s*a\s*(?:and|&)\s*plan\s*b|plan\s*a\s*(?:and|&)\s*b|both/i.test(prompt)) return "both";
  if (/budget\s*plan\s*b|plan\s*b\b/i.test(prompt)) return "buffered";
  if (/budget\s*plan\s*a|plan\s*a\b/i.test(prompt)) return "optimal";
  return null;
}

function isGenericClientCandidate(value: string) {
  const normalized = value.trim().toLowerCase();
  if (!normalized) return true;
  if (/^(a|an|the)\b/.test(normalized)) return true;
  if (/\b(villa|apartment|office|retail|hotel|healthcare|hospitality|industrial|educational|project)\b/.test(normalized)) {
    return true;
  }
  return false;
}

function normalizeClientName(value: string) {
  const cleaned = cleanExtractedValue(value);
  return isGenericClientCandidate(cleaned) ? "" : titleCaseWords(cleaned);
}

function parseArea(prompt: string) {
  const direct = readField(prompt, "Area");
  const raw =
    direct.match(/(\d[\d,]*)/i)?.[1] ||
    prompt.match(/area\s*[:\-]?\s*(\d[\d,]*)/i)?.[1] ||
    prompt.match(/(\d[\d,]*)\s*(sq\.?\s*ft|sqft|square feet)/i)?.[1] ||
    "";
  const value = Number(raw.replace(/,/g, ""));
  return Number.isFinite(value) ? value : 0;
}

function parseTimelineDays(prompt: string) {
  const direct = readField(prompt, "Timeline");
  const match = (direct || prompt).match(/(\d[\d,]*)\s*days?/i);
  if (!match) return 150;
  const value = Number(match[1].replace(/,/g, ""));
  return Number.isFinite(value) ? value : 150;
}

function collectMatches<T>(prompt: string, items: Array<{ match: RegExp } & T>, key: keyof T) {
  const result = new Set<string>();
  for (const item of items) {
    if (item.match.test(prompt)) {
      result.add(String(item[key]));
    }
  }
  return Array.from(result);
}

function defaultNegativeList(executionPlan: string) {
  return [
    "Branding Work",
    "Server Racks",
    executionPlan ? `Execution exclusions reviewed for ${executionPlan}` : "Execution exclusions reviewed",
  ].join("\n");
}

function buildDraftSummary(draft: Pick<AIProposalDraft, "clientName" | "projectName" | "location" | "executionPlan" | "timelineDays" | "deliverables">) {
  const deliverables = draft.deliverables.join(", ");
  return `${draft.projectName || "Untitled project"} for ${draft.clientName || "pending client"} in ${draft.location || "pending location"} with ${deliverables || "pending deliverables"} using ${draft.executionPlan || "pending execution plan"} over ${draft.timelineDays || 0} days.`;
}

export function parseProposalPrompt(prompt: string): AIProposalDraft {
  const defaults = getProjectDefaults(prompt);
  const clientName =
    readField(prompt, "Client Name") ||
    readField(prompt, "Client") ||
    readFlexibleField(prompt, [
      /([A-Za-z0-9&][A-Za-z0-9&().,\-\/\s]*?)\s+client\b/i,
      /client\s*[:\-]\s*([A-Za-z0-9&][A-Za-z0-9&().,\-\/\s]*?)(?=\s*(?:,|and\s+project|project\b|area\b|location\b|include\b|timeline\b|plan\b|with\b|$))/i,
      /proposal\s+for\s+([A-Za-z0-9&][A-Za-z0-9&().,\-\/\s]*?)(?=\s*(?:,|project\b|area\b|location\b|include\b|timeline\b|plan\b|$))/i,
    ]);
  const projectName =
    readField(prompt, "Project Name") ||
    readField(prompt, "Project") ||
    readFlexibleField(prompt, [
      /project(?:\s+name)?\s*[:\-]?\s*([A-Za-z0-9][A-Za-z0-9&().,\-\/\s]*?)(?=\s*(?:,|and\s+area|area\b|location\b|include\b|timeline\b|plan\b|with\b|$))/i,
    ]) ||
    defaults?.projectName ||
    "";
  const location =
    readField(prompt, "Location") ||
    readFlexibleField(prompt, [
      /location\s*[:\-]?\s*([A-Za-z][A-Za-z,\-\/\s]*?)(?=\s*(?:,|and\s+include|include\b|timeline\b|plan\b|scope\b|$))/i,
      /\bin\s+([A-Za-z][A-Za-z,\-\/\s]*?)(?=\s*(?:,|with\b|include\b|timeline\b|plan\b|for\b|scope\b|$))/i,
    ]);
  const executionPlan =
    readField(prompt, "Execution Plan") ||
    readFlexibleField(prompt, [
      /execution\s+plan\s*[:\-]?\s*([A-Za-z0-9][A-Za-z0-9\s-]*?)(?=\s*(?:,|and\s+timeline|timeline\b|$))/i,
      /package\s*[:\-]?\s*([A-Za-z0-9][A-Za-z0-9\s-]*?)(?=\s*(?:,|and\s+timeline|timeline\b|$))/i,
    ]) ||
    readNaturalLanguageField(prompt, /use\s+the\s+([^.\n]+?execution plan[^.\n]*)/i) ||
    readNaturalLanguageField(prompt, /(basic|standard|premium)(?:\s+turnkey)?(?:\s+execution plan| package)?/i);
  const additionalNotes = readField(prompt, "Additional Notes") || readField(prompt, "Notes");
  const deliverables = collectMatches(prompt, deliverableMap, "discipline") as DisciplineName[];
  const scopeGroupIds = collectMatches(prompt, scopeMap, "groupId");
  const parsedArea = parseArea(prompt);
  const parsedTimeline = parseTimelineDays(prompt);
  const selectedPlan = parseSelectedPlan(prompt);

  return {
    clientName: normalizeClientName(clientName),
    projectName: cleanExtractedValue(projectName),
    areaSqFt: parsedArea > 0 ? parsedArea : (defaults?.areaSqFt ?? 0),
    location: titleCaseWords(location),
    deliverables,
    scopeGroupIds,
    executionPlan: executionPlan || "Premium Turnkey Package",
    selectedPlan,
    timelineDays: parsedTimeline > 0 ? parsedTimeline : (defaults?.timelineDays ?? 150),
    notes: additionalNotes || "AI-generated proposal draft prepared for review and inline editing.",
    includeLandscape: /landscape/i.test(prompt) ? true : null,
    summary: "",
  };
}

export function withDraftSummary(draft: AIProposalDraft): AIProposalDraft {
  return {
    ...draft,
    summary: buildDraftSummary(draft),
  };
}

export function buildGeneratedDraftVersionFromDraft(baseProject: ProjectRecord, draft: AIProposalDraft): ProposalVersion {
  const parsed = withDraftSummary(draft);
  const areaSqFt = parsed.areaSqFt > 0 ? parsed.areaSqFt : 5000;
  const hasWorkscope = parsed.scopeGroupIds.length > 0;
  const hasExecutionEstimate = parsed.timelineDays > 0;
  const deliverables: DisciplineName[] = parsed.deliverables;
  const consultancySection = {
    disciplines: deliverables.map((discipline) => ({
      ...createConsultancyDiscipline(discipline, areaSqFt),
      isLocked: false,
    })),
    servicesSubtotal: 0,
    sstTaxRate: 15,
    sstTaxAmount: 0,
    servicesTotalWithTax: 0,
  };
  const scopeSection = {
    ...createScopeSection(areaSqFt, parsed.scopeGroupIds),
    lockedGroupIds: [],
    exclusionsTitle: "Negative List",
    optimalExclusions: defaultNegativeList(parsed.executionPlan),
    bufferedExclusions: [
      "Customized lighting",
      "Premium imported finishes",
      "Smart automation scope",
    ].join("\n"),
    note: parsed.notes,
  };
  const baseExecutionSection = hasWorkscope ? createExecutionSection() : createBlankExecutionSection();
  const executionSection = hasExecutionEstimate
    ? {
        ...baseExecutionSection,
        isLocked: false,
        selectedPlan: hasWorkscope ? parsed.selectedPlan : null,
        totalProjectDurationDays: parsed.timelineDays,
        timelineRows: createDistributedTimelineRows(parsed.timelineDays, baseProject.proposalDate).map((row, index) => ({
          ...row,
          remarks: index === 0 ? parsed.executionPlan : row.remarks,
        })),
        budgetPlans: hasWorkscope
          ? baseExecutionSection.budgetPlans.map((plan, index) => ({
              ...plan,
              title: index === 0 ? "Budget Plan A" : "Budget Plan B",
              optionLabel: index === 0 ? "Standard Option" : parsed.executionPlan,
            }))
          : [],
      }
    : createBlankExecutionSection();

  return {
    ...baseProject.draftVersion,
    previewSections: {
      ...createDefaultProposalSectionVisibility(),
      consultancyFee: true,
      workScope: true,
      negativeList: true,
      optimalList: true,
      bufferedOptimalList: true,
      executionEstimate: true,
      timeline: true,
      budgetComparison: true,
    },
    workspaceSections: createDefaultWorkspaceSections(),
    consultancySection,
    scopeSection,
    executionSection,
    paymentSchedule: createEmptyPaymentSchedule(),
  };
}

export function buildGeneratedDraftVersion(baseProject: ProjectRecord, prompt: string): ProposalVersion {
  return buildGeneratedDraftVersionFromDraft(baseProject, parseProposalPrompt(prompt));
}
