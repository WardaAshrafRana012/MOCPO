import { addDays, differenceInCalendarDays, formatISO } from "date-fns";

import type {
  ConsultancyDiscipline,
  ConsultancySection,
  ConsultancyTotals,
  ExecutionPlan,
  ExecutionSection,
  ProjectRecord,
  ProposalVersion,
  PaymentSchedule,
  ScopeCategory,
  ScopeSection,
  ScopeTotals,
  TimelineRow,
  TimelineTotals,
} from "@/lib/types";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";

export const CONSULTANCY_SST_RATE = 15;
export const WORKSCOPE_GST_RATE = 18;

export function calculateConsultancyRowTotal(rate: number, area: number, multiplier = 1) {
  return roundCurrency(rate * area * multiplier);
}

export function calculateConsultancyDisciplineTotal(rows: ConsultancyDiscipline["rows"], multiplier = 1) {
  return roundCurrency(rows.reduce((sum, row) => sum + calculateConsultancyRowTotal(row.rate, row.area, multiplier), 0));
}

export function calculateConsultancyTotals(
  section: ConsultancySection,
  _taxRate: number,
  _discountRate: number,
  projectDurationMonths = 1,
): ConsultancyTotals {
  const servicesSubtotal = roundCurrency(
    section.disciplines.reduce(
      (sum, discipline) =>
        sum + calculateConsultancyDisciplineTotal(discipline.rows, discipline.usesProjectDuration ? projectDurationMonths : 1),
      0,
    ),
  );
  const deliverableCount = section.disciplines.reduce((sum, discipline) => sum + discipline.rows.length, 0);
  const sstRate = Number.isFinite(section.sstTaxRate) ? Number(section.sstTaxRate) : CONSULTANCY_SST_RATE;
  const sstAmount = servicesSubtotal > 0 ? roundCurrency(servicesSubtotal * (sstRate / 100)) : 0;
  const servicesTotalWithTax = servicesSubtotal > 0 ? roundCurrency(servicesSubtotal + sstAmount) : 0;

  return {
    deliverableCount,
    sstRate,
    servicesSubtotal,
    sstAmount,
    servicesTotalWithTax,
    subtotal: servicesSubtotal,
    taxAmount: sstAmount,
    discountAmount: 0,
    grandTotal: servicesTotalWithTax,
  };
}

export function calculateScopeCategoryTotals(category: ScopeCategory) {
  const optimal = roundCurrency(category.rows.reduce((sum, row) => sum + row.quantity * row.optimalRate, 0));
  const buffered = roundCurrency(category.rows.reduce((sum, row) => sum + row.quantity * row.bufferedRate, 0));

  return { optimal, buffered };
}

export function calculateScopeTotals(section: ScopeSection): ScopeTotals {
  const perCategoryMap = new Map<string, ScopeTotals["perCategory"][number]>();

  for (const row of getScopeRowsForTotals(section.rows)) {
    if (!row.groupId || !row.groupName) continue;

    const current = perCategoryMap.get(row.groupId) ?? {
      categoryId: row.groupId,
      categoryName: row.groupName,
      optimal: 0,
      buffered: 0,
    };

    current.optimal = roundCurrency(current.optimal + (row.leftAmount ?? 0));
    current.buffered = roundCurrency(current.buffered + (row.rightAmount ?? 0));
    perCategoryMap.set(row.groupId, current);
  }

  const perCategory = Array.from(perCategoryMap.values());
  const gstRate = Number.isFinite(section.gstTaxRate) ? Number(section.gstTaxRate) : WORKSCOPE_GST_RATE;
  const optimalSubtotal = roundCurrency(perCategory.reduce((sum, category) => sum + category.optimal, 0));
  const bufferedSubtotal = roundCurrency(perCategory.reduce((sum, category) => sum + category.buffered, 0));
  const optimalGstAmount = optimalSubtotal > 0 ? roundCurrency(optimalSubtotal * (gstRate / 100)) : 0;
  const bufferedGstAmount = bufferedSubtotal > 0 ? roundCurrency(bufferedSubtotal * (gstRate / 100)) : 0;
  const optimalGrandTotal = optimalSubtotal > 0 ? roundCurrency(optimalSubtotal + optimalGstAmount) : 0;
  const bufferedGrandTotal = bufferedSubtotal > 0 ? roundCurrency(bufferedSubtotal + bufferedGstAmount) : 0;
  const selectedTotal =
    section.planMode === "buffered"
      ? bufferedGrandTotal
      : section.planMode === "compare"
        ? optimalGrandTotal
        : optimalGrandTotal;
  const differenceAmount = roundCurrency(bufferedGrandTotal - optimalGrandTotal);
  const differencePercentage = optimalGrandTotal > 0 ? Number(((differenceAmount / optimalGrandTotal) * 100).toFixed(2)) : 0;

  return {
    perCategory,
    gstRate,
    planANetTotal: optimalSubtotal,
    planATaxAmount: optimalGstAmount,
    planATotalWithTax: optimalGrandTotal,
    planBNetTotal: bufferedSubtotal,
    planBTaxAmount: bufferedGstAmount,
    planBTotalWithTax: bufferedGrandTotal,
    optimalSubtotal,
    bufferedSubtotal,
    optimalGstAmount,
    bufferedGstAmount,
    optimalGrandTotal,
    bufferedGrandTotal,
    optimalTotal: optimalGrandTotal,
    bufferedTotal: bufferedGrandTotal,
    selectedTotal,
    differenceAmount,
    differencePercentage,
  };
}

export function getSelectedExecutionCost(execution: ExecutionSection, selectedPlan?: ExecutionPlan) {
  const { budgetATotal, budgetBTotal } = getExecutionBudgetTotals(execution);
  const plan = selectedPlan ?? execution.selectedPlan;

  if (!plan) return 0;
  if (plan === "both") return roundCurrency(budgetATotal + budgetBTotal);
  if (plan === "buffered") return budgetBTotal;
  return budgetATotal;
}

export function getExecutionBudgetTotals(execution: ExecutionSection) {
  const budgetPlans = execution.budgetPlans ?? [];
  const budgetA = budgetPlans.find((item) => item.key === "budget-a");
  const budgetB = budgetPlans.find((item) => item.key === "budget-b");
  const hasActiveRows = (plan?: NonNullable<typeof budgetA>) =>
    plan?.rows.some((row) => row.quantity > 0 || row.rate > 0 || row.totalAmount > 0) ?? false;

  const budgetATotal = roundCurrency(
    hasActiveRows(budgetA)
      ? budgetA?.rows.reduce((sum, row) => sum + roundCurrency(row.quantity * row.rate), 0) ?? 0
      : execution.importedOptimalCost,
  );
  const budgetBTotal = roundCurrency(
    hasActiveRows(budgetB)
      ? budgetB?.rows.reduce((sum, row) => sum + roundCurrency(row.quantity * row.rate), 0) ?? 0
      : execution.importedBufferedCost,
  );

  return {
    budgetA,
    budgetB,
    budgetATotal,
    budgetBTotal,
  };
}

export function getExecutionPlanLabel(selectedPlan: ExecutionPlan) {
  if (!selectedPlan) return "Not selected";
  if (selectedPlan === "both") return "Plan A and Plan B";
  if (selectedPlan === "buffered") return "Budget Plan B";
  return "Budget Plan A";
}

export function getTimelinePlanLabel(selectedPlan: ExecutionPlan) {
  if (selectedPlan === "optimal") return "Tentative Timeline (Plan A)";
  if (selectedPlan === "buffered") return "Tentative Timeline (Plan B)";
  if (selectedPlan === "both") return "Tentative Timeline (Plan A and Plan B)";
  return null;
}

export function calculateTimelineEndDate(startDate: string, days: number) {
  if (!startDate) return "";
  return formatISO(addDays(new Date(startDate), days), { representation: "date" });
}

export function calculateTimelineTotals(rows: TimelineRow[]): TimelineTotals {
  const totalDays = rows.reduce((sum, row) => sum + (Number.isFinite(row.days) ? row.days : 0), 0);

  return {
    totalDays,
    totalMonths: Number((totalDays / 30).toFixed(1)),
  };
}

export function calculateFinalEstimate(execution: ExecutionSection) {
  return roundCurrency(getSelectedExecutionCost(execution) + execution.importedConsultancyFee);
}

export function calculateProposalGrandTotal(project: ProjectRecord, version: ProposalVersion) {
  const consultancyVisible = version.previewSections.consultancyFee;
  const scopeVisible =
    version.previewSections.workScope ||
    version.previewSections.negativeList ||
    version.previewSections.optimalList ||
    version.previewSections.bufferedOptimalList;
  const executionVisible =
    version.previewSections.executionEstimate ||
    version.previewSections.timeline ||
    version.previewSections.budgetComparison;

  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);

  let total = 0;

  if (consultancyVisible) {
    total += consultancyTotals.grandTotal;
  }

  if (scopeVisible) {
    if (version.executionSection.selectedPlan === "buffered") {
      total += scopeTotals.planBTotalWithTax;
    } else if (version.executionSection.selectedPlan === "both") {
      total += scopeTotals.planATotalWithTax + scopeTotals.planBTotalWithTax;
    } else {
      total += scopeTotals.planATotalWithTax;
    }
  }

  if (executionVisible) {
    total += getSelectedExecutionCost(version.executionSection);
  }

  return roundCurrency(total);
}

export function calculatePaymentScheduleSummary(paymentSchedule: PaymentSchedule) {
  const allocatedPercentage = roundCurrency(
    paymentSchedule.rows.reduce((sum, row) => sum + (Number.isFinite(row.percentage) ? row.percentage : 0), 0),
  );
  const totalAmount = roundCurrency(
    paymentSchedule.rows.reduce((sum, row) => sum + (Number.isFinite(row.amount) ? row.amount : 0), 0),
  );

  return {
    allocatedPercentage,
    remainingPercentage: roundCurrency(100 - allocatedPercentage),
    totalAmount,
    isBalanced: Math.abs(allocatedPercentage - 100) < 0.01 && Math.abs(totalAmount - paymentSchedule.grandTotal) < 1,
  };
}

export function getProposalWarnings(project: ProjectRecord, version: ProposalVersion) {
  const warnings: string[] = [];
  const scopeEnabled =
    version.previewSections.workScope ||
    version.previewSections.negativeList ||
    version.previewSections.optimalList ||
    version.previewSections.bufferedOptimalList;
  const executionEnabled =
    version.previewSections.executionEstimate ||
    version.previewSections.timeline ||
    version.previewSections.budgetComparison;
  const executionUsesWorkscope = scopeEnabled && version.executionSection.budgetPlans.length > 0;
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);

  if (!project.projectName || !project.clientName || !project.location || project.areaSqFt <= 0) {
    warnings.push("Complete the shared project profile fields.");
  }

  if (consultancyTotals.subtotal <= 0) {
    warnings.push("Consultancy fee missing.");
  }

  if (scopeEnabled && (version.scopeSection.rows.length === 0 || scopeTotals.optimalTotal <= 0)) {
    warnings.push("Scope breakup incomplete.");
  }

  if (executionUsesWorkscope && !version.executionSection.selectedPlan) {
    warnings.push("No plan selected.");
  }

  if (executionEnabled && !version.executionSection.isLocked) {
    warnings.push("Estimate not locked.");
  }

  if (
    executionEnabled &&
    (timelineTotals.totalDays <= 0 || version.executionSection.timelineRows.some((row) => !row.startDate))
  ) {
    warnings.push("Timeline incomplete.");
  }

  if (
    executionEnabled &&
    version.executionSection.totalProjectDurationDays > 0 &&
    timelineTotals.totalDays !== version.executionSection.totalProjectDurationDays
  ) {
    warnings.push("Timeline days do not match total project duration.");
  }

  return warnings;
}

export function createFileName(projectName: string, versionLabel: string, extension: "pdf" | "xlsx" | "proposal.json") {
  const safeName = projectName.trim().replace(/[^a-zA-Z0-9-_]+/g, "_") || "Project";
  return `${safeName}_Proposal_${versionLabel}.${extension}`;
}

export function getVersionNumber(versionLabel: string) {
  const numeric = Number(versionLabel.replace(/[^0-9]/g, ""));
  return Number.isFinite(numeric) && numeric > 0 ? numeric : 1;
}

export function getNextVersionLabel(savedVersions: ProposalVersion[]) {
  const max = savedVersions.reduce((highest, version) => Math.max(highest, getVersionNumber(version.versionLabel)), 0);
  return `V${max + 1}`;
}

export function getProposalProgress(project: ProjectRecord, version: ProposalVersion) {
  const checkpoints = [
    Boolean(project.projectName),
    Boolean(project.clientName),
    project.areaSqFt > 0,
    version.consultancySection.disciplines.length > 0,
    version.scopeSection.rows.length > 0,
    version.executionSection.timelineRows.length > 0,
    version.executionSection.isLocked,
    project.savedVersions.length > 0,
  ];

  const complete = checkpoints.filter(Boolean).length;
  return {
    complete,
    total: checkpoints.length,
    percentage: Math.round((complete / checkpoints.length) * 100),
  };
}

export function getVersionDeltaDays(fromDate?: string | null, toDate?: string | null) {
  if (!fromDate || !toDate) return 0;
  return differenceInCalendarDays(new Date(toDate), new Date(fromDate));
}

export function roundCurrency(value: number) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}
