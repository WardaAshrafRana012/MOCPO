export type DisciplineName =
  | "Architecture"
  | "Interior"
  | "MEP Design"
  | "Structure"
  | "Facade Engineering"
  | "Landscaping"
  | "Top Supervision"
  | "Resident Engineering & Supervision Team";

export type ProposalStatus = "draft" | "saved" | "final";
export type ScopePlanMode = "optimal" | "buffered" | "compare";
export type ExecutionPlan = "optimal" | "buffered" | "both" | null;
export type DownloadKind = "pdf" | "xlsx" | "json";
export type PreviewSectionKey = "consultancy" | "scope" | "execution";
export type ProposalSectionKey =
  | "consultancyFee"
  | "workScope"
  | "negativeList"
  | "optimalList"
  | "bufferedOptimalList"
  | "executionEstimate"
  | "timeline"
  | "budgetComparison"
  | "paymentSchedule";
export type ProposalSectionVisibility = Record<ProposalSectionKey, boolean>;
export type AIConversationStatus = "idle" | "collecting" | "ready";
export type AIMessageRole = "assistant" | "user";
export type AIRequirementKey =
  | "clientName"
  | "projectName"
  | "areaSqFt"
  | "location"
  | "deliverables"
  | "scopeGroupIds"
  | "executionPlan"
  | "selectedPlan"
  | "timelineDays";

export interface ProposalWorkspaceSectionState {
  hidden: boolean;
  locked: boolean;
  deleted: boolean;
  order: number;
}

export type ProposalWorkspaceSections = Record<ProposalSectionKey, ProposalWorkspaceSectionState>;

export interface AIChatMessage {
  id: string;
  role: AIMessageRole;
  content: string;
  createdAt: string;
  quickReplies?: string[];
}

export interface AIProposalDraft {
  clientName: string;
  projectName: string;
  areaSqFt: number;
  location: string;
  deliverables: DisciplineName[];
  scopeGroupIds: string[];
  executionPlan: string;
  selectedPlan: ExecutionPlan;
  timelineDays: number;
  notes: string;
  includeLandscape: boolean | null;
  summary: string;
}

export interface AIConversationState {
  messages: AIChatMessage[];
  combinedPrompt: string;
  draft: AIProposalDraft;
  missingFields: AIRequirementKey[];
  readyToGenerate: boolean;
  status: AIConversationStatus;
  lastGeneratedAt?: string | null;
}

export interface ConsultancyRow {
  id: string;
  phaseLabel: string;
  deliverable: string;
  rate: number;
  area: number;
  totalCost: number;
}

export interface ConsultancyDiscipline {
  name: DisciplineName;
  rows: ConsultancyRow[];
  isLocked: boolean;
  estimatedAmount: number;
  rateLabel: string;
  inputLabel: string;
  usesProjectDuration: boolean;
  notes?: string[];
}

export interface ConsultancySection {
  disciplines: ConsultancyDiscipline[];
  servicesSubtotal: number;
  sstTaxRate: number;
  sstTaxAmount: number;
  servicesTotalWithTax: number;
}

export interface ScopeItem {
  id: string;
  itemDescription: string;
  unit: string;
  quantity: number;
  optimalRate: number;
  optimalAmount: number;
  bufferedRate: number;
  bufferedAmount: number;
  remarks: string;
}

export interface ScopeCategory {
  id: string;
  name: string;
  rows: ScopeItem[];
  isLocked: boolean;
  isStandard: boolean;
}

export interface ScopeSheetRow {
  id: string;
  kind: "groupHeader" | "line" | "spacer";
  groupId?: string | null;
  groupName?: string | null;
  leftSerial: string;
  leftScope: string;
  leftSft: number | null;
  leftRate: number | null;
  leftAmount: number | null;
  leftValueRowSpan?: number | null;
  rightSerial: string;
  rightScope: string;
  rightSft: number | null;
  rightRate: number | null;
  rightAmount: number | null;
  rightValueRowSpan?: number | null;
}

export interface ScopeSection {
  sheetTitle: string;
  optimalLabel: string;
  bufferedLabel: string;
  rows: ScopeSheetRow[];
  lockedGroupIds: string[];
  planMode: ScopePlanMode;
  totalLabel: string;
  exclusionsTitle: string;
  optimalExclusions: string;
  bufferedExclusions: string;
  note: string;
  gstTaxRate: number;
  planANetTotal: number;
  planATaxAmount: number;
  planATotalWithTax: number;
  planBNetTotal: number;
  planBTaxAmount: number;
  planBTotalWithTax: number;
}

export interface TimelineRow {
  id: string;
  activity: string;
  days: number;
  startDate: string;
  endDate: string;
  remarks: string;
}

export interface ExecutionBudgetRow {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  totalAmount: number;
  remarks: string;
}

export interface ExecutionBudgetPlan {
  id: string;
  key: "budget-a" | "budget-b" | "custom";
  title: string;
  optionLabel: string;
  rows: ExecutionBudgetRow[];
}

export interface ExecutionSection {
  importedConsultancyFee: number;
  importedOptimalCost: number;
  importedBufferedCost: number;
  selectedPlan: ExecutionPlan;
  totalProjectDurationDays: number;
  timelineRows: TimelineRow[];
  budgetPlans: ExecutionBudgetPlan[];
  isLocked: boolean;
  importedAt?: string | null;
}

export interface PaymentInstallment {
  id: string;
  name: string;
  percentage: number;
  amount: number;
  dueDate: string;
  description: string;
}

export interface PaymentSchedule {
  enabled: boolean;
  grandTotal: number;
  rows: PaymentInstallment[];
  notes: string;
  updatedAt?: string | null;
}

export interface ProposalVersion {
  id: string;
  versionLabel: string;
  createdAt: string;
  savedAt?: string | null;
  savedBy?: string | null;
  basedOnVersionId?: string | null;
  isDraft: boolean;
  previewSections: ProposalSectionVisibility;
  workspaceSections: ProposalWorkspaceSections;
  consultancySection: ConsultancySection;
  scopeSection: ScopeSection;
  executionSection: ExecutionSection;
  paymentSchedule: PaymentSchedule;
}

export interface DownloadArtifact {
  id: string;
  kind: DownloadKind;
  versionLabel: string;
  filename: string;
  createdAt: string;
}

export interface BrandProfile {
  companyName: string;
  logoUrl: string;
  preparedBy: string;
  signatureName: string;
  signatureTitle: string;
  footerText: string;
}

export interface ProjectRecord {
  projectId: string;
  projectName: string;
  clientName: string;
  clientFolderName: string;
  areaSqFt: number;
  location: string;
  projectDurationMonths: number;
  proposalDate: string;
  proposalStatus: ProposalStatus;
  currentDraftVersionId: string;
  activeVersionId: string;
  draftVersion: ProposalVersion;
  savedVersions: ProposalVersion[];
  versions: ProposalVersion[];
  downloads: DownloadArtifact[];
  taxRate: number;
  discountRate: number;
  notes: string;
  lastEditedAt: string;
  brandProfile: BrandProfile;
  aiConversation: AIConversationState;
}

export interface ScopeTotals {
  perCategory: { categoryId: string; categoryName: string; optimal: number; buffered: number }[];
  gstRate: number;
  planANetTotal: number;
  planATaxAmount: number;
  planATotalWithTax: number;
  planBNetTotal: number;
  planBTaxAmount: number;
  planBTotalWithTax: number;
  optimalSubtotal: number;
  bufferedSubtotal: number;
  optimalGstAmount: number;
  bufferedGstAmount: number;
  optimalGrandTotal: number;
  bufferedGrandTotal: number;
  optimalTotal: number;
  bufferedTotal: number;
  selectedTotal: number;
  differenceAmount: number;
  differencePercentage: number;
}

export interface ConsultancyTotals {
  deliverableCount: number;
  sstRate: number;
  servicesSubtotal: number;
  sstAmount: number;
  servicesTotalWithTax: number;
  subtotal: number;
  taxAmount: number;
  discountAmount: number;
  grandTotal: number;
}

export interface TimelineTotals {
  totalDays: number;
  totalMonths: number;
}

export interface ProposalSummaryPayload {
  project: ProjectRecord;
  version: ProposalVersion;
}
