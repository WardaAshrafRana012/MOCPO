export const GOOGLE_SHEET_ID = "198ZsPuPHT0nMc-3QweTQ8MrZHqjjDdK_iiYQmlSFAc8";

export const PO_TABS = {
  main: "PO_Main",
  items: "PO_Items",
  settings: "Settings",
  activity: "Activity_Logs",
};

export type POStatus = "Draft" | "Generated" | "Archived";

export interface POItem {
  id: string;
  description: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  amount: number;
}

export interface PurchaseOrder {
  id: string;
  vendorName: string;
  poNumber: string;
  poDate: string;
  deliveryDate: string;
  reference: string;
  items: POItem[];
  totalAmount: number;
  amountWords: string;
  deliveryAddress: string;
  preparedBy: string;
  telephone: string;
  deliveryInstructions: string;
  itemCategory: string;
  status: POStatus;
  archived: boolean;
  pdfGeneratedAt: string | null;
  pdfLink: string;
  driveFileId: string;
  createdAt: string;
  updatedAt: string;
}

export interface POSettings {
  companyName: string;
  address: string;
  ntn: string;
  strn: string;
  footer: string;
  spreadsheetId: string;
  poMainTab: string;
  poItemsTab: string;
  settingsTab: string;
  activityTab: string;
  driveFolderId: string;
  prefix: string;
  autoGenerate: boolean;
  deliveryDateRequired: boolean;
  archiveInsteadOfDelete: boolean;
  theme: "Light" | "System";
  accent: string;
  glassIntensity: number;
  logoUrl: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  poNumber: string;
  detail: string;
  createdAt: string;
}

export interface IntegrationStatus {
  ok: boolean;
  message: string;
  checkedAt: string | null;
}

export function createId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}-${Date.now().toString(36)}`;
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function formatPKR(value: number) {
  return new Intl.NumberFormat("en-PK", {
    maximumFractionDigits: 0,
  }).format(Math.round(value || 0));
}

export function formatDate(value: string) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

const smallNumbers = [
  "Zero",
  "One",
  "Two",
  "Three",
  "Four",
  "Five",
  "Six",
  "Seven",
  "Eight",
  "Nine",
  "Ten",
  "Eleven",
  "Twelve",
  "Thirteen",
  "Fourteen",
  "Fifteen",
  "Sixteen",
  "Seventeen",
  "Eighteen",
  "Nineteen",
];

const tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

function wordsBelowThousand(value: number): string {
  const parts: string[] = [];
  const hundred = Math.floor(value / 100);
  const rest = value % 100;
  if (hundred) parts.push(`${smallNumbers[hundred]} Hundred`);
  if (rest < 20 && rest > 0) parts.push(smallNumbers[rest]);
  if (rest >= 20) {
    const ten = Math.floor(rest / 10);
    const unit = rest % 10;
    parts.push(unit ? `${tens[ten]} ${smallNumbers[unit]}` : tens[ten]);
  }
  return parts.join(" ");
}

export function amountToWords(value: number) {
  const rounded = Math.round(value || 0);
  if (rounded === 0) return "ZERO RUPEES ONLY";
  const chunks = [
    { label: "Million", value: Math.floor(rounded / 1_000_000) },
    { label: "Thousand", value: Math.floor((rounded % 1_000_000) / 1_000) },
    { label: "", value: rounded % 1_000 },
  ];
  return `${chunks
    .filter((chunk) => chunk.value > 0)
    .map((chunk) => `${wordsBelowThousand(chunk.value)} ${chunk.label}`.trim())
    .join(" ")} Rupees Only`.toUpperCase();
}

export function vendorInitials(vendorName: string) {
  const clean = vendorName.replace(/[^a-zA-Z0-9\s]/g, " ").trim();
  const words = clean.split(/\s+/).filter(Boolean);
  if (words.length === 0) return "PO";
  const initials = words.map((word) => word[0]).join("").slice(0, 3).toUpperCase();
  return initials.padEnd(3, initials.at(-1) || "X");
}

export function nextPONumber(vendorName: string, existing: Pick<PurchaseOrder, "poNumber">[], prefix = "PO") {
  const highest = existing.reduce((max, po) => {
    const match = po.poNumber.match(/^PO-(\d{4})-/);
    return match ? Math.max(max, Number(match[1])) : max;
  }, 0);
  return `${prefix}-${String(highest + 1).padStart(4, "0")}-${vendorInitials(vendorName)}`;
}

export function normalizeItems(items: POItem[]) {
  return items.map((item) => ({
    ...item,
    quantity: Number(item.quantity) || 0,
    unitPrice: Number(item.unitPrice) || 0,
    amount: (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0),
  }));
}

export function recalculatePO(po: PurchaseOrder) {
  const items = normalizeItems(po.items);
  const totalAmount = items.reduce((sum, item) => sum + item.amount, 0);
  return {
    ...po,
    items,
    totalAmount,
    amountWords: amountToWords(totalAmount),
    updatedAt: new Date().toISOString(),
  };
}

export const defaultSettings: POSettings = {
  companyName: "MOLECULE",
  address: "MOLECULE 47-B, MAIN KH-E-SHAMSHEER, DHA-5, KARACHI",
  ntn: "8660135-2",
  strn: "32-77-8762-10932",
  footer: "Generated by Molecule Work Place Solution.",
  spreadsheetId: GOOGLE_SHEET_ID,
  poMainTab: PO_TABS.main,
  poItemsTab: PO_TABS.items,
  settingsTab: PO_TABS.settings,
  activityTab: PO_TABS.activity,
  driveFolderId: "",
  prefix: "PO",
  autoGenerate: true,
  deliveryDateRequired: false,
  archiveInsteadOfDelete: true,
  theme: "Light",
  accent: "#F59E0B",
  glassIntensity: 60,
  logoUrl: "/brand/molecule-workplace-solution.jpeg",
};

export function createBlankPO(existing: PurchaseOrder[] = [], vendorName = ""): PurchaseOrder {
  const now = new Date().toISOString();
  return recalculatePO({
    id: createId("po"),
    vendorName,
    poNumber: nextPONumber(vendorName || "New Vendor", existing),
    poDate: todayISO(),
    deliveryDate: "",
    reference: "",
    items: [{ id: createId("item"), description: "", quantity: 1, unit: "set", unitPrice: 0, amount: 0 }],
    totalAmount: 0,
    amountWords: amountToWords(0),
    deliveryAddress: defaultSettings.address,
    preparedBy: "",
    telephone: "",
    deliveryInstructions: "",
    itemCategory: "",
    status: "Draft",
    archived: false,
    pdfGeneratedAt: null,
    pdfLink: "",
    driveFileId: "",
    createdAt: now,
    updatedAt: now,
  });
}

export function validatePO(po: PurchaseOrder) {
  const errors: string[] = [];
  if (!po.vendorName.trim()) errors.push("Vendor Name is required.");
  if (!po.poDate) errors.push("PO Date is required.");
  if (!po.items.length) errors.push("At least one item is required.");
  if (po.items.some((item) => !item.description.trim())) errors.push("Every item needs a description.");
  if (!po.deliveryAddress.trim()) errors.push("Delivery Address is required.");
  if (!po.preparedBy.trim()) errors.push("Prepared By is required.");
  return errors;
}
