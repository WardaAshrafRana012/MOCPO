import type {
  ProjectRecord,
  ProposalSectionKey,
  ProposalSectionVisibility,
  ProposalVersion,
  ProposalWorkspaceSectionState,
  ProposalWorkspaceSections,
} from "@/lib/types";
import { calculateScopeTotals, calculateTimelineTotals } from "@/lib/calculations";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";

export const proposalSectionOrder = [
  "consultancyFee",
  "workScope",
  "negativeList",
  "optimalList",
  "bufferedOptimalList",
  "executionEstimate",
  "timeline",
  "budgetComparison",
  "paymentSchedule",
] as const;

export const proposalSectionMeta: Record<
  ProposalSectionKey,
  {
    label: string;
    module: "consultancy" | "scope" | "execution";
    route: string;
  }
> = {
  consultancyFee: {
    label: "Consultancy Fee",
    module: "consultancy",
    route: "/proposal-wizard?step=consultancy&returnTo=preview",
  },
  workScope: {
    label: "Work Scope",
    module: "scope",
    route: "/proposal-wizard?step=scope&returnTo=preview",
  },
  negativeList: {
    label: "Negative List",
    module: "scope",
    route: "/proposal-wizard?step=scope&returnTo=preview",
  },
  optimalList: {
    label: "Optimal List",
    module: "scope",
    route: "/proposal-wizard?step=scope&returnTo=preview",
  },
  bufferedOptimalList: {
    label: "Buffered Optimal List",
    module: "scope",
    route: "/proposal-wizard?step=scope&returnTo=preview",
  },
  executionEstimate: {
    label: "Execution Estimate",
    module: "execution",
    route: "/proposal-wizard?step=execution&returnTo=preview",
  },
  timeline: {
    label: "Timeline",
    module: "execution",
    route: "/proposal-wizard?step=execution&returnTo=preview",
  },
  budgetComparison: {
    label: "Budget Comparison",
    module: "execution",
    route: "/proposal-wizard?step=execution&returnTo=preview",
  },
  paymentSchedule: {
    label: "Payment Schedule",
    module: "execution",
    route: "/edit-proposal",
  },
};

export function createDefaultProposalSectionVisibility(): ProposalSectionVisibility {
  return {
    consultancyFee: false,
    workScope: false,
    negativeList: false,
    optimalList: false,
    bufferedOptimalList: false,
    executionEstimate: false,
    timeline: false,
    budgetComparison: false,
    paymentSchedule: false,
  };
}

export function createDefaultWorkspaceSections(): ProposalWorkspaceSections {
  return proposalSectionOrder.reduce((acc, key, index) => {
    acc[key] = {
      hidden: false,
      locked: false,
      deleted: false,
      order: index,
    };
    return acc;
  }, {} as ProposalWorkspaceSections);
}

function getMigratedWorkspaceSection(
  workspaceSections: Record<string, Partial<ProposalWorkspaceSectionState>> | null | undefined,
  key: ProposalSectionKey,
  visible: boolean,
  index: number,
): ProposalWorkspaceSectionState {
  const next = workspaceSections?.[key];

  return {
    hidden: next?.hidden ?? !visible,
    locked: next?.locked ?? false,
    deleted: next?.deleted ?? false,
    order: typeof next?.order === "number" ? next.order : index,
  };
}

export function migrateWorkspaceSections(
  workspaceSections: Record<string, Partial<ProposalWorkspaceSectionState>> | null | undefined,
  previewSections?: Record<string, boolean> | null,
): ProposalWorkspaceSections {
  const visibleSections = migrateProposalSectionVisibility(previewSections);

  return proposalSectionOrder.reduce((acc, key, index) => {
    acc[key] = getMigratedWorkspaceSection(workspaceSections, key, visibleSections[key], index);
    return acc;
  }, {} as ProposalWorkspaceSections);
}

export function syncPreviewSectionsFromWorkspaceSections(
  workspaceSections: ProposalWorkspaceSections,
  previewSections?: ProposalSectionVisibility | null,
) {
  return proposalSectionOrder.reduce((acc, key) => {
    const state = workspaceSections[key];
    acc[key] = !state.hidden && !state.deleted && (previewSections?.[key] ?? true);
    return acc;
  }, createDefaultProposalSectionVisibility());
}

export function getOrderedProposalSections(workspaceSections: ProposalWorkspaceSections) {
  return [...proposalSectionOrder].sort((left, right) => workspaceSections[left].order - workspaceSections[right].order);
}

export function getModuleProposalSections(module: "consultancy" | "scope" | "execution"): ProposalSectionKey[] {
  return proposalSectionOrder.filter((key) => proposalSectionMeta[key].module === module);
}

export function migrateProposalSectionVisibility(
  previewSections?: Record<string, boolean> | null,
  project?: ProjectRecord,
  version?: ProposalVersion,
): ProposalSectionVisibility {
  const defaults = createDefaultProposalSectionVisibility();

  if (!previewSections) {
    if (!project || !version) {
      return defaults;
    }

    return getAvailableProposalSections(project, version).reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, { ...defaults });
  }

  const next = { ...defaults };
  let hasGranularKey = false;

  for (const key of proposalSectionOrder) {
    if (key in previewSections) {
      next[key] = Boolean(previewSections[key]);
      hasGranularKey = true;
    }
  }

  if (hasGranularKey) {
    return next;
  }

  if (previewSections.consultancy) {
    next.consultancyFee = true;
  }

  if (previewSections.scope) {
    next.workScope = true;
    next.negativeList = true;
    next.optimalList = true;
    next.bufferedOptimalList = true;
  }

  if (previewSections.execution) {
    next.executionEstimate = true;
    next.timeline = true;
    next.budgetComparison = true;
  }

  if (previewSections.paymentSchedule) {
    next.paymentSchedule = true;
  }

  return next;
}

export function getAvailableProposalSections(project: ProjectRecord, version: ProposalVersion): ProposalSectionKey[] {
  const scopeRows = getScopeRowsForTotals(version.scopeSection.rows);
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const { budgetPlans } = version.executionSection;

  return proposalSectionOrder.filter((key) => {
    switch (key) {
      case "consultancyFee":
        return version.consultancySection.disciplines.length > 0;
      case "workScope":
        return scopeRows.length > 0 || scopeTotals.optimalTotal > 0 || scopeTotals.bufferedTotal > 0;
      case "negativeList":
        return version.scopeSection.note.trim().length > 0;
      case "optimalList":
        return version.scopeSection.optimalExclusions.trim().length > 0;
      case "bufferedOptimalList":
        return version.scopeSection.bufferedExclusions.trim().length > 0;
      case "executionEstimate":
        return budgetPlans.length > 0 || version.executionSection.selectedPlan !== null;
      case "timeline":
        return timelineTotals.totalDays > 0 || version.executionSection.timelineRows.length > 0;
      case "budgetComparison":
        return budgetPlans.some((plan) => plan.key === "budget-a") || budgetPlans.some((plan) => plan.key === "budget-b");
      case "paymentSchedule":
        return version.paymentSchedule.enabled && version.paymentSchedule.rows.length > 0;
      default:
        return false;
    }
  });
}

export function isProposalSectionRenderable(project: ProjectRecord, version: ProposalVersion, key: ProposalSectionKey) {
  const visibility = migrateProposalSectionVisibility(version.previewSections, project, version);
  return visibility[key] && getAvailableProposalSections(project, version).includes(key);
}
