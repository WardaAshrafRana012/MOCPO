import { createId } from "@/lib/utils";
import type { PaymentInstallment, PaymentSchedule } from "@/lib/types";

export function createDefaultPaymentInstallments(): PaymentInstallment[] {
  return [
    {
      id: createId("payment-installment"),
      name: "Advance Payment",
      percentage: 60,
      amount: 0,
      dueDate: "",
      description: "Initial mobilization and project kick-off.",
    },
    {
      id: createId("payment-installment"),
      name: "Final Payment",
      percentage: 40,
      amount: 0,
      dueDate: "",
      description: "Final submission and closing deliverables.",
    },
  ];
}

export function createEmptyPaymentSchedule(): PaymentSchedule {
  return {
    enabled: false,
    grandTotal: 0,
    rows: createDefaultPaymentInstallments(),
    notes: "",
    updatedAt: null,
  };
}

export function syncPaymentScheduleAmounts(paymentSchedule: PaymentSchedule, grandTotal: number): PaymentSchedule {
  return {
    ...paymentSchedule,
    grandTotal,
    rows: paymentSchedule.rows.map((row) => ({
      ...row,
      percentage: Number.isFinite(row.percentage) ? row.percentage : 0,
      amount: Math.round(((grandTotal * (Number.isFinite(row.percentage) ? row.percentage : 0)) / 100 + Number.EPSILON) * 100) / 100,
    })),
  };
}
