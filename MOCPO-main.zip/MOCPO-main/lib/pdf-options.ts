import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import type { ProjectRecord, ProposalVersion } from "@/lib/types";

export type PdfSectionKey =
  | "coverPage"
  | "tableOfContents"
  | "projectSummary"
  | "consultancyFee"
  | "workScopeBreakup"
  | "projectImages"
  | "executionEstimate"
  | "paymentSchedule"
  | "companyProfile"
  | "teamPage"
  | "termsAndConditions"
  | "signaturePage";

export type PdfCoverTemplate = "branded" | "classic" | "minimal";
export type PdfSummaryMode = "auto" | "manual" | "skip";
export type PdfImageLayout = "single" | "two-up" | "four-up" | "full-width";
export type PdfPageSize = "a4" | "letter";
export type PdfImageQuality = "high" | "medium" | "low";

export interface PdfWizardImageItem {
  id: string;
  name: string;
  dataUrl: string;
  caption: string;
}

export interface PdfCoverPageOptions {
  enabled: boolean;
  template: PdfCoverTemplate;
  imageDataUrl: string;
  projectTitle: string;
  clientName: string;
  proposalDate: string;
  preparedBy: string;
}

export interface PdfProjectSummaryOptions {
  enabled: boolean;
  mode: PdfSummaryMode;
  manualSummary: string;
}

export interface PdfProjectImagesOptions {
  enabled: boolean;
  layout: PdfImageLayout;
  items: PdfWizardImageItem[];
}

export interface PdfExtraPagesOptions {
  tableOfContents: boolean;
  companyProfile: boolean;
  teamPage: boolean;
  termsAndConditions: boolean;
  signaturePage: boolean;
}

export interface PdfSettingsOptions {
  pageSize: PdfPageSize;
  imageQuality: PdfImageQuality;
  showPageNumbers: boolean;
  showHeaderFooter: boolean;
  saveAsTemplate: boolean;
  templateName: string;
  selectedTemplateId: string;
}

export interface ProposalPdfOptions {
  coverPage: PdfCoverPageOptions;
  projectSummary: PdfProjectSummaryOptions;
  imagesPage: PdfProjectImagesOptions;
  extraPages: PdfExtraPagesOptions;
  sectionOrder: PdfSectionKey[];
  settings: PdfSettingsOptions;
}

export interface SavedPdfTemplate {
  id: string;
  name: string;
  updatedAt: string;
  options: ProposalPdfOptions;
}

export const PDF_TEMPLATE_STORAGE_KEY = "mocpo-pdf-templates";

export const PDF_SECTION_LABELS: Record<PdfSectionKey, string> = {
  coverPage: "Cover Page",
  tableOfContents: "Table of Contents",
  projectSummary: "Project Summary",
  consultancyFee: "Consultancy Fee",
  workScopeBreakup: "Work Scope Break-up",
  projectImages: "Project Images",
  executionEstimate: "Execution Estimate",
  paymentSchedule: "Payment Schedule",
  companyProfile: "Company Profile",
  teamPage: "Team Page",
  termsAndConditions: "Terms & Conditions",
  signaturePage: "Signature Page",
};

export const PDF_DEFAULT_SECTION_ORDER: PdfSectionKey[] = [
  "coverPage",
  "tableOfContents",
  "projectSummary",
  "consultancyFee",
  "workScopeBreakup",
  "projectImages",
  "executionEstimate",
  "paymentSchedule",
  "companyProfile",
  "teamPage",
  "termsAndConditions",
  "signaturePage",
];

export function createDefaultPdfOptions(project: ProjectRecord): ProposalPdfOptions {
  return {
    coverPage: {
      enabled: true,
      template: "branded",
      imageDataUrl: "",
      projectTitle: project.projectName || "Untitled Project",
      clientName: project.clientName || "",
      proposalDate: project.proposalDate || "",
      preparedBy: "Molecule Work Place Solution",
    },
    projectSummary: {
      enabled: true,
      mode: "auto",
      manualSummary: "",
    },
    imagesPage: {
      enabled: false,
      layout: "two-up",
      items: [],
    },
    extraPages: {
      tableOfContents: false,
      companyProfile: false,
      teamPage: false,
      termsAndConditions: false,
      signaturePage: false,
    },
    sectionOrder: [...PDF_DEFAULT_SECTION_ORDER],
    settings: {
      pageSize: "a4",
      imageQuality: "high",
      showPageNumbers: true,
      showHeaderFooter: true,
      saveAsTemplate: false,
      templateName: "",
      selectedTemplateId: "",
    },
  };
}

export function getSelectedPdfSections(project: ProjectRecord, version: ProposalVersion, options: ProposalPdfOptions) {
  const selected = new Set<PdfSectionKey>();

  if (options.coverPage.enabled) selected.add("coverPage");
  if (options.extraPages.tableOfContents) selected.add("tableOfContents");
  if (options.projectSummary.enabled && options.projectSummary.mode !== "skip") selected.add("projectSummary");
  if (isProposalSectionRenderable(project, version, "consultancyFee")) selected.add("consultancyFee");
  if (isProposalSectionRenderable(project, version, "workScope")) selected.add("workScopeBreakup");
  if (options.imagesPage.enabled && options.imagesPage.items.length > 0) selected.add("projectImages");

  const showExecution =
    isProposalSectionRenderable(project, version, "executionEstimate") ||
    isProposalSectionRenderable(project, version, "timeline") ||
    isProposalSectionRenderable(project, version, "budgetComparison");
  if (showExecution) selected.add("executionEstimate");
  if (isProposalSectionRenderable(project, version, "paymentSchedule")) selected.add("paymentSchedule");

  if (options.extraPages.companyProfile) selected.add("companyProfile");
  if (options.extraPages.teamPage) selected.add("teamPage");
  if (options.extraPages.termsAndConditions) selected.add("termsAndConditions");
  if (options.extraPages.signaturePage) selected.add("signaturePage");

  const ordered = options.sectionOrder.filter((key) => selected.has(key));
  for (const key of PDF_DEFAULT_SECTION_ORDER) {
    if (selected.has(key) && !ordered.includes(key)) {
      ordered.push(key);
    }
  }
  return ordered;
}

export function sanitizePdfTemplateOptions(options: ProposalPdfOptions): ProposalPdfOptions {
  return {
    ...options,
    coverPage: {
      ...options.coverPage,
      imageDataUrl: "",
    },
    imagesPage: {
      ...options.imagesPage,
      items: [],
    },
  };
}

export function applySavedPdfTemplate(
  template: SavedPdfTemplate,
  project: ProjectRecord,
): ProposalPdfOptions {
  const defaults = createDefaultPdfOptions(project);
  return {
    ...defaults,
    ...template.options,
    coverPage: {
      ...defaults.coverPage,
      ...template.options.coverPage,
      imageDataUrl: "",
      projectTitle: template.options.coverPage.projectTitle || defaults.coverPage.projectTitle,
      clientName: template.options.coverPage.clientName || defaults.coverPage.clientName,
      proposalDate: template.options.coverPage.proposalDate || defaults.coverPage.proposalDate,
      preparedBy: template.options.coverPage.preparedBy || defaults.coverPage.preparedBy,
    },
    imagesPage: {
      ...defaults.imagesPage,
      ...template.options.imagesPage,
      items: [],
    },
    settings: {
      ...defaults.settings,
      ...template.options.settings,
      selectedTemplateId: template.id,
      saveAsTemplate: false,
      templateName: template.name,
    },
    sectionOrder: template.options.sectionOrder?.length ? [...template.options.sectionOrder] : [...PDF_DEFAULT_SECTION_ORDER],
  };
}
