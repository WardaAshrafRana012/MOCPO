import { generateProviderReply } from "@/lib/mocpo-ai-agent";
import { parseProposalPrompt, withDraftSummary } from "@/lib/ai-proposal-builder";
import { standardDisciplineOrder } from "@/lib/seeds";
import { standardScopeGroupOptions } from "@/lib/scope-sheet";
import type {
  AIChatMessage,
  AIConversationState,
  AIProposalDraft,
  AIRequirementKey,
  DisciplineName,
} from "@/lib/types";
import { createId } from "@/lib/utils";

export interface ProposalChatRequest {
  messages: AIChatMessage[];
  combinedPrompt: string;
}

export interface ProposalChatResponse {
  assistantMessage: AIChatMessage;
  conversation: AIConversationState;
  draft: AIProposalDraft;
}

const deliverableChoices = standardDisciplineOrder.map((item, index) => `${index + 1}. ${item}`);
const scopeChoices = standardScopeGroupOptions.map((item, index) => `${index + 1}. ${item.name}`);
const executionPackageChoices = ["1. Basic", "2. Standard", "3. Premium"];
const selectedPlanChoices = ["1. Plan A and Plan B", "2. Budget Plan A", "3. Budget Plan B"];
const timelineChoices = ["90 days", "120 days", "150 days", "180 days"];
const stableInitialMessageCreatedAt = "2026-01-01T00:00:00.000Z";

const missingFieldOrder: AIRequirementKey[] = [
  "clientName",
  "projectName",
  "areaSqFt",
  "location",
  "deliverables",
  "scopeGroupIds",
  "executionPlan",
  "selectedPlan",
  "timelineDays",
];

const missingFieldQuestions: Record<AIRequirementKey, { message: string; quickReplies?: string[] }> = {
  clientName: {
    message: "Enter the client name.",
  },
  projectName: {
    message: "Enter the project name.",
  },
  areaSqFt: {
    message: "Enter the project area in square feet.",
    quickReplies: ["2,500", "5,000", "10,000"],
  },
  location: {
    message: "Enter the project location.",
  },
  deliverables: {
    message: `Consultancy Fee - Standard Deliverables\nChoose one or more options by number.\n${deliverableChoices.join("\n")}`,
    quickReplies: deliverableChoices,
  },
  scopeGroupIds: {
    message: `Work Scope Breakup\nChoose one or more scope groups by number.\n${scopeChoices.join("\n")}`,
    quickReplies: scopeChoices,
  },
  executionPlan: {
    message: `Execution Estimate Package\nChoose one option.\n${executionPackageChoices.join("\n")}`,
    quickReplies: executionPackageChoices,
  },
  selectedPlan: {
    message: `Selected Budget Plan For Final Estimate\nChoose one option.\n${selectedPlanChoices.join("\n")}`,
    quickReplies: selectedPlanChoices,
  },
  timelineDays: {
    message: "Choose the project timeline days.",
    quickReplies: timelineChoices,
  },
};

function createAssistantMessage(
  content: string,
  quickReplies?: string[],
  options: { id?: string; createdAt?: string } = {},
): AIChatMessage {
  return {
    id: options.id ?? createId("ai-message"),
    role: "assistant",
    content,
    createdAt: options.createdAt ?? new Date().toISOString(),
    quickReplies,
  };
}

function getCombinedPrompt(messages: AIChatMessage[], fallbackPrompt: string) {
  const transcript = messages
    .filter((message) => message.role === "user")
    .map((message) => message.content.trim())
    .filter(Boolean)
    .join("\n");

  return [fallbackPrompt.trim(), transcript].filter(Boolean).join("\n");
}

function parseNumberList(value: string) {
  return Array.from(
    new Set(
      (value.match(/\d+/g) ?? [])
        .map((item) => Number(item))
        .filter((item) => Number.isFinite(item) && item > 0),
    ),
  );
}

function getPromptedFieldFromContent(content: string): AIRequirementKey | null {
  const normalized = content.toLowerCase();
  if (normalized.includes("client name")) return "clientName";
  if (normalized.includes("project name")) return "projectName";
  if (normalized.includes("project area")) return "areaSqFt";
  if (normalized.includes("project location")) return "location";
  if (normalized.includes("consultancy fee - standard deliverables")) return "deliverables";
  if (normalized.includes("workscope breakup") || normalized.includes("work scope breakup")) return "scopeGroupIds";
  if (normalized.includes("execution estimate package")) return "executionPlan";
  if (normalized.includes("selected budget plan")) return "selectedPlan";
  if (normalized.includes("timeline days")) return "timelineDays";
  return null;
}

function applyFieldAnswer(baseDraft: AIProposalDraft, promptedField: AIRequirementKey, text: string) {
  const selectedNumbers = parseNumberList(text);
  const nextDraft = { ...baseDraft };

  switch (promptedField) {
    case "clientName":
      nextDraft.clientName = text;
      break;
    case "projectName":
      nextDraft.projectName = text;
      break;
    case "areaSqFt": {
      const area = Number((text.match(/(\d[\d,]*)/)?.[1] ?? "0").replace(/,/g, ""));
      if (Number.isFinite(area) && area > 0) nextDraft.areaSqFt = area;
      break;
    }
    case "location":
      nextDraft.location = text;
      break;
    case "deliverables":
      nextDraft.deliverables =
        selectedNumbers
          .map((number) => standardDisciplineOrder[number - 1])
          .filter((item): item is DisciplineName => Boolean(item));
      break;
    case "scopeGroupIds":
      nextDraft.scopeGroupIds =
        selectedNumbers
          .map((number) => standardScopeGroupOptions[number - 1]?.id)
          .filter((item): item is string => Boolean(item));
      break;
    case "executionPlan":
      nextDraft.executionPlan =
        selectedNumbers[0] === 1 ? "Basic" : selectedNumbers[0] === 2 ? "Standard" : selectedNumbers[0] === 3 ? "Premium" : nextDraft.executionPlan;
      break;
    case "selectedPlan":
      nextDraft.selectedPlan =
        selectedNumbers[0] === 1 ? "both" : selectedNumbers[0] === 2 ? "optimal" : selectedNumbers[0] === 3 ? "buffered" : nextDraft.selectedPlan;
      break;
    case "timelineDays": {
      const days = Number((text.match(/(\d[\d,]*)/)?.[1] ?? "0").replace(/,/g, ""));
      if (Number.isFinite(days) && days > 0) nextDraft.timelineDays = days;
      break;
    }
  }

  return nextDraft;
}

function applyPromptedAnswers(baseDraft: AIProposalDraft, messages: AIChatMessage[]) {
  let nextDraft = { ...baseDraft };
  let pendingField: AIRequirementKey | null = null;

  for (const message of messages) {
    if (message.role === "assistant") {
      pendingField = getPromptedFieldFromContent(message.content);
      continue;
    }

    if (message.role === "user" && pendingField) {
      nextDraft = applyFieldAnswer(nextDraft, pendingField, message.content.trim());
      pendingField = null;
    }
  }

  return nextDraft;
}

function getMissingFields(draft: AIProposalDraft): AIRequirementKey[] {
  return missingFieldOrder.filter((field) => {
    if (field === "clientName") return !draft.clientName.trim();
    if (field === "projectName") return !draft.projectName.trim();
    if (field === "areaSqFt") return !draft.areaSqFt || draft.areaSqFt <= 0;
    if (field === "location") return !draft.location.trim();
    if (field === "deliverables") return draft.deliverables.length === 0;
    if (field === "scopeGroupIds") return draft.scopeGroupIds.length === 0;
    if (field === "executionPlan") return !draft.executionPlan.trim();
    if (field === "selectedPlan") return draft.selectedPlan === null;
    if (field === "timelineDays") return !draft.timelineDays || draft.timelineDays <= 0;
    return false;
  });
}

function enrichDraft(draft: AIProposalDraft): AIProposalDraft {
  const deliverables: DisciplineName[] =
    draft.includeLandscape && !draft.deliverables.includes("Landscaping")
      ? [...draft.deliverables, "Landscaping"]
      : draft.deliverables;

  return withDraftSummary({
    ...draft,
    deliverables,
  });
}

function getQuickReplies(missingFields: AIRequirementKey[], readyToGenerate: boolean) {
  if (readyToGenerate) {
    return ["Generate proposal", "Save version V1", "Open proposal preview"];
  }

  const nextMissing = missingFields[0];
  return nextMissing ? missingFieldQuestions[nextMissing]?.quickReplies : undefined;
}

export function buildInitialConversation(options: { stable?: boolean } = {}): AIConversationState {
  return {
    messages: [
      createAssistantMessage(
        "Let's build the proposal step by step.\nFirst, enter the client name.",
        undefined,
        options.stable
          ? {
              id: "ai-message-initial",
              createdAt: stableInitialMessageCreatedAt,
            }
          : undefined,
      ),
    ],
    combinedPrompt: "",
    draft: enrichDraft(parseProposalPrompt("")),
    missingFields: [...missingFieldOrder],
    readyToGenerate: false,
    status: "idle",
    lastGeneratedAt: null,
  };
}

export function runLocalProposalConversation(request: ProposalChatRequest): ProposalChatResponse {
  const combinedPrompt = getCombinedPrompt(request.messages, request.combinedPrompt);
  const parsedFromPrompt = parseProposalPrompt(combinedPrompt);
  const parsed = enrichDraft(applyPromptedAnswers(parsedFromPrompt, request.messages));
  const missingFields = getMissingFields(parsed);
  const nextMissing = missingFields[0];
  const followUp = nextMissing ? missingFieldQuestions[nextMissing] : null;
  const readyToGenerate = missingFields.length === 0;

  const assistantMessage = readyToGenerate
    ? createAssistantMessage(
        `I have enough information to generate the proposal for ${parsed.clientName || "the client"}. I've prepared the consultancy scope, work scope, timeline, execution estimate, and summary for review in the workspace.`,
        getQuickReplies(missingFields, readyToGenerate),
      )
    : createAssistantMessage(
        followUp?.message ?? "Tell me a bit more so I can complete the proposal.",
        getQuickReplies(missingFields, readyToGenerate),
      );

  return {
    assistantMessage,
    draft: parsed,
    conversation: {
      messages: [...request.messages, assistantMessage],
      combinedPrompt,
      draft: parsed,
      missingFields,
      readyToGenerate,
      status: readyToGenerate ? "ready" : "collecting",
      lastGeneratedAt: readyToGenerate ? new Date().toISOString() : null,
    },
  };
}

export async function runProposalConversation(request: ProposalChatRequest): Promise<ProposalChatResponse> {
  const localResponse = runLocalProposalConversation(request);
  if (!localResponse.conversation.readyToGenerate) {
    return localResponse;
  }

  try {
    const providerReply = await generateProviderReply({
      draft: localResponse.draft,
      messages: request.messages,
      missingFields: localResponse.conversation.missingFields,
      readyToGenerate: localResponse.conversation.readyToGenerate,
    });

    if (!providerReply) return localResponse;

    const assistantMessage = createAssistantMessage(
      providerReply,
      getQuickReplies(localResponse.conversation.missingFields, localResponse.conversation.readyToGenerate),
    );

    return {
      ...localResponse,
      assistantMessage,
      conversation: {
        ...localResponse.conversation,
        messages: [...request.messages, assistantMessage],
      },
    };
  } catch {
    return localResponse;
  }
}
