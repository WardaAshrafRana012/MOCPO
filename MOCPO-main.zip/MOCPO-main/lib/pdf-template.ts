import { jsPDF } from "jspdf";

import {
  calculateConsultancyTotals,
  calculatePaymentScheduleSummary,
  calculateScopeTotals,
  calculateTimelineTotals,
  getExecutionBudgetTotals,
  getExecutionPlanLabel,
} from "@/lib/calculations";
import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";
import type { ProjectRecord, ProposalSummaryPayload, ProposalVersion, ScopeSheetRow } from "@/lib/types";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/utils";

const PAGE_WIDTH = 595.28;
const PAGE_HEIGHT = 841.89;
const PAGE_MARGIN_X = 36;
const HEADER_HEIGHT = 104;
const BODY_TOP = 138;
const BODY_BOTTOM = 782;
const CONTENT_WIDTH = PAGE_WIDTH - PAGE_MARGIN_X * 2;
const NAVY: [number, number, number] = [9, 34, 79];
const NAVY_SOFT: [number, number, number] = [24, 54, 104];
const GOLD: [number, number, number] = [240, 181, 39];
const TEXT: [number, number, number] = [24, 36, 58];
const MUTED: [number, number, number] = [102, 118, 145];
const BORDER: [number, number, number] = [224, 229, 237];
const PANEL: [number, number, number] = [247, 249, 252];
const PANEL_ALT: [number, number, number] = [252, 250, 244];
const WHITE: [number, number, number] = [255, 255, 255];

type PdfColumn = {
  key: string;
  header: string;
  width: number;
  align?: "left" | "right" | "center";
};

type PdfRow = Record<string, string>;

type PageControl = {
  openPage: (title: string) => number;
  nextPage: (title: string) => number;
};

function applyTextColor(doc: jsPDF, color: [number, number, number]) {
  doc.setTextColor(color[0], color[1], color[2]);
}

function fillRect(doc: jsPDF, x: number, y: number, width: number, height: number, color: [number, number, number]) {
  doc.setFillColor(color[0], color[1], color[2]);
  doc.rect(x, y, width, height, "F");
}

function roundedPanel(
  doc: jsPDF,
  x: number,
  y: number,
  width: number,
  height: number,
  fill: [number, number, number],
  stroke = BORDER,
) {
  doc.setFillColor(fill[0], fill[1], fill[2]);
  doc.setDrawColor(stroke[0], stroke[1], stroke[2]);
  doc.roundedRect(x, y, width, height, 10, 10, "FD");
}

const COMPANY_LOGO_DATA_URI = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/4gHYSUNDX1BST0ZJTEUAAQEAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADb/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAGQAZADASIAAhEBAxEB/8QAHgABAAMBAQEBAQEBAAAAAAAAAAcICQYFBAoDAgH/xABnEAABAwMCBAIEBwgLCwcGDwACAAMEBQYHCBIBEyIyCUIRFFJiFSMzQ1NykiExOEF2gqK0Fhckc4OjpLO1wtIYN1FZYWNkdHWTsiU0OUSRltMnVGaBlMEZJlVWV3eVoaWxxNTi4/D/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAdEQEBAAMBAAMBAAAAAAAAAAAAAQIREjIhIjFB/9oADAMBAAIRAxEAPwDVBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEUN0LVvp8uPLEjCVEyZSJV2x+H/NG3fi3XvT1R23vk3Hh8zYlxLu9ktsyICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiKk2rzxL8YYE4zLKxx6pel9tcCbcaae3U6muf6Q4Pyhj9E31dO0ibQWeyzmnG+DbSevXKF1xKJTGfSAcXvuuyXPomW+HU4fH2R4f5fvLH/V54mOSs7lNsjGHCVZNjvbmXeW56KlVG/wDSHB+TbL6Jv3hIi7VA9Xr+onWjldoZXGsX1dVQ47Y0RgfioTPp7W2/k47Q+YukfMRbupaZaQ/CysTGAw79zvwgXfdjex1ilbeZS6afvCX/ADlwfaL4sfKJbRJXyz6ZWVLCuZLOsej5eqVh16mWzU5HLp1cNgm2uLg+ghMS7hEvm3C2iW0tu7ar56K/FQl0jhCxjqcnuy4fTHg3eXU6z5RGaI9Tg/54er6Td1ODqZXbaoNzUSXbdfpEOo0qcwUeTBksC5HebLyk2XSQrJrWn4WtasnjUcnabKfKrFAHdImWuJE7Ngj5ijeaQ3/m/lB/znlvSNaqRWKXcNNjVaj1CNOgy2hdjyIzoutPNlw9IkJD9wh4ivQWB2kfXrlTSvU2rdmlJuOxXHf3ZQZLvXE6upyI4XyJ+032l1btpdQ7WYRztjHULZbF9YwuNupwi2hJY48dsmE9x+akN/fbc/RLuEiHaSmWLaRURFAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBEWR+vDxAtQ+OdRN24qxLfTFBoNv+qxd7FOjPPuPFGbce+MebcIdrjhD07e1BrgvCuS97Ps6P61dl1UajM7d2+oVBmMP2nCFfnmrepLVRlKT8G1DMWQ647I/6jEqcnlubv9HZIR/RX1W3pE1ZZDkeuU3Bd9TDkFu9bqFNejC573OkbR/O3LXKbbXXbr20f2XwP4Yz3bMgm+4aU65Ui/kouKF7s8YXSrROBjb8C9bkP5s4dMbYa4/WKQ62Q/ZVG7S8JvWFcnASq1Btq2RL/wCVa425tH6sYXlIld8H67rJxzcl+XvmmkCdu0WdVih0ulOvi/yGDd5fOccb27tu3dyyTk25DVT4ouUc3QnbPxhDlWBashvlyiak7qlPEu4XHh28lv3W+ovMRCW1cppK8OzLOpVyJdFbafs+wy4i5xrM1j4+e37MNkvlP30trf1iHaqmcNwkJCW0h7VrpoA8SOn30NKwpnioMQbl2tw6LcDpC2xVOHDhtCO+XaMjyiXa529LnylyZXNwZpvxPp0tUbVxbbLFPbc4DxmVB3hzJs9wfPIe7j83T9wR9PSIqUkRYbEREFHdaXhsWRnpuXkHGXCHauQDEnHuPAOXAq5f6QIj8W6X0wj1fOCXcOWNt3VqE0T5ge9T+ErQuqkmLcyDKb3MTGfZcb7ZDBeUh6fM2W7aS3G1L6rcX6WrO43Nfk7i/UZQkNJosZwfW6i57o+VsfM6XSPvEQiWF2pLUpkXVBf53xkCW0ARxKPTKZG6Y1Pi7t3Lb8xF5icLqIvd2iO8UrUvDXi5adrsoMIcsnUrJr23bMH1F6XB5nDzMuMiTm0vZIR29vV3FZmydVem/I3ABs7N1mz33OyMVXZYkl/AuELn6Kwl0zaYL71U3VWLMx9VKJBqNIpRVY/hV15tp5sXW2iESbbc6tzo+Vd9e3hq6yrJFx5zErtbjt/P0WoR5e76rYuc7+LTk23vZeakNi8y4JtkO4SHjuEhX9F+bwJepzT1JEG3sl47MT7d0+l7i+r07lK1keJprIsnYyWUhuCK38xXKaxJ3fWe2i9/GKcm29qLI2yvGpyJC4tNZCwxb1WHtN2kVB6AX1trov7v0Voppf1FW7qhxVHyjbVHmUhh2Y9Bdhy3BNxl5rb6eoekh2kJf+tZVLyIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIC/N/kydKzrqhuOVT3Scdvi9pDMLb1dMqaTbI/ZIRX6A88Xjwx3ha+774vcGzoNuVGoNFx+kbYMmx/OLbwWF3h92Z+znWJjGlkzwcahVb4aMvKPqTRyRIvzmR/O2qxK32ti07fs6mNUW2aPCpsJkBbBmKwLQ9PD0eVewiKKKMdT7nJ03ZXc9mx68X8gdUnKJtWr/FnS3l1wf/AJi1wf8AtgPIMSdAliWvk7VbZlhXtQotYodXZqzM6FIHcLjfwVLL6wkJbSEh6hIRIeoV1+tzQbeGmGsldlu+uVzHdQf2xamQbnaeRF0x5e3tL2XO1z3S6V/Hwum92tuwi+jYrDn/AOGSR/rLdK4beol10eXb1w02LUabUGSjy4cpoXWn2S+4QEJffFbyYZd6AfEuOlDT8J6ja2bsYuLcWh3VLP7rHlFiaZfN+UXy7fnOnqHVNiQ3IAXGSE2yHcJCW4SFYqa7vDtruB5M7KWJ4cqqY7cPmSo27myaAReVzzOMbu1zuHpEvaL3dA3iQVDEbkDEOdKm/PsciGPTKue5x+ieUW3PM5G/Sb8u4ekYNk1U3WfrysXS/Rzt6lcmv5EmMcCgUUT48W4m7tflkPyYeyHyjnuj8YMS64PE3tvGsJ/G+nur06v3ZIa4DIr7BjJgUngY/MkPS+/1e82Pm3EJNrPDT5pqzNrLyRMGkyJbzTkj1q4bqqfMdajbuoicc7nni8rfcXujuIWOLbzIcPP+t3NXHg0M+7bwrh7nnS6WIUfd3F83Hjt7vdHq2juIuq7uoDRHjzSboPvOpiTNevqpuUlqo11xv0bBKewRR430bW4e7uPbuLyiN8NOWmHGGmGygtHHlL4+sviJ1OrvgJTKk8I97pez7LY9I/WIiKIfFcc5ejC5h+kqdLH+Vtl/VTpNKa+C23/5eL3c9m0dv8tY/srYlZAeCuPD9ua/3PZtlsftS21r+pSP5SorMxk48hsHWnB2mBjuEhUS3rpF0zZE4GV24Ns2W853SWqU3GfL+GZ2ufpKX0UVjv4nWirDenOy7UyBh2351IYqlYcpdQjnUHpLIkTJOs7ecREPyL3mU2eCndnCfiTIVkme74HuGPUhH2Rlxtn/AOkJSv4r9rDcmjivVLlbztur02rN+7+6BjEX2ZJKn3gvXZ8H5qviyye2BWrabqHAfacjSWxH9GS4S0mmwyIiyoiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIKm+KHen7D9G13x23tki4pEGisF7XMkA44P5zLTyoz4Nll/DWoe5byeb9LVu2y42Bbe2RKfbEf4tuQpu8au9Bj48xtj9tzqqlamVhxv0/+asC0O7/ANsL7JL6PBVsvhDxdkS/yb9HGs16LSQMh++MSPzOn86X+itJ186aRIiLKih3WM5wb0p5cL/0Mqw/ajOCpiUI623eVpKy0X/orOH7TZCgyR8K1vma07QL6ODVi/kTo/1lu4sK/Cjb5msy3nPoaRVC/kxD/WW2F+31amNbYnXre1eh0aiUxonpU6W9y22x/rFx7REeoi4iI9ytSPTrJU0adKKuFG4U0WHPXClbeRydvHmczd07dvp3bunavz26xh06jnCs/wBzK5KK1d25/p/cQzNxcz1Lzcj2d3m3bfi+Wpf1weIhd2o2VLx/jsplv43Bwg4tEWyTWdva5I29rfmFn6pFuLbt7bQp4aVWytxgZaz3BlUuzCEZFNoZbmpdZHuFxzzMxi+055do7SJGVHcdx7FmXvRIuS6hVIFqvTmxq8mmMC9LZi7uomxLp3fa9raXaX6KcB25iK1sWUKm4Ij0sLLKOMimu04uY3JEu54nO5xwvMRdW7uVBdenhjxZDEvMOmqgsxn2Wyeq9ow2trbgD3OwWx7S9pge75vq6Sqfoz1vX1pPuX4IqDcqr2HOf/5VoZl1Ry7Sfjbult0fMPSLnaW3pcHXpqN8VTbxaHNujesj7VapY/xyszi3KVkZlsuBkDHdfj1eh1MN7L7JdQl5m3B7m3B+8QF1CqteLq5y9IMgfpLjpo/ziwqr/gqM7sp5HkfR0CK32+1J/wD4rXVZKeCc3uv3Jz3s0inj9p53+yta1akERFFRFq4tP9nGmXKFstt73ZFq1Bxhv0dzzLJOs/xjYrHHwxbs/YrrPshtx7YxWgnUl33uZEcJsf8AfNtreGoU+NVIMimzG98eU0TLrftNkO0hX5ycTTpOF9UVqyp7hNHZ98RWZm72WJog8JfmiQqxK/SAiIooiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIMffGcjXk9mOzJ82hS2rXj2/wCqwagQfEOzSfdOQ2JdokLfI6S6vN2qRvCb1YYxpNmtaabjAKDcblQkTqZMfdEWKw48XyO75t8ekRH5wRHb1dK0Lyniyxs0WTPsDI1AZq1FqQbXWHR6gLyutl3NuD98SHqFYd6ytFF96TrrCrQHpFWsic/uo9ebEtzDncMeRt+TeHyl2uD1Dt6hGxhvqizI0AeJc1XuNOwlqMrLbVW+LiUS6JTnobl/iGPLIu17yi72n5urqc03UbFA+ut3k6Qcrn7VuSB+1tFTwqb+JbnvGtiadrpxjX680N0XpA9TplLYIXHyHmDxJ5wfm2h2l1F3F0juQZjaAswWNgbPfHKeRJ5x6TSaBUfQDDfMfkyDARbZZHzOEXHzbRHuIhHqXzaqNYOVNXl5MRpTMiHbjcoQodsQzJ0RcLpbcc2jufklu27tvm2iI7uqF7BsG8cnXXTrHsK3pdarlUdFmLDit7iIvaLyiIj1ERdIiJES2g0QeHnZ2nWGxfl9hEuHI0hn7r+3fFo4kPU3G3dznlJ4uryjtHdu3kkRLoQ8MSJavCDlzUhSWJlcHlyqVa7o8xiD5helj2uPey12t+bcXSOliIsKLPvXz4b9Ly23Oy9g6mx4F9db9RpAbWo9d/GRD5W5Je12uebaXUtBEQfnr0yapMs6NsiShhsyzphyPV7jtefuZF7lltLpLqZkD2i5t3Dt2kJDuFXw8QrPeOtQWg6nZBxxWhmQpV1U5mTGPjtkwZPBl8iYfb+bcH7Jdw7hISUp66vD8tvUjTn76sAI1EyRHZ6X+IiEariI9LUj2T8ovfmluHbtxguaj3zjeqVrG1zR6pQ5jMgWarSn+JN/HM7uXzG+0tu4iEvZc3D3K+krQ/wSm9115Xc9mn0kftOSf7K1hWUvgk7RrOXXNw7hjUMdu73pq1aSqIigXVVq7xlpTs74Zu2R69XZzZfA9AimPrM1z2i+ja3dzhfm7i6VB3Gac3Y5wBY8vIGTq+3TaZH9INB3Py3vR0sMN/fccL2frEW0RIh/PJly8YuVMyXXflr0GTT2rqr8yqQ4HAua82Ul8nBb6R6i3F5V2WV8uZz1q5aiyKuE6u1qoSPU6FQKa0RMQ2y+ZYb8o9PU4XUW3cRdK1J0OeHTa2n5qJkTJ7MKv5H48BcY28OZEoe4e1jd0uPe095e1vzE5fJ+rgWDU6lW7JoFZrkGRCqM6lQ5UyLIbIHWHjaEnG3B49pCXEuBD/kXRIigIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAufvWzrayDbU+zrwo0WrUaqMFHmQ5Yb23Wy/8Af7JdwlwEuHoIV0CIMMtcmgC5NNdSkX1Ywy63jWS96BkkPMfo5EW0WZPtN+UXvzS2lt3S9oA8SeRaR07CeoatG/Qy2xaJcsktzlP9liWXmY8oudzfaXxfU3q7WqRS6/S5VFrkCPNp85hyPKjyGhcZeaLhtIXBLpISH8S/PtrSszAdh51q9B083O7V7fbLdJaH4yNT5W4uZGjyN37obH2vL27nNu5WMNRdbXiI2dp8pb9l44fh3JkKSzvFkT4ORKSBDuB2QQ8eo+I9QtCXUPUW0SHdj1XZWVc4Vi6MmV3jVrmnw2vhSv1Z/qGO2TgtiThdrY7iFttsfqiPSvHsCkWtX71otDve5nbfoM2c3HqFVCGUkocci6nOSJbi2rYPUviHD+E/DcvmgYWiRDoM6nUuV8KMmLzlW4uT43okuSB+VIhL7/aI9IiI7RWvLfpT7wem+Zqxml9HaFQL+PjD/WW2KxY8G5vdqqrZfR2TOL+VwhW06zUgiIooiIgLOPxk8b2S3h62sq/AUULrauOPQxqQDy3XIbkaS6TLm35QRJkSHd29W3uLdo4qA+NA7xDTPage1fUX9QnKxYyhw9mbIOB74g5CxnXTptWhltLzNSWd3VHeb7XGy8w/VIdpCJLc3SJrRx3qptPmwOLNIvCnNCVat83txs/55gvnWC9ry9peXdm14e+k6wNVuNMvW9dXDjCrNOfo7lBrTIbnae8Tc3d++NObW+Y2XdtHtLaSrHNK/tNeYJ8W171jxbltGoORQq9AqAutEQ9JE24PSQkJbSEveEh7hWuWY2N1seIHZOmenv2haoxrgyNIb9DVOFzcxTRLtel7ftC13F7oluWSVr2tnzWvmZxuKc667trTvNqFQl8drEOPu+UeIR2ssN9oiI+yLY7tor/enLA94avMztWS3d0OLNqBOVKq1Wpy+Y+Te7c8422RcyS71do/WIhHcS3a0/adMY6arFZsfG1G4sNceIuTp73oKXUXhH5aQ55i+/6B6RHdx2iKz5PTgNIWinG+lW2hKmthWLzqDAt1e4nWtrjn+Zjj8yxw9nuLpIiLaO2ySIooiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAvOrdbpNs0iXXa7Uo0CnQWiflS5LwtMsNiPpIiIvuDwXP5SyrYeGbKnX9kW4Y1GokAeJOvvF1GXlbbHh1OOF5RHqJYj6zteN+apqwdt0XhIoOPor/7jpAH8bOIS6ZEvb3F7LY9I+8XUVxxEsa6/EtrGWONQxNgadKpNmEJR6jWB4E1LrIdpNt+ZmMX2nB7tokTZcfoe8O67NRciJkHIzc23sdNmLjZ7OXLre3uCPu7WvKT35o7uohlzQl4Ysuv/AAdmDUrRXY1L47ZFKtN/gQvSvML00e5tv2We4vnNo9JatQoEWmxGoEGM0xHjgLLLLQbQbER9AiI8O3h6FWGTuvHwy+NmRJWX9NtHffoUVrmVe12uJOvwhEep+Nu3E435ib6iHuHcPydOLZ1QZIt3A926c5E0qpZt0NxyaiS3SIqW8zLak8xgvKLnL2k327i3d27d+jRZV+KBoYsa0rYqepnGxRqGTMhr9kNGba2x5JyHgaGTHEfk3OY4PMHtIerpLdzGOTWkceDIyLmpq6HPo7Fmfr8FbNr88WjbU9N0p5eC/W6C3V6XUoZUmrxt21/1UnG3CJku0XBJlsurpIdw9O7cO9WKcsWNmqyoGQMeVtiqUSohwJt0OPW2XmadDubcHzCSlI7NERRRERAWfHjSuejTxZbftXm2X2YEtXcyNkiysUWlUL6yFcEWiUSmNk5IlyXNoj7Ijw++Rl2iI9RF08FiHrn1xVzVfXI9v0amfA9g0SUUilxHmx9ZlPbeLfrL5eUtpEItj0iJdW4uodY4pUQ451D5LxPje7sbY/rBUaNfDsUqvOjEQyzZYF0RYbc+bbLnFuIeou3dt3CU16M/D3v7U4fC8LmkSrUsBsnBGpk18fUHB6dsZsu4RLucLp6SEdxbtvTeGho5snUhcFbvvJUk5Vv2bJit/Abe7gNRkOCRDzXPoh29Qj3bu4R7tpqXSoVGgMUulRWYkSK0LLEdhoW22mx4bRERHpEeH+BW5Mvz357085m0W5Ujx6lKlRyjv+uW5c9OJxlqWLZDtcbcHqbdHp3N7tw+8JCRaa6D/ESomeYsPF2VZcOkZGZDg3HfLa0xXRHzN+Vt/wBprzdRN+YW7W5iw1YGd7Km49yVRGqnR5g/e4jtdjPejpeZc7m3B8pD7wluEiFYaastHWSdIt6tSikS6jakqVzKDc0USb+MHqFlzb8jJHbu97buHzbc+l8v0Dos4NAXiTMX9wp2F8/1lpi6C4NxaNcL5iDVU8osyC7Rf9k+1ztL4z5TR9RoREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERBgj4i2XMp35qVu6zL4rzjlIs2qvQaHTWvi40aP0kB8vzOuDtInC6i90RERvF4fvh0WtjumUbN2X24dwXXMYj1KjQeG12FSmzEXG3PZef6hLd2tl27iEXFSrxSbc+ANaF5ShDY3WYlNqTY7faiNNEX2mSWvujq5P2V6WMVVgnN7hWnTY7penucZYFpz9JslusJkREWGxVG8VRzl6LLvH6SdSR/l7Jf1VblU78WJ3l6M7hb+kq9LH+UiX9VBkpp00yXhqa43fS7BkMFXrYow1WJT3+kah8cIEwLhFtBzaW4d3SRDtLbu3L19N2prLmjPJUkqfHlDD9a9VuO15+5oJHFstpCQlw3Mvj1bXNu4S6S3DuFWd8FZvdl7ILns20yP2pI/2Va/XJ4f1q6k6Y/fFlhEouSYbXxcsh5bFYER6WJO3zeUXu4e0tw7du+kiwOBtQGN9R1hxcgY0q/CXGdEQlxHOmTT5HmYkN+Ux+yXcJEPUpLX518WZYzlomzJKlU6LMolcpb/qdcoNRAhYmsj8y835h6twuD7W4S6lt5pi1V421TWO3dlkyvVKlF4CFZor5j6zTXvZL6RstvHa4PSQ+yQkI5uKpsUUagtR+MdNNjPXpkiscGuB7m4FNYLgUyovcPm2Q83vEXSPmJcDrA1t450p23xbnbK1ec5kjpNvsudXH2XpBfNNfpF2iPcQ4yXDcmfdbWaWnJTc+7bvrR8mHBit7WIUfd8m2PbHYb3biIunuIiIiIiuOI9nUjqlzDrMyDG+E2JIwfWPV7etWmcHHm2CcLaIiI9T75btpObdxbtoiI9K9vUBosufTVgy08hZLncm67sq5RSojRCTdOijHI9rznzj5Ft7S2jt83l090V+H/Y+manNXbcnCJcWRpTXxtTJncxTRIepmIJdvmEne4vdEtqhvxsXi/axxpH9qvTHPsxx/tK9JX+fBOa4/tcZMf4/eKuQR+ywf9paSrOTwUQ2YhyGftXJH4fyYVo2sJj5FzOQbBtHJ1p1Gx75oUasUWrMlHlxJDe4SH/CPH74kPHqEh6hIRIfvLpkRphDrd0GXbphrZXXbXCXXccz3tsWok36Xaa4RdMeXt7fde6Rc90lYrw9PEfnDMo2As9VCRO4y3mabblxnucdBwi5bUaX5iEiIRF3uHdtLp6h0T1AVCi0nB9/Vi4oEWdTafbVSmSY0toXGnRbjOHtIS6S7VhVoJtT9mmsPFlJ5O8Y9cGrF7vqTZy938StsP0LIiLDYiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiIMb/Gctv1HP9o3QLe0KtaYxS95yPLf6vsvN/ZV2fCzuThX9F9nRSc3uUWXUqaZfVmOujw/3bwqvHjb2zzKJii7mw+5FlVamul7XMGM42P8S4u48F64vXtP14WyTm5yk3YUgRLytvxGNv6TLi0w0GREWWxUv8W97g3o8qLf01wUsf4wi/qq6CpH4vjnAdIvEOHzlz00f0XeKCtvgot7sjZLe2/dGiwR+0+5/ZWtyyb8Exv/AOOeU3vZplLHd9Z5/wDsrV9+Q3HAnnjEGxHcREW0RFWpFZtZ2iWw9VFscJvAmaLfVOa20qucG/TzBH/q0kR+UZL7QF1D5hLF+lV/NGj3NM9uh1l23L0teU5T5nqz7b7LntNuD1NvNF0ltL3S6SHpv1rq8UFqKVQw/poqwm/w3Rqvdsc+lv8AETUAva8vrH+78rg1A0paJ8rauq1IqUOQVDteOZev3LOYJ4TkF1ctkdw8932uoREe4t20S1iy5HE+Kcy6zs0PUem1J2s3DWDKoVms1N/cMZncIuSHi7to7hEREfZERW3WlnSPjLSvZ3CiWbF9erkwB+F6/Ja4cJM5z7+3/NtCXa2P3vNuLcRYkXxYeddE+aWY856bblzUN/1qlVWGRciaz2i8yXa804PSQl7wuD3CtdNEOvOz9T9DG2q+MWh5Fp7G6ZSuB7Wp4iPVIibu4fab7m/eHqTJuLdLNDxtz9Fj4tZ9uq1Ivsss/wBpaXrMfxuj9Fs4mZ9qdWC+y3G/tLB1y6fwV2//ACH3497V1CP2YjK0RWe/gtN+jT5ernHzXk4P8ijf2loQjOPkRERpWXxIbt/YhozyJKbPlv1KLGpLQ+16zKabcH/dk4s7PB9tP4c1TTbicZ3NW3a8yULnsvPPNMD/ABbj32VavxnLu+CdPlrWgy5tdr10C+fD2o8aM6RfxjrKjzwS7Q2QcqXy818u7S6TGc+qL7rw/pMrSVqKiIsqIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCifjF238MaWKbWW2vQ5Q7sgyCL2W3GH2i/Scb+yoA8GLIlAtyvZMs2vV6nwCqzFLmQW5UltknnGSktuC3uLqLa432+yr8608L17UBpxurFdq+pjW6p6m9Tzlny2ReZltO9RbS27hbIfzljhePh0ayrME35WFajVow9rtFlMVDd9VtlwnP0VYlfoABwXOG4S3Cv+r83jFwancAv8GGaxkvH3FstvBknZ9L/ADeWW1SrZfiZayrL2NllQa9Hb+YrVMjSd31nBbF7+MV5Nt7lRnxh3OXpOgD9Jd9PH+Ikl/VVa7O8ajKlP4A3kDDts1tvzOUqY/TnP4zniuc1t+Ihj7VjgmBjqh2LcNvV2LX4tWd4SzZeiEy2w+BCLgkJbtzw/NprRt1vg43Hb9l/t03dc9Wh0ulUum0d6VNlOiyyw3ulkRERdI9q4rXL4kVezY9PxfhiVMolg7ijzZ3U1LrYj7XmZYL6PuIflO7ljSOn1q4I9KmWrTalNCnVh+O5LgsGXLluM8zk7hHuIeY5t+stM9CPhfczjT8wamqP9zhtk0i0Hx+y7PH9Lkf7zzNqm0O6F/Dpr+en4OTMsx5lFx2PEXmGOG5mXW/Z5f0bBeZzuLtb+kHZe0rRt2xbfg2paVGiUqj0xkWIcOGyLTTLY+URFelGjNQ2hjxwFtpvgIgAjtER9kV/dYVFOovThjXUzYT1h5Dpvp9HEnadUmR4cJdOkbflWS/7Nw9pfjWGuedPOZtFuVYkaqSJUd2O/wCuW5ctNJxpqWIkO1xlwept0enc3u3CXtCQkX6IFwWYsL4/z1Y83H2S6I3U6TMHgQ8PRtejPbel9lz77bg+UvrCW4SIVcchVXQf4h1Bz7GiYwynJh0nI7ACDDvS1Hroj5mfKL/mJrzdzfmFuJfG9d20vD7W7ukVwvsjB/tKnGq/R9k/SHfLchx2ZNtmRI5lv3PG4cvcQ9Qg5tL4qSO3d73cPu+PqF1Z3xqSx7ju18jNjKrdhlUmyrO7qqDMgY3LJ4fph5Bbi824fNu3a5TbSHwXmCHTXdr/ANJfEofswIX9pX/WXHhg6nsAYJ03Vyi5VydSLeqcq8ZkwIb/ADDfNkokJsXOW2JFt3NkO73VYyveKnoyovAgh3/Vqy4PlgUGXw/SebbFYTHyt2iz9r3jPadYO4aDjvIFUPyk7GiMNl/HkX6KjmveNu1w4ENtaeDL2Xahcu3+Lbjf1ldVpzHjW3Z61kLGthi7w20ujzqsYcP9JfFof1Qv0lZXwh7R/Y7pLGuE36ON0XHUKkJe0LfLjf8AFGJZSapdSFxapcn/ALZ1yUOFSH26ezS2IcVwnAaZbJwh6i6u5wiW4Oh60+Fl6SsV0Um9hOW3FqBh6O0pe6SX6T5JT0nRERQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQfwlxY86OcWUy28y4O02zHcJD9VRTeekfTPkDeV2YNsuY653SWqQzGfL+GZEXP0lLqIKW3l4SWka5t50Ol3Pahl1cPgusk62JfVli8oCv3wUiaaflYzzmTrvACJiHXKRt3F5RKQy50/W5K1PRXZfs/N87CzBpDzXDdrFv/Ad52jMGUwxUojb7Bbe1wRLc282XVtcH6wkJCJDtBo911Y51S0H4O4k1Qb6gtbqhQXnflBHufjF841+k35unaRdrqa0oYw1T2fwt2+oPq9TiCRUmtxmh9bpznul5my8zRdJe6QiQ4kZwwHnDRhlCG3WHplOkRZPrVv3LTHHG48sWy6XGXB6hcHcO5suod3mEhInpny/RGioFoX8SmhZn9RxdmuXEol9bW48KeRCzErheXh7LMgvo+1wvk9u7lq/qjQi5+872tPH1vTLrvW4INEo8AOLsidOf4MstD9bj5vxCPcRdPBZZ6tvFkrVxcZ1h6Y+L9Hp3Uy/dUlnbNfDt/cjZfIiX0hfGeyLZILba5NVemXGlh1bHOV6fDvmqViITY2jHPgTxbuptx9z/qg7hEhc+U7SbEtqw0jU6ZclfGl2tQ5kl+oSOTT6fGEpL5bi+LZHaO5wvL0j1Kb9OmkLOuru436nQYjzFIckk5VbqrBOcgXCLc58YXVIe90d3cO4h7lsRpg0QYb0u03g9alN+F7oea5cy46i0JSXPTw6hZHtjt+639/p3EW1b8p+ss7U8KvWDdMSPOlWnRbfCQAuCNXrDYuCJe02zzCEvdLqUm0LwXc6SeI/skynY9PHzepetyyH7TTa2JRTo0y9t7wRqXw9Dl0ahZb/ALTUG3Ba/ScfL/hUj0LwZ9NdO2lXL1v+rOeYfXIjDRfmjH3fpK/aKbqz6qk0HwstF1F2lJxlNqpj5p9cmlu/NbdEf0VaekUinUKmRKJSo4R4UBhuLGYDj0tNtiIiI/VEeC+9FAREQEREBERAREQEREBERAREQFW/UJqD1BYIoVYvmNpxo932tSeY87LpV6mMtqGJfLvRnIHT07SIWyd29XVtHcrILjs0DuxDfH5NVT9WcQUhwT4vFvZfy1bmNblw/wAbRi3FLGntVXjcfrYtSHOlkSb9Wb6XHNre7d07ty0PX5vMlYfrWM7IxjlKEUr4Lv6kOVCNJ3beROjSXGnmRIdvUO1lwf373VuPooz9H1Hae7cvt6UDlciB8FXAA/fGoMiPML3eYJNvCP4hd9CtE+IiKAqF6o/FPoenXMNSxHRsT/svdorLPGoThr/qQtSnB3kwI+rObtok3uLd3EQ7elW5zdlKjYWxTc2Uq8Qeq23TnpgtEW3nvdrLI+844TbY+84KwY1S49uKy5tjXXfTjrt25Ktwr4rxu8S3esTZ8smx2+X4kWdw+UiIVYdabQ6ZM/Zd1AWpTMkVrCNKsy1Ks247Cefuo5c+Q2O4RcGMMIR5ZEPcTglt6hEh27rAqG9Gv4KOJPyOpf6sCmRKCIigIiICIiAvnkSWIjRyJDgg02JEZFx2iIj3FxX0LzqzRqRcNPdpNbpkSown+l2NLYF1o/x9Ql0kgqxmbxMtOWLas1adt1cr7uN6SMX1WhuiURlwi2/Gy/k/93zC91W4WN3in2rbNpasMb0+17eptHjO29T3TagRG47bjnwlJHcQtiI7ukVsigIiIC4vLGI7BzdZk2wsj0GPVqPOHqBzh8Yy55XWj7m3B8pCu0RBgjrJ0J5A0s1kripJSK9j6U//AMn1poeuIRF0tSxH5Nz2XO1zy7S6Rl/Tf4st54vx1NsvLluTL5l02JwG3qn62IPkXaLM1wtxONiPz3U507SEt24dfK/QaRdFIl0C4KZFqNNqDBR5UOU0LrL7ZdwkJfcLgsws2eDzOrGVocvCV2U+jWRVnScnsVMnHXqN5i4MCP8AzhsvKJEJCW0SIh6lo5UrzNqDz/rHvmHGuOXNrL8iRyqLbFIYcKNHIt3SzHHcTjn+cLc4XmLaKu9pJ8JFsOEO+dUDu9zjwF1i0ob3SP8Arrw8er96b6e3cRdQq6GmzRxhjS/SODNh0ThKrklvZOuCePBydJ9od3zLf+bb2j0ju3F1Kdk6TTzaDQKPbFIi0C36XDplNgtCzFhw2RZZYbHtEQHpHgvSRFlRERAREQEREBERAREQFCOd9YmANOkYxyRfcZurAG5uh0/j63UnPZ+JH5Pd7ThAPvKblRPxUMeWDQ9KFbuGjWXQoFTKuU8jmxacy1IInHurc4I7urzILL6bc6U3Uhial5do1AlUaBVpMxmPFluibotx5LjAkW3pEi5e7aO7bu27i7lKqqb4Wn4Edjf6zWP6Rkq2SAiIgIiICIiAuNzN/egvn8mql+rOLslxuZv70F8/k1Uv1ZxBQ+iae+Gonwo7Lt+lwufctAp0yuUHaHxjkpmXJ3McP31vi43t9ohLyqtfhSahyxTnYsX16Zxat7InLgjzC6GKo3u9WL+E3ONe8TjfsrSbw5PwLMX/AOz5X66+srvEYwPM08amZletdt2BQ7sP9klDfY+L9WkczdIZbLyk298YO3tFxtaZyxbwooS0eZ5iajsBW5kjg618Lk18H1xoPmqkyIi90+US6XRH2XBUt3DXaXa9DqFy12Y3EptKivTpkk+PoFlloCNxwvdERIllpUDWE+Wf8+Yt0c04iOkuSRva+uXx6RpMYtrLDnuvObh90iYJU58ZpluPqKs9lsOAgNjx9vDh28B9fm9KuZoAoVSyVOyJrHu2I8xVMqVpxmhtPj1xKDELlR2/zib2l7XIbLzKnHjQfhHWj+RMf9fmrRk0u0afgo4j/I6k/qwKZFDejT8FHEf5HUn9WBTIs5AiKhXiW6pbvsdq39N+GZLrd95A4tsvSIrm1+LFfc5TLbRfNuvubh3eURL2hIQni+9aWErMu5zHNJnVy+bxZ4kL9AsylO1iWxt47S5nK+LbIS7hJwSHzeheO/ruxTbs+JDyrZOS8YsTXBZjz7vtZ6JCccL7w+sN8XGx/wAu4h9C6vSxpqs3TLi+DZVvRY71XeZber1XEPjqlN29ZkXdyxLcLY+Ufe3EUoXbadu3zb861Luo8SrUipMFHmQ5TQuNPNl5SHitNPpolcpFyUyLWaFU4tSp8xoX48qI+LzL7ZdptuD0kP8AlFeisvMRX3XtA2sZ/Svc9alSsT3tKblW05Nc3fBpS3CGO4JeUecLjD3lIh53T1btQ1lkREQZBeLl+F9jT8maf/Skta+rILxcvwvsafkzT/6UlrX1WpBERRXjXVdttWRRJVyXdXYFGpUFsnZM2dIFhloR8xEX3FXWN4hWJrjOU5i/HGWsj0+GZNu1O07MkS4gkPd8Y5y/+FUoypkC4PEQ1qUnANEq0pjFVu1J7mtxXCEJMeNu9ZnF7zm3ksl82LjfSO5zdrDa9p27ZFBg2talJi0uj01gI0OFFaFtphse0RFaMUX4U1cYRz1VZduWXcb8W5adv9ct6sRXIFSY293xLg9W3zcsi2+ZTSqBeKLh9+37SourjGZcaNfGP6lFGZUofDY4/DccFpsnPpCbdJser5txwS3CrV6Zcxw8+4OtPK8NsGjrkESmMB2sS2yJqQ2Pui825t93asiUkRfyeebYAnHCEREdxEXaIoPjrNapVvUyTWq3U4tPgw2SekSpb4tMstj98iMukR/ykqvXP4m+lCh1o7fody128ZrZEJDblHelh0+y4W0XB94SIVUm9b4vzxN9Tx4Xs64ZdIwzajhSp78XpGXHac2lLLd3OvEW2OJfJiW7b8otLMUYTxjhG2WLTxfZ8ChU9kBFzkM8OdIIfO878o6fvERLWjFClieJZpKvitDbjt+yrYqjjnLFi44DkAd3sk8W5lv85wVZ+PKZmMhIjuCbTgiQGPH0iQl2lwVL/FCwtjKu6bLsyxUbFjybvt0IfqNWiNcuW225LZaMXCH5RoW3HOlzcI9w7VwHg35Uvm7cb3njy435U2jWdJglRZL5EXJbkC/zIwl7AkyJCPl5he6g0XREWRXm4Nfuku06vIoN2ZW4UWqRC2vw6hQanHfaL3m3IwkKmqzbwt+/bXpl52nUOE+jViMEyDK4NkHB9kx9IltLgJD+cKzy8ai2qHxxxj67iprPww3XHqYMzbtP1VxgnCbIvMO5sSH2er2iVwdFn4JuJfySpv8AMCgkC/sgW3jK3XrsvGTMjUqPw9L0iNT5Evle8QsNuEI+8Q7eHtKKrJ106UMjXZTLGsnL8OqV2rv+rwYgQJrZOuff27nGRHh978ZKfVjjUrfo1r+MdFo9v01mBEG7IcjkMDtDmP04HXi2+8444X5y1BsciIsgqbeLR+BtWf8AbVL/AJ5XJVNvFo/A2rP+2qX/ADyD1/C0/Ajsb/Wax/SMlWyVTfC0/Ajsb/Wax/SMlWyVoIizr8VXVzcmN6ZTdPeMp8mDXboh+tVqZFL49inmRNtsNlw6hN4hc3ebaO35xQWJvfXVge0Lucx3QZNw3/dcbiQv0ayqO7WJDXEe7cTfxe4fMPM3D5l8lB19YPlXXFsrIFNvTGFan8NsNi+7fcpIyPqulxJseHvEQivT0ZaZKBppw3S7bapcbhdFRjMzLkn8Gx5r80h3E1zPM2zu5YD29O7uIl1mpbBFrai8T1nG1yw45OymHHaXMcDc5AnCPxMhsu4dpejdt7h3D5lppKjbguDuEh4iXaQ+Zf7VB/Cn1B3HeljXDgTIUh924savizEKQe54qeRE3yS8xEw42Te72XGx8qvwssi43M396C+fyaqX6s4uyXG5m/vQXz+TVS/VnEEQ+HJ+BXi//Z8r9dfXheJDp6/b605VV+jwedc1mcyv0jlj8Y4LY/umOP74zu6fM422vd8OT8CvF/8As+V+uvqyCv8ARi14S+ofhjXM0jDtwTiCh5CEW4fMLpaqzYlyfq84Scb94uSryeIjedarNoWnpisGRxC68z1huj72+r1altuCUt0vd+TEvab53srMnXRhGoaXtT007R4O02kVB9u6LXkxun1YSc3ctsh7SZeEhH3RbLzK92hit3Pq5zrW9Yt+UsIsW1aHDs23owlubanEwLk95v8AOcc2+7K2+VKzjkvRYlmUPHVn0exrZj8ik0GBHpsNv8Yssti2O72i6erisjvGg/COtH8iY/6/NWySxt8aD8I60fyJj/r81ItaXaNPwUcR/kdSf1YFMihvRp+CjiP8jqT+rApkUyUWRE99zIXjNRo9e+NYpdwttxmy6hb9QpROM7f4RnmfWJa7rJLP1NcwN4stn5Gqger0W7qrTZjUk+wW5DPwfIIi91zmEXukKsStbURFFZUeNhRWYFcxFd0XjyZzzFYhk6HSW1kojjf2Sec+0tMMZV2VdWOrWuicPDhJq9Fgznv3x6OBl+kSzH8Wx6dlfUJiLAlq8OEmsjFLlMD1bZFRktstiXs9MUS+qW5am27Q4dtUGmW7T+H7lpcNmGx+9ttiA/oitHT0kRFkZBeLl+F9jT8maf8A0pLWvqyC8XL8L7Gn5M0/+lJa19VqQXG5jrUy2cSXtclPc4hKpNuVKcwQ+VxuM4Yl9oV2S8G+bdG7rNrlpuFsCtUyVTyL2ecyTf8AWUViL4bGJMgZVyzcrWOcxz8bVCl28TjlTg01ua46y5JaHkbXHBER3CJbv82K0e/uRNWH+MLu/wD7qRv/AB1R3wj64Vhasrkx7cgep1CqUCdTRYMuoZ0aQ04439YW2ZH2Vs4tZZJFJ720Hag8i2xPsu99d10Vii1RvkzIT9qx9jwbhLaW1/2hEvzVNOkXTbx0r4qcxaF8PXSzwqsipMSnYPqpNC6Le5rl8xzzCRbt3nU3osqKHNYlx1C09LuUq7SXiamR7VqDbTg8eoCcZJvcPvDu3KY1Heoex5WTMGX9j+C3vmXBblQgxR/0hxghZ/jNqCk3gq21TWMR5Bu8Wh9fqFxs01w9vVyY8YXGx+1JcWjqyi8GbLsCiXBfeC6zI4xp1W5NcpTTvSTjjIk3Kb/fNvJLb3bW3PZWrqJHzTIceoR3IcxgH2HgJt1pwOBC4PHuEhL7/BfFb9sW9acLjTbXoNOpETifM9XgxG2Gt34y2tiI+lesv5i4HEyDiXDcI7uPD0//AO/wIr+iIiDOrxq/7ythflQ5+qOK1uiz8E3Ev5JU3+YFVV8all0sH2I8PDjy27qIeJeyRRHtv/CStLopebe0mYmNsh48BtSnt8fR7QsiJfpCtHKbVkFeX/TRxvylpf8AQ7C19WP91SGZHjPx3GXBMRuamjuEvMNIaEh+0KkStgERFFFTbxaPwNqz/tql/wA8rkqm3i0fgbVn/bVL/nkHr+Fp+BHY3+s1j+kZKtkqm+Fp+BHY3+s1j+kZKtkrQWGWshmsZI8SipWuzWHIEqddVBoMOUIcz1L4uI024LZd20i5m3zFuW5qxN17wXMM+IxFyRObMKdKqNv3cwW3ubj8ptwh/hIjyRKvx/ciasP8YXd//dSN/wCOn9yJqw/xhd3/APdSN/46tlFlx50duVFeB1h0RcBwC3CYl2kJL6FFU80u+H/L04Znq+ZpObZt2z69Blw6kw/RBic9yRIbfJ4iF8vu8xvdt2+ZXDREBVX1a6uMa2HjS8bTovGfdF2zIEykMUilQJD/AC5DgE1ueeEOW2LZF1dW7p2j1K1CIM//AA6dVFiW5gi38NZMj1G0K7bBPx2nalBfbiTo7j7jwvC9s5bfEeZtITIe3cPcr9sSG5TQvNFuBwdwl7Qr+qIKc+JtpwmZ3wOVctakPT7usd0qpTWmG+BOyYpegZUcR83Eh2uCI9REyI+ZTZpYwxDwBgm0sXsg365S4IlU3W/R8bPcInJBbvMPMIhH3RFS0iDzrgr9JtilSK5XJ7UOBEAnH33S2i2PtLFLxL7+a1AZ+hV3GNt3DVaNQKAzRvhDhS5ANyXxffdcJvc2JbfjRHd5tpbenaS2+RBVLQXnKzLowJYmOXZEmlXZblFZpMukVCO7GfIore3mN8wRFwSbHf07tvaXarWoiAq0649JsDVRi5ul091mDeVvuOTLdqDvDaPBwh+MjOEPa25tHq4dpC2XVtISssiCpOmXWBSptIYxBqUnjYeXLbAINShXC6MQavt6QlxniLlvcwerpLu3EO5vaSkfMmr7BmFbedqldvil1SqkPAYNDpMtuXUZzxfJttstkRdRbR3FtH3lIt64yx3kmCFPyHYlAuaK3u2NVemMyxDd7PMEtv5q8ey9P2EMczfhWwcR2db1Q/8APKdRY7D/APvBHd+ktNKo6OdM1/3jmKua1dSlH+Dbtr7hOW5bjo9VIjkOxtxwS6hMWRFtsC6hHcRdRdN8ERZZF80+oRaXEenTngZjR2yeddPjtFtsR9JES+lEGKPiQ5HazLqaod1Y0tquVukWfSolNcnNU18WZkhqU8+5yS29Tfxwju8xCW3cO0i12xblqzMxWqxdNlzjkR3W2yejvtEzJimQ7uW82QiQEPV9np9K7hEBERBkpr/02ZOwTnPhrFwTFljAcnDWKk5DZ3FSakPyjzjfmYe7iIunc44JdwqV8WeMjhqoW+03lqyLkoFebARkFS2G5sJ0vaAicFwd3skJbfaJaIutg8HFtwRIS6SEh7lFdV0paZ63UirFVwBj6VOcLc4+5bkTiThe0XxfUX1lraaVDuXXVlDV9PPC+i7H9cpfwl+56ve1aAWRpEUulxxsWyIWy27trhFzPo2920hvJiuwYuMMeW9j2HVJ1QYt6nR6eMyc8Tj8jltiPMIiIu70dvaPaPSIr2rdte3bRprdGtWg02j09n5OJT4jcZgPqttiIr1VlRERBlBrg0WZVw9lwtVumKHOda9e+Gp0OlN7pNInbtzr7bXzrDhEREO0tu5wSHlqU8E+L3iGuUKNTs+0qo2jcTIi3JmQ4bkunvl7Yi3uebL3CEtvtLQxRxd+nTA9/VFysXrhqyq5UHC3HMn0GK6+f1nCDcX2kTSCah4luBbhmsWrgqBc2VLvqHRTqPRqTIjcHHP8Lz0ltsWWx8zm0to9Sn7Elv3TSKFIrGQZ0eXd9ccGZVvVd3qsQvR8XEi7urkMj0j7ZcxzucJejZGKMa40inDxzj+3rZZe+66NJpjMTm/W5Yju/OXXLTYiIssoE1tafS1K6f63jynEyFdZcbq1Dce47QGczu2iReUXGyca3eXmbvKqmeH3rItfDNqSNLmpef8AsGr1nTHmaZJrAkwyTLjhGUZ5wuG1txtwnCEi2iTZCI9vVpcuFyDg/EGVXGXck4yti5nWB2tPVWlMyXWx9kTIdw8PzkER37rkxE2bVoYRqkfK1/1T4qkUO23fW2ycL5yTJb+JjsD3OERbhHyrNOr2DqDtHxB5pYztzjf+Q7fqEGtVI32nCgFUJMJl2S64Qk36vG50hwW9xDtHlj9bZWxsUY1xjGOHjnH9uWyw98q3SaYzE5v1uWI7vzl7FNt+j0mbUJ9NpcOLJqzwyJr7DAtuSXBbEBccIe8toiO4vKIitDmsS/tvHbDbuan7TK4XuIuOR7aiSG4kYdvyfMkPGTvHd5trf1fMu6RFkFn/AOK5legVXC7uD7ZjT67dM2rxZEiNAhPSBgss/GbnjEdokW5sRHdu6ty0ARBRPws8sW9HwFR8J1pmZRrqoc6ftg1CM4wUtl15ySLjJEPDg5tFziJDw6h5ZF27VexEQFTLxJtIlU1IY2g3PYUQXb4swnnoUcekqlFc286NwL6TpE2/T5hIfnNyuaiDJLSn4oMrBtrxsMakLIuCQFriNOi1GK1wGfHbb6Rjyo7xN/Jj07t27aIiQkXUU4XX4t+Mqs01b2A8XXle931H4qmwX4QsNE8XbuFsnHnPqiPVt7h7lb++cD4XydI4TMh4ptO5ZTY7QkVOjsSHhH2RcId36S+ux8P4pxpwc/a7xtbNscXB2ulSKUxEJz6xNiJF+ctGSK9H+Msu2lb9w5Fz7cz8/IGQpjNSqNNbfIoVGZbb5ceIy3u5YkIl1EPd0juc5fMKw6IsgiIgIiICIiAiIgIiICIiAiIgIiICIiAi4bI2ZMeYmmW7Dv8AuIaUV11NujUji5HeMJM5z0bGtzbZC3u3dzhCPd937i9PIWQbSxVZtSv6+603SaBR2henTHgcIWhIuAj0tiRF1EPD0CPmQdMi5nHeQLSynZ1Nv6wqy1VqDWGyehzGgcEXREuIF0uCJD6CEh9BCPHpXm2HmLHOT6xdFFsa4wqsyzKkVIrjbcV4BiTBIhJrmG2IuEJAXYRf/eKDuERRHmjVZgXT9xYayzkSBRpUoOYxBBtyTLcH2uSyJOCPvEIj7yCXEUI4W1kac8/1PjQ8YZKiVGrABOFTpMd6JJIR7iBt8RJwf3vdt8ym5AReFeV4UDH9rVS9LsqIwKNRYjk6oSibcPkR2x3OObWxIi2j7IqAP/hLtEf/ANOUT/7Fqf8A+2QWcRcBijOeJ83Ul6t4qvuk3HGikLcn1R741gi7ea0XAXG93o6dw8Ny79ARcRWcxY9t7I9BxHV7hFm7bmivTKVTfV3iKSyyJk8XMEOWO0Wy7iHtX98nZUsHDdpSb4yRcsWhUKJxEXZb+4uou0RERInCL2REiQdgi52x71oOQbbp942vKkSaTVmRkwnn4j0YnWePa5y3gBwRLuHcPUPHgQ9PFdEgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiCqXiZWJNu7ShXq7R941ex50O6oDgdzRR3NrpfmsuvF+aos1qZN/b+wjgbFVsv8QkagK1R5EkGi+Sp7YtOyN3s8t55kv4IleS9bWpt9WjW7LrHDdAr1NlUuUO3duZfaJsv0SJZX+HJbt7X9qRpVHvyP8AufTfb9SocbqIhGoSKjJHq3dpct6Q39WM2tQ6TjoayG3gXFWdsP3c+45xwJWqpOa4Ol1HSyF11sh+s4y8X8KKkTwxrNqFB0wQ70r24q1kSs1C6qg4fDqMnneW2X1SbZFz+EVTvEooV6Yy1CVNywIvxGoi14tuyhHcPMnR5sYS2+8TLcZv6r7i1DxzZlPx5YdvWHSeA+p27SotLY9A7dwsNC2JfoodPWrFTYo1KmVaSJE1DYckHwH7+1sdxf8A5KkXh5YxoGWbWq+rzKdIh3FfmQa5OeYlT2hkfBcJl0mgYYE/k+ptwdw/Ni2PaKvHLhszorsOU2LjLwE24HHtIS4ejiKz606ZoougefW9Leo8ptDoMWryp9k3UUNx2FUKc8W7lmTYltcEi3F5RJxwS27R3mki+ITgy0xw3Uc92bSodv5ExqUevUqvU9oWJPEWXg3tOEPyg7S4kO7tIR8pEJWWw9ex5KxTZmRHGgYO5qBT6w40Ha2UiO26Q/m7tqplqe1S23qytg9K2k5+VeddvV6OxWqwxDebp1Epouibzrzjgj3bRH7nTtIurftErv2FZtNx9ZFv2JSS4nAt2lxaTG4lw6iZjtC0O780UZ6RzrO/BPy5+R1U/VyVZ9OWpnQdbuA8e27ft12K1cFPtynxaq1LoZOujKFgRcFwuQW4t27zKzGs/wDBPy5+R1U/mCXEaUsH4auPS/i+o13Elm1GVULQprkt+VQIjrkgijDuIyJvcXEveRpCelqXYWRtel45T020P1DGUWzhpdWnQ6cUCBUKsT7ZDy2SFvq2j7PzZF85uLQpUY0rtBpr1b5O0mcOLkW1LjYG+LHYM/iwbPplMM+n2S3D9WIRK86lSqB6v8p2fhPXdhzKt+TXY1Ft+za68/xab4m45xJmSDbTY/jcNwhEfL1dXER6l4enGC34iWUqtm3OFWiOW5jupep2/jRsiJuC4XUMmeJCPM3bfquE2Q9LbfLLsNSlm2vffiO6f7cvGiQ6tTCt6rS+MSU3zGSeYbkvNEQ+ba422W0unpX+9WVg3XprypF1y4XpxzIzYjDyVbzHSNSpu4R9bEfK4307j8pC24XSLu6pyvEDYt8No/cHyiv9rlsa5DtbK1lUe/7Jqbc+i1yIEyI+Jfd2l98CHymJCQkPlISHyrqVkEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBEXA5yylFwlii48qzqQ7VI9tQymOQ2nuDRvDuEdokQlt7kHfLzadQaPSZMmTTqTCjPTj5kpxiOLZPl93qcIe7j1F9//DxVPKP4gOWa5SYNx03QjlqZSKhGbmRpkNsnxejuDwJtxvaz8YJCXAhU6addTNgalaHU6paEeqUqq2/L9RrlDq8fkT6bI6ul1v0l0ltPaXukPSQkKCT6lQaNVnYsiqUqHLdhOcyM4+wLhMOfc6g3dvHpH73+BekihyytQ8K8dQ2QdPzNryYszH8OnzH6kUkSbljLZbdERb27h28z0d3lQTGvKuK1rau2nlSLqt+m1mAfHcUWoRW5LRF9RwSFeqiDxLXsy0bJhuU+z7WpFDinx3cWKbBajNkXtbWxEV7a5rJN9UXGVh3BkK4z4jS7ep0ipS+I8erlstke0feLbtH3iFRXpH1YWpq4saqXbb9DkUGVRql8HzKXKki68HAmxcbd3CI9LgkW3/K2XsoJvn0+HU4rsGbGakRnhJtxp0OBi4JdwkJJBgw6dEagwY7UeOyItgy0HAAbHh2iIj95fUvNrVapdv0qXW61OZhU+nsOSpcp9zY0wy2O5xwiLtER+76UH+ZFBpMmpM1iRTYjk6OO1mWTI8Xmh6vSIudw8OovtcV6ipc34g9533Jl1LTzpHv7I9qRHnGf2Q8/4NjyibLaXGOJMucz6u4S9oRUxaddVFk6imqxS6ZR61bF22y4LNdtmuR+ROgkXaW3zN7uHEd3Tx9oR3CtNJbeoNHk1BqrP06K7Njjy2pRsCTrQ/jES7h832l9kqKzOYcjSm23WnBIDbMdwkJfiIV9CrLqH1k1LCOWKJh22cHXLkOu1yilWmGaK+PMFsXHQIeXyyItvJItyyysXS6PTKHF9RpFMiwYu7dwYjMC02JF3cdo9K+9U4/u6M7f4vnLv+7L/wABW4o89+p0qHUH4L0J2Uw285Hd+UZIh3E2XvD95B96IiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAq/6/PwOcq/7DL+ebVgFCWtO2LhvbS3ka07TpEuq1ip0cmYcKI1zHn3OYHSI+ZBW3CniD2/aOGLDs8dNuc6rLo9r0mmjIp9rA5GluNRGg5jTnO3E2W3cJbeofKu80T4/yTUcoZf1MZHsWTYzmTJUFul25K+5JjxYzZDwckD5TISDpIRLdzC27SFT5p5pFUoGA8bUGu09+BUqbaFFhzIj4bXWHm4TIuNmPlISEhLh7qkdaaFTbBv/AEk2pH/Yds/qDCuSs/LhuXN+Btb+ZMo23phvfIFBvCDQ4MOXSmyBndHhMC4Qucst3UJD9YVlloGirvhDUvlrKd7/ALF7z0oXtjun8Ibsj4YrLu5jmDt2s/JD1Fu9ryqxCCkPiY5Do8i3rC041C7afbjGTK/HKvVKbKCOzCocZxs33HHHOkdznL27u7lkK4CzcnYVw5r+pB4dyJa9XsPNFGj0OdHotUZktU2sRhFuIRC2RbeZtbbHd3FKe9lSPaOB5mfNXeT8t5/xY3KtC3Yca0rLply0wXY8tlsiN6a228O0h5gkQlt7ZJeyvr1faJccVnBtZnYDxLbluX9b7rNcob9v0hiJLdejGJEyJNiJFub5m0fpOX7K2crlqovim3DVaBo5udqkum1wq86n02U4HcMcnxIvzS5YiXukrB4aum5L0xnbVz3lbU2gV+fTWXKrTJjBMvRpm3a8PLLtHmCW32h2kvK1F4cpOf8ADdzYmrEr1VuvReWxI27vVpDZC4y9t821wALb5h3D5lgdNju06DYlj0OzLXjMsUmiQGIEMGeHoHlthwEeP/r9G7d+Pd6V4MbBuN4eX387QqCUe9ZlKGjSqi1Je4C/F4EJbXGt3LIuhvqId3SPV0qqdhamdU2AbZh4qzTpKv69qrb0cKfCuSzWCqMSqstjtZccIRLlkQiO4i6i7iAS6V2+mi1NQeQM13JqXznSZtkU6fSG6Ha9kOVAnSiR+YJlJktjtEXuku4RL4xzpERFaaW5We+qu+L7x34iGNLnxzjCVkGtx8eym2qFGnDEcebKRLEnOYQkPSPV2rQhUV1QFl3H+tqws7WLge6shUmh2TIpb4UZovQMh16T0k5tIR2i4JbfeWWeXTwtXGrqTLYjyvD0uWIy48IOP8bwYLg2PEuotvq3l++rhqm/93BqI/xe2Uv/AGj/APoVq7QrdQuO16RXqnRJFGm1KBHmSKbI47noTjjYkTDn3B6myLaX1Vpp7qIiyyIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICLnr+vGm49si4L9rAOHAtulTKtKBr5QmY7JOnt97aBKlWNKh4hepmzYWbLTzhZeNKBXhckUW3mqCzUS9XFwhH1h55oiEi2+UvzR7UF9kVadKWcMvXZcN74Z1BWvEp1+WC9H5lSprZDT6zDeHc3IZ3ebbtIh6flB6RLcI2WQEVWNTGpHJFEyVQtNmm+26fW8mXDEKpypVTIvUaFT+31h7b+PpLp+r0mTgiXD122fE0xZSXMhM5jsrKPweBSp1quW83CKQyPUYRnGW2ycc27tokQ/nF0ldLpd9FGGnHOls6i8TUjKNtNORQniTEyC6e52DMb6XmCLzbS7S8wkJeZSeogirTpLzPkHKuQ89W/edUZlwrFv2VQaKLcZtomYbbjoiJEPD4wtoj1F1KyyAiKtGHczZAu/WHnLD9cqjD1s2PGortHjjFbBxkpUYHHtznAdznURdyCy6KvGvLLd9YM0zXHk3HFTZgV+lyaeDDz0Zt8RF6W0250ueke0iU8UN56XSIMqQe916M24Zejb1EIkg+9FG+dqJmmvWOMHA94US2Ln9cbL16rxOex6v1cwduwuounyqlNyXp4jls6g7S06yc/2C7WbvpEqsRpzdut+rNNxxdIhc+J3bi5JdooNHkUN6eLZ1MW3GrfDUdke2rtfkOR/gg6LA9WGM2PM53M+LDdu3N7e7tUyICKtemPNGQMl5z1BWRdtUZlUrH9xw6bQ2m4rbXFhlz1ncJEPDc58mPUXsqyiAiq1qc1K5EtrIFu6ctOttQK5lG6Yx1Anqif7gokASISlP/4S6S2j7vaW4BLhazafib42prt9Rc1WRkx+C36xKtI7ebiC+2Pc3GeZabccc7tu4m93vdq22u+iifTRny3dSeKKZk+3YpwSkmcao095zc5Bmt/ceYIvN6OniJfc3CQltHtUsLDAiz7wtrrvtvV5fWFczSGOFmSrvqlr2lVxhtsNxJ0aSQtRHHBEeZzGybHcXVu5flIiGbteGZ8gYOxlatz46qjMCfU71plFkuOxG3xKK+L/ABcHaf3B+THqQWWREQEREBERAREQEREBERAREQEREBERAREQEREBERBy+Sq3Y9Bsat1DJM6FEtYYbjdXdm/IDFc6HOZ7pbtv5yp1bujzMuO6GxXdE2ribSLPqgDU6TQLghDUqbwZkDzRJl4hc2tlv3dLO7q3ERF1K5d+WRb+RrNrNi3VE9apFegvwJjXp2kTLgkJbS8pdXTx/Eqf2zpw174PpTeO8F6grErdl0/c3SmrxpjozYEfytCTLTnMEfvdRbfZER6RsWO10s6h8w3DlK7NNmo22qNAyDatOZrLVQoZkUKp08ibHm7SItpbnWvZ3by6QIeq1qrhpl0u3Fiu7LozJl3IvG+MnXk0zFqNUbj+rxokNvbtjR2x29PS31bR+Tb2iPVusepkmSkeIXI1M8TzOUOvegalVrVo8ii8XOHykJtiI28Lf8Jt3cB+jL2SV2HXm2g4uO8RER4bi48fxKvepnShxzTWKDk6wL5mWHlC0OBDRLjiNczgTJbt0WQ352i3F9XmOdJCRCUUVvT/AOIRlWjnYWWdR9i0W06g2UeqSLVpj3Cpzo5dzZb2mhb3D3bSEeotwkO4S00+rwwCanWXl+4KLw22zWMo1iVRdvyZx9rXUHu7eWP5pK6q43E2LLQwvYFHxrYlP9To1EY5DA8S3OGW7iTjrheZxwiIiL2i4rsllnFTLQL/AH4NVf8A9ak7+efVzVRWn6T9Z2PMlZKu3CGerItylZCuiZcTsWZR/W3h5zzhNiROMltIRc29PSpywDZuq62atVn9RGXbYvKE+w2FMYpNIGGTD3AvjCMhaHcJDtWmk8KmGnkhZ8RfU3HeLgDz1Ptt4G+PcTfqTXV+kP2lc9VXz1pZyZV8vR9RmmzKECy7+KmfA9VYqcLn06rxx4jt520SISHaI9pfJt7dpDuKq8rxVpDLGiy7WXC4CUioUltsfaL11otv2RL/ALFaq3hMKJAZMOIG3FZEh4+UuWKpq9pR1UZ4ua3OOr3MFnzbKtqqN1gbatKC6LNSkN/J8H3Hm2y29XV3dJEI7SLcN3VEFTHLH/ShYQ/Iis/zcxXOUBXngC4bk1cWBqLi12nM0qz6BOo79PMT9ZfckC+IkBbdu0ecPd/gJSJE+oiKIppom/Cf1b/ljT/+GWrlqBcAYAuDEmXM1ZFq9cp86Hk6uRatBYjcHOZFBvn7hd3cNu744e32VPSCk2ODZpHim5bj1/0Nza3YdLeoJO9PMitjEF8W/a+ObIto/Rl7KuuZCHDcSr1qb0phnGoUHIVlXvLsXJln7uNCuOE1zNoFu3R32/T8YyW4uny8wu4SISies4E8RHJ8Bywcn6j7EpFpzA4x6lNtemO/CkyOXcHU02Le4e7luD3ebtWmn0+Ge6zUIedbioJiVrVbKlWeopN/JG30lub93lkz9lXWXCYexFZ2Dce0fGNiQjjUajM8trgfU684RERvOF5nDIiIv/dw+4u7QZv4p0/2/qTp2rTHVYMYk0suVSbRajw4fGU+oNuO8l/h7vVtLb3CRCo7zdnu4coaZrcxblZlyDlbGOUaDR7oiO98kRCSLU0faFwR6iHp3dXa4CvbpuwHcGFrqy7cFarUCe1kW9Zlzwwi8HN0Zl5wyFpzdw7h3cO3pUV6w9A8fUJka1csWRXqfb1x02VHCslIac5VTismJMkXL+eb27RLzDxEfmxRnlctERZBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERB//9k=";

function cleanText(value: string | null | undefined) {
  if (!value) return "-";
  return value.replace(/\s+/g, " ").trim() || "-";
}

function bulletLines(value: string | null | undefined) {
  return (value || "")
    .split(/\r?\n/)
    .map((line) => line.replace(/^[-*\s]+/, "").trim())
    .filter(Boolean);
}

function formatDateLabel(value: string | null | undefined) {
  if (!value) return "-";
  return formatDateTime(value);
}

function getSelectedPlanLabel(version: ProposalVersion) {
  if (version.executionSection.selectedPlan === "buffered") return "Plan B (Buffered)";
  if (version.executionSection.selectedPlan === "both") return "Plan A + Plan B";
  if (version.executionSection.selectedPlan === "optimal") return "Plan A (Optimal)";
  return "Not Selected";
}

function getIncludedSectionNames(project: ProjectRecord, version: ProposalVersion) {
  const names: string[] = [];
  if (isProposalSectionRenderable(project, version, "consultancyFee")) names.push("Consultancy Fee");
  if (isProposalSectionRenderable(project, version, "workScope")) names.push("Workscope Break-up");
  if (
    isProposalSectionRenderable(project, version, "executionEstimate") ||
    isProposalSectionRenderable(project, version, "timeline") ||
    isProposalSectionRenderable(project, version, "budgetComparison")
  ) {
    names.push("Execution Estimate");
  }
  return names;
}

function createPageControl(doc: jsPDF, project: ProjectRecord, version: ProposalVersion): PageControl {
  const drawChrome = (title: string, pageNumber: number) => {
    fillRect(doc, 0, 0, PAGE_WIDTH, HEADER_HEIGHT, NAVY);
    roundedPanel(doc, PAGE_WIDTH - 202, 16, 166, 72, NAVY_SOFT, NAVY_SOFT);

    doc.addImage(COMPANY_LOGO_DATA_URI, "JPEG", PAGE_MARGIN_X + 6, 18, 56, 64);

    const headerTextX = PAGE_MARGIN_X + 82;
    applyTextColor(doc, WHITE);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(23);
    doc.text(cleanText(project.projectName || "Untitled Project"), headerTextX, 48);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.text(`Prepared for ${cleanText(project.clientName || "Client")}`, headerTextX, 68);

    const infoX = PAGE_WIDTH - 188;
    const infoY = 32;
    const lineGap = 16;
    applyTextColor(doc, WHITE);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text("VERSION", infoX, infoY);
    doc.text("UPDATED", infoX + 78, infoY);
    doc.text("AREA", infoX, infoY + lineGap * 2);
    doc.text("SELECTED PLAN", infoX + 78, infoY + lineGap * 2);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.text(version.versionLabel || "V1", infoX, infoY + 11);
    doc.text(formatDateLabel(version.savedAt || project.lastEditedAt || version.createdAt), infoX + 78, infoY + 11, {
      maxWidth: 72,
    });
    doc.text(`${formatNumber(project.areaSqFt || 0)} SQ.FT`, infoX, infoY + lineGap * 2 + 11);
    doc.text(getSelectedPlanLabel(version), infoX + 78, infoY + lineGap * 2 + 11, { maxWidth: 72 });

    fillRect(doc, 0, PAGE_HEIGHT - 20, PAGE_WIDTH, 20, NAVY);
    applyTextColor(doc, WHITE);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.text(`${cleanText(project.projectName)} | ${version.versionLabel}`, PAGE_MARGIN_X, PAGE_HEIGHT - 7);
    doc.text("Prepared by Molecule Work Place Solution", PAGE_WIDTH / 2, PAGE_HEIGHT - 7, { align: "center" });
    doc.text(`Page ${pageNumber} - ${title}`, PAGE_WIDTH - PAGE_MARGIN_X, PAGE_HEIGHT - 7, { align: "right" });
  };

  return {
    openPage: (title) => {
      drawChrome(title, 1);
      return BODY_TOP;
    },
    nextPage: (title) => {
      doc.addPage();
      drawChrome(title, doc.getNumberOfPages());
      return BODY_TOP;
    },
  };
}

function drawKeyValue(doc: jsPDF, label: string, value: string, x: number, y: number, width: number) {
  applyTextColor(doc, MUTED);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.text(label.toUpperCase(), x, y);
  applyTextColor(doc, TEXT);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  const lines = doc.splitTextToSize(value || "-", width);
  doc.text(lines, x, y + 14);
}

function drawSectionHeading(doc: jsPDF, title: string, y: number) {
  applyTextColor(doc, NAVY);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(15);
  doc.text(title.toUpperCase(), PAGE_MARGIN_X, y);
}

function drawSummaryCard(doc: jsPDF, title: string, value: string, x: number, y: number, width: number, height: number) {
  roundedPanel(doc, x, y, width, height, WHITE);
  applyTextColor(doc, NAVY);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(title.toUpperCase(), x + 14, y + 20, { maxWidth: width - 28 });
  applyTextColor(doc, MUTED);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(7.5);
  doc.text("TOTAL", x + width - 14, y + 20, { align: "right" });
  applyTextColor(doc, NAVY);
  doc.setFontSize(12);
  doc.text(value, x + width - 14, y + 40, { align: "right", maxWidth: width - 28 });
}

function drawCoverPage(doc: jsPDF, project: ProjectRecord, version: ProposalVersion) {
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const showConsultancyFee = isProposalSectionRenderable(project, version, "consultancyFee");
  const showWorkScope = isProposalSectionRenderable(project, version, "workScope");
  const showExecution =
    isProposalSectionRenderable(project, version, "executionEstimate") ||
    isProposalSectionRenderable(project, version, "timeline") ||
    isProposalSectionRenderable(project, version, "budgetComparison");
  const summaryItems: Array<{ title: string; value: string }> = [];

  if (showConsultancyFee) {
    summaryItems.push({ title: "Consultancy Fee", value: formatCurrency(consultancyTotals.grandTotal) });
  }
  if (showWorkScope) {
    const selectedScopeTotal = version.executionSection.selectedPlan === "buffered"
      ? scopeTotals.planBTotalWithTax
      : scopeTotals.planATotalWithTax;
    summaryItems.push({ title: "Workscope Break-up", value: formatCurrency(selectedScopeTotal) });
  }
  if (showExecution) {
    summaryItems.push({ title: "Execution Estimate", value: `${timelineTotals.totalDays} Days` });
  }

  const leftX = PAGE_MARGIN_X;
  const rightX = PAGE_MARGIN_X + 282;
  let cursorY = BODY_TOP + 2;

  drawSectionHeading(doc, "Included Sections - Summary", cursorY);
  cursorY += 12;
  roundedPanel(doc, leftX, cursorY + 10, 250, 220, WHITE);
  summaryItems.forEach((item, index) => {
    drawSummaryCard(doc, item.title, item.value, leftX + 12, cursorY + 24 + index * 62, 226, 50);
  });

  drawSectionHeading(doc, "Proposal Summary", cursorY);
  roundedPanel(doc, rightX, cursorY + 10, 241, 160, WHITE);
  const proposalSummary: Array<[string, string]> = [
    ["Consultancy Fee Total (With Tax)", showConsultancyFee ? formatCurrency(consultancyTotals.grandTotal) : "Not Included"],
    [
      "Workscope Break-up Total (With Tax)",
      showWorkScope
        ? formatCurrency(version.executionSection.selectedPlan === "buffered" ? scopeTotals.planBTotalWithTax : scopeTotals.planATotalWithTax)
        : "Not Included",
    ],
    ["Execution Estimate Total Days", showExecution ? `${timelineTotals.totalDays} Days` : "Not Included"],
  ];
  let summaryY = cursorY + 36;
  proposalSummary.forEach(([label, value], index) => {
    if (index > 0) {
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.line(rightX + 14, summaryY - 10, rightX + 227, summaryY - 10);
    }
    applyTextColor(doc, MUTED);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.text(label, rightX + 14, summaryY, { maxWidth: 155 });
    applyTextColor(doc, NAVY);
    doc.setFontSize(10);
    doc.text(value, rightX + 227, summaryY + 14, { align: "right", maxWidth: 92 });
    summaryY += 40;
  });

  roundedPanel(doc, rightX, cursorY + 178, 241, 52, NAVY, NAVY);
  applyTextColor(doc, GOLD);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("GRAND TOTAL", rightX + 14, cursorY + 208, { maxWidth: 132 });
  applyTextColor(doc, WHITE);
  doc.setFontSize(12);
  const grandTotalLabel = showWorkScope
    ? formatCurrency(version.executionSection.selectedPlan === "buffered" ? scopeTotals.planBTotalWithTax : scopeTotals.planATotalWithTax)
    : showConsultancyFee
      ? formatCurrency(consultancyTotals.grandTotal)
      : `${timelineTotals.totalDays} Days`;
  doc.text(grandTotalLabel, rightX + 223, cursorY + 208, { align: "right", maxWidth: 88 });

  const overviewY = cursorY + 252;
  drawSectionHeading(doc, "Proposal Overview", overviewY);
  roundedPanel(doc, leftX, overviewY + 10, CONTENT_WIDTH, 256, WHITE);
  const columnOneX = leftX + 18;
  const columnTwoX = leftX + 198;
  const columnThreeX = leftX + 378;
  const infoStartY = overviewY + 34;

  drawKeyValue(doc, "Client", cleanText(project.clientName), columnOneX, infoStartY, 150);
  drawKeyValue(doc, "Project", cleanText(project.projectName), columnTwoX, infoStartY, 150);
  drawKeyValue(doc, "Location", cleanText(project.location), columnThreeX, infoStartY, 150);
  drawKeyValue(doc, "Area", `${formatNumber(project.areaSqFt)} SQ.FT`, columnOneX, infoStartY + 48, 150);
  drawKeyValue(doc, "Proposal Date", project.proposalDate || "-", columnTwoX, infoStartY + 48, 150);
  drawKeyValue(doc, "Version", cleanText(version.versionLabel), columnThreeX, infoStartY + 48, 150);
  drawKeyValue(doc, "Updated", formatDateLabel(version.savedAt || project.lastEditedAt), columnOneX, infoStartY + 96, 150);
  drawKeyValue(doc, "Selected Plan", getSelectedPlanLabel(version), columnTwoX, infoStartY + 96, 150);
  drawKeyValue(doc, "Sections Included", getIncludedSectionNames(project, version).join(", "), columnThreeX, infoStartY + 96, 150);

  const includedLines = getIncludedSectionNames(project, version);
  applyTextColor(doc, NAVY);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("Included in this active version", leftX + 18, overviewY + 186);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  includedLines.forEach((line, index) => {
    doc.text(`- ${line}`, leftX + 18, overviewY + 206 + index * 16);
  });
}

function buildScopePlanRows(rows: ScopeSheetRow[], side: "left" | "right") {
  return getScopeRowsForTotals(rows)
    .map((row, index) => {
      const description = side === "left" ? cleanText(row.leftScope || row.groupName) : cleanText(row.rightScope || row.groupName);
      const amount = side === "left" ? row.leftAmount : row.rightAmount;
      if (!amount || amount <= 0) return null;
      return {
        sr: row.leftSerial || row.rightSerial || `${index + 1}`,
        description,
        amount: formatCurrency(amount),
      };
    })
    .filter((row): row is { sr: string; description: string; amount: string } => Boolean(row));
}

function drawTable(
  doc: jsPDF,
  columns: PdfColumn[],
  rows: PdfRow[],
  y: number,
  addPage: (continuationLabel: string) => number,
  continuationLabel: string,
) {
  const rowPaddingY = 10;
  const lineHeightMultiplier = 6.8;
  const headerHeight = 22;
  const minRowHeight = 32;
  const columnLeft = columns.reduce<number[]>((acc, column, index) => {
    if (index === 0) return [PAGE_MARGIN_X];
    acc.push(acc[index - 1] + columns[index - 1].width);
    return acc;
  }, []);

  const drawHeader = (headerY: number) => {
    fillRect(doc, PAGE_MARGIN_X, headerY, CONTENT_WIDTH, headerHeight, NAVY);
    applyTextColor(doc, WHITE);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    columns.forEach((column, index) => {
      const align = column.align === "right" ? "right" : column.align === "center" ? "center" : "left";
      const targetX = align === "right" ? columnLeft[index] + column.width - 8 : align === "center" ? columnLeft[index] + column.width / 2 : columnLeft[index] + 8;
      doc.text(column.header.toUpperCase(), targetX, headerY + 14, { align, maxWidth: column.width - 16 });
    });
  };

  let cursorY = y;
  drawHeader(cursorY);
  cursorY += headerHeight;

  rows.forEach((row, rowIndex) => {
    const cellLines = columns.map((column) => doc.splitTextToSize(row[column.key] || "-", column.width - 16));
    const maxLines = Math.max(...cellLines.map((lines) => lines.length), 1);
    const rowHeight = Math.max(minRowHeight, rowPaddingY + maxLines * lineHeightMultiplier + rowPaddingY);
    if (cursorY + rowHeight > BODY_BOTTOM) {
      cursorY = addPage(continuationLabel);
      drawHeader(cursorY);
      cursorY += headerHeight;
    }

    if (rowIndex % 2 === 0) {
      fillRect(doc, PAGE_MARGIN_X, cursorY, CONTENT_WIDTH, rowHeight, PANEL);
    }

    doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
    doc.line(PAGE_MARGIN_X, cursorY + rowHeight, PAGE_MARGIN_X + CONTENT_WIDTH, cursorY + rowHeight);
    applyTextColor(doc, TEXT);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setLineHeightFactor(1.25);
    columns.forEach((column, index) => {
      const align = column.align === "right" ? "right" : column.align === "center" ? "center" : "left";
      const targetX = align === "right" ? columnLeft[index] + column.width - 8 : align === "center" ? columnLeft[index] + column.width / 2 : columnLeft[index] + 8;
      doc.text(cellLines[index], targetX, cursorY + rowPaddingY + 5, { align, maxWidth: column.width - 16, lineHeightFactor: 1.25 });
    });
    cursorY += rowHeight;
  });

  return cursorY;
}

function drawTaxCard(doc: jsPDF, title: string, values: Array<[string, string]>, x: number, y: number, width: number) {
  const height = 28 + values.length * 22;
  roundedPanel(doc, x, y, width, height, WHITE);
  applyTextColor(doc, NAVY);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text(title.toUpperCase(), x + 14, y + 20);
  let rowY = y + 42;
  values.forEach(([label, value], index) => {
    if (index > 0) {
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.line(x + 14, rowY - 11, x + width - 14, rowY - 11);
    }
    applyTextColor(doc, MUTED);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.text(label, x + 14, rowY);
    applyTextColor(doc, NAVY);
    doc.setFontSize(9);
    doc.text(value, x + width - 14, rowY, { align: "right" });
    rowY += 22;
  });
  return y + height;
}

function drawConsultancyPages(doc: jsPDF, project: ProjectRecord, version: ProposalVersion, pages: PageControl) {
  if (!isProposalSectionRenderable(project, version, "consultancyFee")) return;
  const disciplines = version.consultancySection.disciplines.filter((discipline) => discipline.rows.length > 0);
  if (disciplines.length === 0) return;

  let pageY = pages.nextPage("CONSULTANCY FEE");
  drawSectionHeading(doc, "Consultancy Fee", pageY);
  pageY += 18;
  const continuation = () => {
    const nextY = pages.nextPage("CONSULTANCY FEE");
    drawSectionHeading(doc, "Consultancy Fee", nextY);
    return nextY + 18;
  };

  disciplines.forEach((discipline) => {
    if (pageY + 34 > BODY_BOTTOM) pageY = continuation();
    roundedPanel(doc, PAGE_MARGIN_X, pageY, CONTENT_WIDTH, 28, PANEL_ALT, BORDER);
    applyTextColor(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text(cleanText(discipline.name), PAGE_MARGIN_X + 12, pageY + 18);
    pageY += 38;
    pageY = drawTable(
      doc,
      [
        { key: "deliverable", header: "Deliverables", width: 300 },
        { key: "rate", header: discipline.rateLabel.replace("Rate / ", "").replace("Rate ", ""), width: 70, align: "right" },
        { key: "area", header: discipline.inputLabel.replace(" Input", ""), width: 75, align: "right" },
        { key: "total", header: "Total (PKR)", width: 78, align: "right" },
      ],
      discipline.rows.map((row) => ({
        deliverable: cleanText(row.deliverable),
        rate: formatNumber(row.rate),
        area: formatNumber(row.area),
        total: formatCurrency(row.totalCost),
      })),
      pageY,
      () => continuation(),
      "CONSULTANCY FEE (CONT.)",
    );
    pageY += 16;
  });

  const totals = calculateConsultancyTotals(version.consultancySection, project.taxRate, project.discountRate, project.projectDurationMonths);
  if (pageY + 142 > BODY_BOTTOM) pageY = continuation();
  drawTaxCard(
    doc,
    "Tax Summary",
    [
      ["Services Net Total", formatCurrency(totals.servicesSubtotal)],
      [`SST Tax Rate (${totals.sstRate}%)`, formatCurrency(totals.sstAmount)],
      ["Grand Total Including SST", formatCurrency(totals.grandTotal)],
    ],
    PAGE_MARGIN_X,
    pageY,
    CONTENT_WIDTH,
  );
}

function drawWorkscopePages(doc: jsPDF, project: ProjectRecord, version: ProposalVersion, pages: PageControl) {
  if (!isProposalSectionRenderable(project, version, "workScope")) return;
  const planARows = buildScopePlanRows(version.scopeSection.rows, "left");
  const planBRows = buildScopePlanRows(version.scopeSection.rows, "right");
  if (planARows.length === 0 && planBRows.length === 0) return;

  let pageY = pages.nextPage("WORKSCOPE BREAK-UP");
  drawSectionHeading(doc, "Workscope Break-up", pageY);
  pageY += 18;
  const continuation = () => {
    const nextY = pages.nextPage("WORKSCOPE BREAK-UP");
    drawSectionHeading(doc, "Workscope Break-up", nextY);
    return nextY + 18;
  };

  const renderPlanBlock = (title: string, rows: Array<{ sr: string; description: string; amount: string }>) => {
    if (rows.length === 0) return;
    if (pageY + 34 > BODY_BOTTOM) pageY = continuation();
    roundedPanel(doc, PAGE_MARGIN_X, pageY, CONTENT_WIDTH, 28, PANEL_ALT, BORDER);
    applyTextColor(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text(title.toUpperCase(), PAGE_MARGIN_X + 12, pageY + 18);
    pageY += 38;
    pageY = drawTable(
      doc,
      [
        { key: "sr", header: "Sr. #", width: 52, align: "center" },
        { key: "description", header: "Description", width: 381 },
        { key: "amount", header: "Amount (PKR)", width: 90, align: "right" },
      ],
      rows,
      pageY,
      () => continuation(),
      `${title} (CONT.)`,
    );
    pageY += 16;
  };

  renderPlanBlock("Plan A - Optimal", planARows);
  renderPlanBlock("Plan B - Buffered", planBRows);

  const scopeTotals = calculateScopeTotals(version.scopeSection);
  if (pageY + 166 > BODY_BOTTOM) pageY = continuation();
  const cardWidth = (CONTENT_WIDTH - 16) / 2;
  drawTaxCard(
    doc,
    "Plan A Tax Summary",
    [
      ["Net Total", formatCurrency(scopeTotals.planANetTotal)],
      [`GST Tax (${scopeTotals.gstRate}%)`, formatCurrency(scopeTotals.planATaxAmount)],
      ["Grand Total", formatCurrency(scopeTotals.planATotalWithTax)],
    ],
    PAGE_MARGIN_X,
    pageY,
    cardWidth,
  );
  drawTaxCard(
    doc,
    "Plan B Tax Summary",
    [
      ["Net Total", formatCurrency(scopeTotals.planBNetTotal)],
      [`GST Tax (${scopeTotals.gstRate}%)`, formatCurrency(scopeTotals.planBTaxAmount)],
      ["Grand Total", formatCurrency(scopeTotals.planBTotalWithTax)],
    ],
    PAGE_MARGIN_X + cardWidth + 16,
    pageY,
    cardWidth,
  );
  pageY += 124;

  const negativeListLines = [
    ...bulletLines(isProposalSectionRenderable(project, version, "optimalList") ? version.scopeSection.optimalExclusions : ""),
    ...bulletLines(isProposalSectionRenderable(project, version, "bufferedOptimalList") ? version.scopeSection.bufferedExclusions : ""),
    ...bulletLines(isProposalSectionRenderable(project, version, "negativeList") ? version.scopeSection.note : ""),
  ];
  if (negativeListLines.length > 0) {
    // Calculate height accounting for text wrapping with generous spacing
    let totalBulletHeight = 0;
    const wrappedLines: string[][] = [];
    negativeListLines.forEach((line) => {
      const wrapped = doc.splitTextToSize(`- ${line}`, CONTENT_WIDTH - 28);
      wrappedLines.push(wrapped);
      totalBulletHeight += wrapped.length * 5.2;
    });
    const panelHeight = 36 + totalBulletHeight + 8;
    
    if (pageY + panelHeight > BODY_BOTTOM) pageY = continuation();
    roundedPanel(doc, PAGE_MARGIN_X, pageY, CONTENT_WIDTH, panelHeight, WHITE);
    applyTextColor(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("Negative List / Notes", PAGE_MARGIN_X + 12, pageY + 22);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setLineHeightFactor(1.2);
    let bulletY = pageY + 42;
    wrappedLines.forEach((lines) => {
      doc.text(lines, PAGE_MARGIN_X + 14, bulletY, { maxWidth: CONTENT_WIDTH - 28, lineHeightFactor: 1.2 });
      bulletY += lines.length * 5.2;
    });
  }
}

function drawExecutionPages(doc: jsPDF, project: ProjectRecord, version: ProposalVersion, pages: PageControl) {
  const showExecution =
    isProposalSectionRenderable(project, version, "executionEstimate") ||
    isProposalSectionRenderable(project, version, "timeline") ||
    isProposalSectionRenderable(project, version, "budgetComparison");
  if (!showExecution) return;

  let pageY = pages.nextPage("EXECUTION ESTIMATE");
  drawSectionHeading(doc, "Execution Estimate", pageY);
  pageY += 18;
  const continuation = () => {
    const nextY = pages.nextPage("EXECUTION ESTIMATE");
    drawSectionHeading(doc, "Execution Estimate", nextY);
    return nextY + 18;
  };

  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const hasWorkscope = isProposalSectionRenderable(project, version, "workScope");
  const hasSelectedPlan = Boolean(version.executionSection.selectedPlan);
  const showExecutionSummaryCards = hasWorkscope && hasSelectedPlan;
  const { budgetATotal, budgetBTotal } = getExecutionBudgetTotals(version.executionSection);

  if (showExecutionSummaryCards) {
    const summaryCardWidth = (CONTENT_WIDTH - 24) / 3;
    drawTaxCard(
      doc,
      "Timeline Summary",
      [
        ["Total Days", `${timelineTotals.totalDays} Days`],
        ["Approximate Months", `${timelineTotals.totalMonths} Months`],
        ["Updated", formatDateLabel(version.savedAt || project.lastEditedAt)],
      ],
      PAGE_MARGIN_X,
      pageY,
      summaryCardWidth,
    );
    drawTaxCard(
      doc,
      "Selected Plan",
      [
        ["Plan", getSelectedPlanLabel(version)],
        ["Execution Mode", getExecutionPlanLabel(version.executionSection.selectedPlan)],
        ["Project Area", `${formatNumber(project.areaSqFt)} SQ.FT`],
      ],
      PAGE_MARGIN_X + summaryCardWidth + 12,
      pageY,
      summaryCardWidth,
    );
    drawTaxCard(
      doc,
      "Budget Snapshot",
      [
        ["Plan A", formatCurrency(budgetATotal)],
        ["Plan B", formatCurrency(budgetBTotal)],
        ["Selected Scope", "Imported"],
      ],
      PAGE_MARGIN_X + summaryCardWidth * 2 + 24,
      pageY,
      summaryCardWidth,
    );
    pageY += 124;
  }

  if (version.executionSection.timelineRows.length > 0) {
    pageY = drawTable(
      doc,
      [
        { key: "sr", header: "Sr. #", width: 36, align: "center" },
        { key: "activity", header: "Activity", width: 214 },
        { key: "days", header: "Duration (Days)", width: 66, align: "right" },
        { key: "start", header: "Start", width: 78 },
        { key: "end", header: "End", width: 78 },
        { key: "remarks", header: "Remarks", width: 87 },
      ],
      version.executionSection.timelineRows.map((row, index) => ({
        sr: `${index + 1}`,
        activity: cleanText(row.activity),
        days: `${row.days}`,
        start: cleanText(row.startDate),
        end: cleanText(row.endDate),
        remarks: cleanText(row.remarks || "-"),
      })),
      pageY,
      () => continuation(),
      "EXECUTION ESTIMATE (CONT.)",
    );
    pageY += 16;
  }

  if (hasWorkscope) {
    const showPlanA = version.executionSection.selectedPlan !== "buffered";
    const showPlanB = version.executionSection.selectedPlan === "buffered" || version.executionSection.selectedPlan === "both";
    if (pageY + 120 > BODY_BOTTOM) pageY = continuation();
    roundedPanel(doc, PAGE_MARGIN_X, pageY, CONTENT_WIDTH, 30, PANEL_ALT, BORDER);
    applyTextColor(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.text("Budget Plan Summary (With Tax)", PAGE_MARGIN_X + 12, pageY + 19);
    pageY += 40;

    const budgetColumns: PdfColumn[] = [{ key: "field", header: "Description", width: 200 }];
    if (showPlanA) budgetColumns.push({ key: "planA", header: "Plan A (Optimal)", width: showPlanB ? 161 : 323, align: "right" });
    if (showPlanB) budgetColumns.push({ key: "planB", header: "Plan B (Buffered)", width: 161, align: "right" });
    const scopeTotals = calculateScopeTotals(version.scopeSection);
    pageY = drawTable(
      doc,
      budgetColumns,
      [
        {
          field: "Net Total",
          planA: showPlanA ? formatCurrency(scopeTotals.planANetTotal) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBNetTotal) : "",
        },
        {
          field: `GST @ ${scopeTotals.gstRate}%`,
          planA: showPlanA ? formatCurrency(scopeTotals.planATaxAmount) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBTaxAmount) : "",
        },
        {
          field: "Total With Tax",
          planA: showPlanA ? formatCurrency(scopeTotals.planATotalWithTax) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBTotalWithTax) : "",
        },
      ],
      pageY,
      () => continuation(),
      "EXECUTION ESTIMATE (CONT.)",
    );
  }
}

function drawPaymentSchedulePages(doc: jsPDF, project: ProjectRecord, version: ProposalVersion, pages: PageControl) {
  if (!isProposalSectionRenderable(project, version, "paymentSchedule")) return;

  let pageY = pages.nextPage("PAYMENT SCHEDULE");
  drawSectionHeading(doc, "Payment Schedule", pageY);
  pageY += 18;
  const continuation = () => {
    const nextY = pages.nextPage("PAYMENT SCHEDULE");
    drawSectionHeading(doc, "Payment Schedule", nextY);
    return nextY + 18;
  };

  const summary = calculatePaymentScheduleSummary(version.paymentSchedule);
  drawTaxCard(
    doc,
    "Payment Summary",
    [
      ["Proposal Grand Total", formatCurrency(version.paymentSchedule.grandTotal)],
      ["Allocated Percentage", `${summary.allocatedPercentage}%`],
      ["Total Amount", formatCurrency(summary.totalAmount)],
    ],
    PAGE_MARGIN_X,
    pageY,
    CONTENT_WIDTH,
  );
  pageY += 110;

  pageY = drawTable(
    doc,
    [
      { key: "name", header: "Installment", width: 135 },
      { key: "percentage", header: "Percentage", width: 72, align: "right" },
      { key: "amount", header: "Amount", width: 110, align: "right" },
      { key: "dueDate", header: "Due Date", width: 88, align: "center" },
      { key: "description", header: "Description / Milestone", width: CONTENT_WIDTH - 135 - 72 - 110 - 88 },
    ],
    version.paymentSchedule.rows.map((row) => ({
      name: cleanText(row.name),
      percentage: `${row.percentage}%`,
      amount: formatCurrency(row.amount),
      dueDate: cleanText(row.dueDate || "-"),
      description: cleanText(row.description || "-"),
    })),
    pageY,
    () => continuation(),
    "PAYMENT SCHEDULE (CONT.)",
  );

  if (version.paymentSchedule.notes.trim()) {
    if (pageY + 100 > BODY_BOTTOM) pageY = continuation();
    roundedPanel(doc, PAGE_MARGIN_X, pageY + 12, CONTENT_WIDTH, 76, WHITE);
    applyTextColor(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.text("Payment Notes", PAGE_MARGIN_X + 12, pageY + 34);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setLineHeightFactor(1.2);
    doc.text(doc.splitTextToSize(cleanText(version.paymentSchedule.notes), CONTENT_WIDTH - 24), PAGE_MARGIN_X + 12, pageY + 52, { maxWidth: CONTENT_WIDTH - 24, lineHeightFactor: 1.2 });
  }
}

export function buildProposalPdfTemplate(payload: ProposalSummaryPayload) {
  const { project, version } = payload;
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pages = createPageControl(doc, project, version);
  pages.openPage("COVER / SUMMARY");
  drawCoverPage(doc, project, version);
  drawConsultancyPages(doc, project, version, pages);
  drawWorkscopePages(doc, project, version, pages);
  drawExecutionPages(doc, project, version, pages);
  drawPaymentSchedulePages(doc, project, version, pages);
  return doc.output("blob");
}








