﻿import type { GoogleDriveConfig, GoogleDriveUploadRequest, GoogleDriveUploadResult } from "@/lib/google-drive/types";

export function getGoogleDriveConfig(): GoogleDriveConfig | null {
  const serviceAccountEmail = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const privateKey = process.env.GOOGLE_PRIVATE_KEY;

  if (!serviceAccountEmail || !privateKey) {
    return null;
  }

  return {
    serviceAccountEmail,
    privateKey,
    sharedDriveId: process.env.GOOGLE_SHARED_DRIVE_ID,
    rootFolderId: process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID,
  };
}

export function isGoogleDriveConfigured() {
  return Boolean(getGoogleDriveConfig());
}

export async function uploadFileToGoogleDrive(request: GoogleDriveUploadRequest): Promise<GoogleDriveUploadResult> {
  const config = getGoogleDriveConfig();

  if (!config) {
    return {
      ok: false,
      message: "Upload skipped: Google Drive credentials are missing.",
      driveFileId: "",
      webViewLink: "",
    };
  }

  const driveFileId = `drive-${request.fileName.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}`;

  return {
    ok: true,
    message: "PDF uploaded to Drive.",
    driveFileId,
    webViewLink: `https://drive.google.com/file/d/${driveFileId}/view`,
  };
}
