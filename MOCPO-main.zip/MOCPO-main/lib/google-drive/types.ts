﻿export interface GoogleDriveConfig {
  serviceAccountEmail: string;
  privateKey: string;
  sharedDriveId?: string;
  rootFolderId?: string;
}

export interface GoogleDriveUploadRequest {
  fileName: string;
  mimeType: string;
  folderId?: string;
  dataBase64?: string;
}

export interface GoogleDriveUploadResult {
  ok: boolean;
  message: string;
  driveFileId: string;
  webViewLink: string;
}
