import { jsPDF } from "jspdf";

import {
  calculateConsultancyTotals,
  calculatePaymentScheduleSummary,
  calculateScopeTotals,
  calculateTimelineTotals,
} from "@/lib/calculations";
import { PDF_COVER_LOGO_DATA_URI } from "@/lib/pdf-cover-logo";
import { getSelectedPdfSections, PDF_SECTION_LABELS, type ProposalPdfOptions } from "@/lib/pdf-options";
import { isProposalSectionRenderable } from "@/lib/proposal-sections";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";
import type { ProposalSummaryPayload } from "@/lib/types";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/utils";

const NAVY: [number, number, number] = [9, 34, 79];
const NAVY_SOFT: [number, number, number] = [29, 78, 137];
const GOLD: [number, number, number] = [240, 181, 39];
const TEXT: [number, number, number] = [24, 36, 58];
const MUTED: [number, number, number] = [99, 113, 139];
const BORDER: [number, number, number] = [226, 232, 240];
const PANEL: [number, number, number] = [248, 250, 252];
const WHITE: [number, number, number] = [255, 255, 255];
const MARGIN_X = 45;
const HEADER_HEIGHT = 96;
const FOOTER_HEIGHT = 24;

function color(doc: jsPDF, rgb: [number, number, number]) {
  doc.setTextColor(rgb[0], rgb[1], rgb[2]);
}

function fill(doc: jsPDF, x: number, y: number, w: number, h: number, rgb: [number, number, number]) {
  doc.setFillColor(rgb[0], rgb[1], rgb[2]);
  doc.rect(x, y, w, h, "F");
}

function panel(doc: jsPDF, x: number, y: number, w: number, h: number, fillColor = WHITE) {
  doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
  doc.setFillColor(fillColor[0], fillColor[1], fillColor[2]);
  doc.roundedRect(x, y, w, h, 10, 10, "FD");
}

function clean(value: string | null | undefined) {
  if (!value) return "-";
  return value.replace(/\s+/g, " ").trim() || "-";
}

function formatDate(value: string | null | undefined) {
  if (!value) return "-";
  const formatted = formatDateTime(value);
  return formatted.split(",")[0]?.trim() || formatted;
}

function getSelectedPlanLabel(selectedPlan: ProposalSummaryPayload["version"]["executionSection"]["selectedPlan"]) {
  if (selectedPlan === "optimal") return "Plan A (Optimal)";
  if (selectedPlan === "buffered") return "Plan B (Buffered)";
  if (selectedPlan === "both") return "Plan A + Plan B";
  return "Not Selected";
}

function getImageFormat(dataUrl: string) {
  return dataUrl.includes("image/png") ? "PNG" : "JPEG";
}

function getImageCompression(quality: ProposalPdfOptions["settings"]["imageQuality"]) {
  if (quality === "low") return "FAST" as const;
  if (quality === "medium") return "MEDIUM" as const;
  return "SLOW" as const;
}

export function buildConfiguredProposalPdf(payload: ProposalSummaryPayload, options: ProposalPdfOptions) {
  const { project, version } = payload;
  const doc = new jsPDF({
    unit: "pt",
    format: options.settings.pageSize === "letter" ? "letter" : "a4",
  });
  const width = doc.internal.pageSize.getWidth();
  const height = doc.internal.pageSize.getHeight();
  const contentWidth = width - MARGIN_X * 2;
  const bodyTop = options.settings.showHeaderFooter ? 120 : 56;
  const bodyBottom = height - (options.settings.showHeaderFooter ? FOOTER_HEIGHT + 28 : 38);
  const imageCompression = getImageCompression(options.settings.imageQuality);

  let firstPage = true;

  const openPage = (_pageTitle?: string) => {
    void _pageTitle;
    if (firstPage) {
      firstPage = false;
    } else {
      doc.addPage();
    }

    if (options.settings.showHeaderFooter) {
      fill(doc, 0, 0, width, HEADER_HEIGHT, NAVY);
      panel(doc, width - 234, 16, 194, 68, NAVY_SOFT);

      color(doc, GOLD);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8);
      doc.text("MOLECULE WORK PLACE SOLUTION", MARGIN_X, 24);

      color(doc, WHITE);
      const headerTitle = fitHeaderTitle(project.projectName, 208);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(headerTitle.fontSize);
      doc.text(headerTitle.lines, MARGIN_X, 48, { maxWidth: 208, lineHeightFactor: 1.12 });
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10.25);
      const titleBlockHeight = measureTextHeight(headerTitle.lines, headerTitle.fontSize * 1.12);
      const clientY = 48 + titleBlockHeight + 10;
      doc.text(`Prepared for ${clean(project.clientName)}`, MARGIN_X, Math.min(clientY, 80), { maxWidth: 208 });

      doc.addImage(PDF_COVER_LOGO_DATA_URI, "PNG", width / 2 - 30, 20, 60, 60, undefined, "SLOW");

      const infoX = width - 226;
      const labelLeftX = infoX;
      const valueLeftX = infoX;
      const labelRightX = infoX + 92;
      const valueRightX = infoX + 92;
      color(doc, WHITE);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.text("VERSION", labelLeftX, 32);
      doc.text("UPDATED", labelRightX, 32);
      doc.text("AREA", labelLeftX, 57);
      doc.text("SELECTED PLAN", labelRightX, 57);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8.5);
      doc.text(splitTextLines(clean(version.versionLabel), 84), valueLeftX, 44, { maxWidth: 84, lineHeightFactor: 1.15 });
      doc.text(splitTextLines(formatDate(version.savedAt || project.lastEditedAt || version.createdAt), 84), valueRightX, 44, { maxWidth: 84, lineHeightFactor: 1.15 });
      doc.text(splitTextLines(`${formatNumber(project.areaSqFt)} SQ.FT`, 84), valueLeftX, 69, { maxWidth: 84, lineHeightFactor: 1.15 });
      doc.text(splitTextLines(getSelectedPlanLabel(version.executionSection.selectedPlan), 84), valueRightX, 69, { maxWidth: 84, lineHeightFactor: 1.15 });

      fill(doc, 0, height - FOOTER_HEIGHT - 8, width, FOOTER_HEIGHT + 8, NAVY);
      color(doc, WHITE);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.text("MOCPO Proposal", MARGIN_X, height - 12);
      doc.text(`Version ${clean(version.versionLabel)} | Prepared by Molecule Work Place Solution`, width / 2, height - 12, {
        align: "center",
        maxWidth: 240,
      });
      doc.text(`Page ${doc.getNumberOfPages()}`, width - MARGIN_X, height - 12, { align: "right" });
    } else if (options.settings.showPageNumbers) {
      color(doc, MUTED);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(8);
      doc.text(`Page ${doc.getNumberOfPages()}`, width - MARGIN_X, height - 12, { align: "right" });
    }
  };
  const sectionHeading = (title: string, y: number) => {
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.text(title, MARGIN_X, y);
  };

  const splitTextLines = (value: string, maxWidth: number) => {
    const normalized = clean(value || "-")
      .replace(/\bRs\s+(?=\d)/g, "Rs\u00A0")
      .replace(/(\d{4})-(\d{2})-(\d{2})/g, "$1\u2011$2\u2011$3")
      .replace(/([A-Z])\s*\/\s*([A-Z])/g, "$1\u00A0/\u00A0$2");
    const safeWidth = Math.max(24, maxWidth);
    const paragraphs = normalized.split(/\r?\n/);
    const wrapped = paragraphs.flatMap((paragraph) => {
      const words = paragraph.split(/[ \t]+/).filter(Boolean);
      if (words.length === 0) return ["-"];
      const lines: string[] = [];
      let current = words[0] || "-";
      for (let index = 1; index < words.length; index += 1) {
        const candidate = `${current} ${words[index]}`;
        if (getTextWidth(candidate, 10.25) <= safeWidth) {
          current = candidate;
        } else {
          lines.push(current);
          current = words[index];
        }
      }
      lines.push(current);
      return lines;
    });
    return wrapped.length > 0 ? wrapped : ["-"];
  };

  const measureTextHeight = (lines: string[], lineHeight: number) => Math.max(lineHeight, lines.length * lineHeight);

  const getTextWidth = (value: string, fontSize: number, fontStyle: "normal" | "bold" = "normal") => {
    doc.setFont("helvetica", fontStyle);
    doc.setFontSize(fontSize);
    return doc.getTextWidth(value);
  };

  const getLongestWordWidth = (value: string, fontSize: number, fontStyle: "normal" | "bold" = "normal") => {
    return clean(value)
      .split(/\s+/)
      .reduce((max, word) => Math.max(max, getTextWidth(word, fontSize, fontStyle)), 0);
  };

  const fitHeaderTitle = (value: string, maxWidth: number) => {
    let fontSize = 21;
    let lines: string[] = [];
    while (fontSize >= 14) {
      doc.setFont("helvetica", "bold");
      doc.setFontSize(fontSize);
      lines = splitTextLines(clean(value), maxWidth);
      if (lines.length <= 1 || (lines.length <= 2 && fontSize <= 18)) {
        break;
      }
      fontSize -= 1;
    }
    return { fontSize, lines };
  };

  const resolveTableColumns = (columns: TableColumn[], rows: Array<Record<string, string>>) => {
    const cellPaddingX = 14;
    const resolved = columns.map((column) => ({ ...column }));
    const minimums = resolved.map((column) => {
      const headerWidth = getTextWidth(column.label.toUpperCase(), 9.25, "bold") + cellPaddingX * 2 + 12;
      const contentWidthSamples = rows.length > 0
        ? rows.map((row) => getTextWidth(clean(row[column.key] || "-"), 10.25, column.key === "field" ? "bold" : "normal"))
        : [0];
      const sampleWidth = Math.max(...contentWidthSamples) + cellPaddingX * 2 + 10;
      const longestWordWidth = rows.length > 0
        ? Math.max(...rows.map((row) => getLongestWordWidth(row[column.key] || "-", 10.25, column.key === "field" ? "bold" : "normal"))) + cellPaddingX * 2 + 8
        : 0;
      const isTotalColumn = column.key === "total" || /total/i.test(column.label);
      const isRemarksColumn = column.key === "remarks" || /remarks/i.test(column.label);
      const isDateColumn = column.key === "start" || column.key === "end" || /date/i.test(column.label);
      const isShortValueColumn = ["rate", "area", "days", "percentage", "amount"].includes(column.key);
      const forcedMinimum = isTotalColumn ? 104 : isRemarksColumn ? 150 : isDateColumn ? 92 : isShortValueColumn ? 88 : 64;
      const safeMinimum = column.align === "left"
        ? Math.max(column.width, Math.min(sampleWidth, contentWidth * 0.62), longestWordWidth, Math.min(headerWidth, column.width + 36), forcedMinimum)
        : Math.max(column.width, headerWidth, sampleWidth, longestWordWidth, forcedMinimum);
      const cap = isTotalColumn ? contentWidth * 0.24 : isRemarksColumn ? contentWidth * 0.28 : column.align === "left" ? contentWidth * 0.62 : contentWidth * 0.22;
      return Math.min(Math.max(safeMinimum, forcedMinimum), cap);
    });

    let totalWidth = resolved.reduce((sum, column) => sum + column.width, 0);
    minimums.forEach((minWidth, index) => {
      if (resolved[index].width < minWidth) {
        const deficit = minWidth - resolved[index].width;
        resolved[index].width += deficit;
        totalWidth += deficit;
      }
    });

    if (totalWidth > contentWidth) {
      let overflow = totalWidth - contentWidth;
      const donorIndexes = resolved
        .map((column, index) => ({ index, spare: column.width - minimums[index], align: column.align || "left" }))
        .filter((entry) => entry.spare > 0)
        .sort((a, b) => {
          if (a.align === "left" && b.align !== "left") return -1;
          if (a.align !== "left" && b.align === "left") return 1;
          return b.spare - a.spare;
        });

      donorIndexes.forEach((entry) => {
        if (overflow <= 0) return;
        const reduction = Math.min(entry.spare, overflow);
        resolved[entry.index].width -= reduction;
        overflow -= reduction;
      });
    }

    const adjustedTotal = resolved.reduce((sum, column) => sum + column.width, 0);
    const difference = contentWidth - adjustedTotal;
    if (Math.abs(difference) > 0.5) {
      resolved[resolved.length - 1].width += difference;
    }

    return resolved;
  };

  const drawKeyValue = (label: string, value: string, x: number, y: number, maxWidth = 180) => {
    const valueLines = splitTextLines(value || "-", maxWidth);
    color(doc, MUTED);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8.75);
    doc.text(label.toUpperCase(), x, y);
    color(doc, TEXT);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11.25);
    doc.text(valueLines, x, y + 16, { maxWidth, lineHeightFactor: 1.4 });
  };

  const drawTextBlock = (lines: string[], x: number, y: number, maxWidth: number, lineHeight = 14) => {
    let cursor = y;
    lines.forEach((line) => {
      doc.text(line, x, cursor, { maxWidth });
      cursor += lineHeight;
    });
    return cursor;
  };

  type TableColumn = {
    key: string;
    label: string;
    width: number;
    align?: "left" | "right" | "center";
  };

  type TableLayoutOptions = {
    headerHeight?: number;
    cellPaddingX?: number;
    cellPaddingY?: number;
    lineHeight?: number;
    minRowHeight?: number;
    rowGap?: number;
    fontSize?: number;
    headerFontSize?: number;
  };

  const measureTableRowHeight = (columns: TableColumn[], row: Record<string, string>) => {
    const cellPaddingX = 14;
    const cellPaddingY = 14;
    const lineHeight = 13.5;
    return Math.max(
      52,
      ...columns.map((column) => {
        const lines = splitTextLines(row[column.key] || "", column.width - cellPaddingX * 2);
        return measureTextHeight(lines, lineHeight) + cellPaddingY * 2;
      }),
    );
  };

  const drawSectionLabel = (title: string, y: number, x = MARGIN_X) => {
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text(title, x, y);
  };

  const drawSummaryRows = (params: {
    x: number;
    y: number;
    width: number;
    rows: Array<[string, string, boolean?]>;
    goldLastRow?: boolean;
  }) => {
    let rowY = params.y;
    const labelWidth = Math.max(168, Math.floor(params.width * 0.54));
    const valueWidth = Math.max(120, params.width - labelWidth - 32);
    const lineHeight = 12.5;

    params.rows.forEach(([label, value, emphasize], index) => {
      const isLast = index === params.rows.length - 1;
      const bg = isLast && params.goldLastRow ? GOLD : NAVY;
      const fg = isLast && params.goldLastRow ? NAVY : WHITE;
      const labelLines = splitTextLines(label, labelWidth);
      const valueLines = splitTextLines(value, valueWidth);
      const contentHeight = Math.max(measureTextHeight(labelLines, lineHeight), measureTextHeight(valueLines, lineHeight));
      const rowHeight = Math.max(40, contentHeight + 18);
      fill(doc, params.x, rowY, params.width, rowHeight, bg);
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.rect(params.x, rowY, params.width, rowHeight);
      color(doc, fg);
      doc.setFont("helvetica", emphasize || isLast ? "bold" : "normal");
      doc.setFontSize(10.25);
      const labelStartY = rowY + (rowHeight - measureTextHeight(labelLines, lineHeight)) / 2 + 9;
      const valueStartY = rowY + (rowHeight - measureTextHeight(valueLines, lineHeight)) / 2 + 9;
      doc.text(labelLines, params.x + 12, labelStartY, { maxWidth: labelWidth, lineHeightFactor: 1.35 });
      doc.text(valueLines, params.x + params.width - 12, valueStartY, { align: "right", maxWidth: valueWidth, lineHeightFactor: 1.35 });
      rowY += rowHeight;
    });
    return rowY;
  };

  const drawSectionCardHeader = (kicker: string, title: string, y: number, x = MARGIN_X, width = contentWidth) => {
    panel(doc, x, y, width, 58, WHITE);
    color(doc, MUTED);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text(kicker.toUpperCase(), x + 14, y + 16);
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.text(title, x + 14, y + 36, { maxWidth: width - 28 });
    return y + 72;
  };

  const drawSummaryMetricRow = (y: number, items: Array<[string, string]>) => {
    const gap = 12;
    const perRow = items.length >= 4 ? 2 : items.length;
    const cardWidth = (contentWidth - gap * (perRow - 1)) / perRow;
    let bottomY = y;
    items.forEach(([label, value], index) => {
      const row = Math.floor(index / perRow);
      const column = index % perRow;
      const cardY = y + row * 88;
      const height = drawMetricCard(MARGIN_X + column * (cardWidth + gap), cardY, cardWidth, [[label, value]]);
      bottomY = Math.max(bottomY, cardY + height);
    });
    return bottomY;
  };
  const drawMetricCard = (x: number, y: number, width: number, items: Array<[string, string]>) => {
    const innerPaddingX = 14;
    if (items.length === 1) {
      const [label, value] = items[0];
      const labelLines = splitTextLines(label, width - innerPaddingX * 2);
      const valueLines = splitTextLines(value, width - innerPaddingX * 2);
      const labelHeight = measureTextHeight(labelLines, 11.5);
      const valueHeight = measureTextHeight(valueLines, 15);
      const cardHeight = Math.max(70, 18 + labelHeight + valueHeight + 18);
      panel(doc, x, y, width, cardHeight, WHITE);
      color(doc, MUTED);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.25);
      doc.text(labelLines, x + innerPaddingX, y + 20, { maxWidth: width - innerPaddingX * 2, lineHeightFactor: 1.3 });
      color(doc, NAVY);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.text(valueLines, x + width - innerPaddingX, y + 22 + labelHeight + 14, { align: "right", maxWidth: width - innerPaddingX * 2, lineHeightFactor: 1.15 });
      return cardHeight;
    }

    const labelWidth = Math.max(84, Math.floor(width * 0.42));
    const valueWidth = width - innerPaddingX * 2 - labelWidth - 8;
    const rowHeights = items.map(([label, value]) => {
      const labelLines = splitTextLines(label, labelWidth);
      const valueLines = splitTextLines(value, valueWidth);
      return Math.max(24, Math.max(measureTextHeight(labelLines, 11.5), measureTextHeight(valueLines, 11.5)) + 12);
    });
    const cardHeight = rowHeights.reduce((sum, h) => sum + h, 12);

    panel(doc, x, y, width, cardHeight, WHITE);
    let rowY = y + 6;
    items.forEach(([label, value], index) => {
      const labelLines = splitTextLines(label, labelWidth);
      const valueLines = splitTextLines(value, valueWidth);
      const rowHeight = rowHeights[index];
      if (index > 0) {
        doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
        doc.line(x + 12, rowY, x + width - 12, rowY);
      }
      color(doc, MUTED);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(8.25);
      const labelStartY = rowY + (rowHeight - measureTextHeight(labelLines, 11.5)) / 2 + 8;
      doc.text(labelLines, x + innerPaddingX, labelStartY, { maxWidth: labelWidth, lineHeightFactor: 1.35 });
      color(doc, NAVY);
      doc.setFont("helvetica", index === items.length - 1 ? "bold" : "normal");
      doc.setFontSize(9.75);
      const valueStartY = rowY + (rowHeight - measureTextHeight(valueLines, 11.5)) / 2 + 8;
      doc.text(valueLines, x + width - innerPaddingX, valueStartY, { align: "right", maxWidth: valueWidth, lineHeightFactor: 1.35 });
      rowY += rowHeight;
    });

    return cardHeight;
  };
  const drawGridTable = (params: {
    title: string;
    columns: TableColumn[];
    rows: Array<Record<string, string>>;
    startY: number;
    continuedTitle?: string;
    sectionTitle?: string;
    zebra?: boolean;
    layout?: TableLayoutOptions;
  }) => {
    const continuedTitle = params.continuedTitle || `${params.title} (Continued)`;
    const sectionTitle = params.sectionTitle || params.title;
    const columns = resolveTableColumns(params.columns, params.rows);
    const headerHeight = params.layout?.headerHeight ?? 34;
    const cellPaddingX = params.layout?.cellPaddingX ?? 14;
    const cellPaddingY = params.layout?.cellPaddingY ?? 14;
    const lineHeight = params.layout?.lineHeight ?? 13.5;
    const minRowHeight = params.layout?.minRowHeight ?? 52;
    const rowGap = params.layout?.rowGap ?? 10;
    const fontSize = params.layout?.fontSize ?? 10.25;
    const headerFontSize = params.layout?.headerFontSize ?? 9.25;
    let cursorY = params.startY;

    const firstRowHeight = params.rows[0] ? measureTableRowHeight(columns, params.rows[0]) : minRowHeight;
    if (cursorY + headerHeight + firstRowHeight > bodyBottom) {
      openPage(continuedTitle);
      sectionHeading(sectionTitle, bodyTop);
      cursorY = bodyTop + 28;
    }

    const drawColumnHeader = () => {
      fill(doc, MARGIN_X, cursorY, contentWidth, headerHeight, PANEL);
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.roundedRect(MARGIN_X, cursorY, contentWidth, headerHeight, 10, 10);
      let columnX = MARGIN_X;
      columns.forEach((column, index) => {
        if (index > 0) {
          doc.line(columnX, cursorY, columnX, cursorY + headerHeight);
        }
        color(doc, NAVY);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(headerFontSize);
        const textX = column.align === "right"
          ? columnX + column.width - cellPaddingX
          : column.align === "center"
            ? columnX + column.width / 2
            : columnX + cellPaddingX;
        doc.text(column.label.toUpperCase(), textX, cursorY + 21, {
          align: column.align === "right" ? "right" : column.align === "center" ? "center" : "left",
          maxWidth: Math.max(24, column.width - cellPaddingX * 2),
        });
        columnX += column.width;
      });
      cursorY += headerHeight + rowGap;
    };

    drawColumnHeader();

    params.rows.forEach((row, rowIndex) => {
      const preparedCells = columns.map((column) => {
        const lines = splitTextLines(row[column.key] || "", column.width - cellPaddingX * 2);
        return { column, lines, textHeight: measureTextHeight(lines, lineHeight) };
      });
      const rowHeight = Math.max(minRowHeight, ...preparedCells.map((cell) => cell.textHeight + cellPaddingY * 2));

      if (cursorY + rowHeight > bodyBottom) {
        openPage(continuedTitle);
        sectionHeading(sectionTitle, bodyTop);
        cursorY = bodyTop + 28;
        drawColumnHeader();
      }

      const rowFill = params.zebra !== false && rowIndex % 2 === 1 ? PANEL : WHITE;
      fill(doc, MARGIN_X, cursorY, contentWidth, rowHeight, rowFill);
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.roundedRect(MARGIN_X, cursorY, contentWidth, rowHeight, 10, 10);

      let columnX = MARGIN_X;
      preparedCells.forEach((cell, cellIndex) => {
        if (cellIndex > 0) {
          doc.line(columnX, cursorY, columnX, cursorY + rowHeight);
        }

        const textX = cell.column.align === "right"
          ? columnX + cell.column.width - cellPaddingX
          : cell.column.align === "center"
            ? columnX + cell.column.width / 2
            : columnX + cellPaddingX;

        color(doc, ["deliverable", "description", "activity", "remarks", "field", "name"].includes(cell.column.key) ? TEXT : NAVY);
        doc.setFont("helvetica", cell.column.key === "field" ? "bold" : "normal");
        doc.setFontSize(fontSize);
        const textStartY = cursorY + (rowHeight - cell.textHeight) / 2 + fontSize * 0.7;
        doc.text(cell.lines, textX, textStartY, {
          align: cell.column.align === "right" ? "right" : cell.column.align === "center" ? "center" : "left",
          maxWidth: cell.column.width - cellPaddingX * 2,
          lineHeightFactor: 1.4,
        });

        columnX += cell.column.width;
      });

      cursorY += rowHeight + rowGap;
    });

    return cursorY;
  };
  const consultancyTotals = calculateConsultancyTotals(version.consultancySection, project.taxRate, project.discountRate, project.projectDurationMonths);
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const selectedPlanLabel = getSelectedPlanLabel(version.executionSection.selectedPlan);
  const rawSelectedSections = getSelectedPdfSections(project, version, options);
  const selectedSections = [
    ...rawSelectedSections.filter((key) => key !== "paymentSchedule"),
    ...(rawSelectedSections.includes("paymentSchedule") ? (["paymentSchedule"] as const) : []),
  ];

  const addCoverPage = () => {
    openPage("Cover Page");

    if (options.coverPage.imageDataUrl) {
      doc.addImage(
        options.coverPage.imageDataUrl,
        getImageFormat(options.coverPage.imageDataUrl),
        0,
        0,
        width,
        height,
        undefined,
        imageCompression,
      );
    } else {
      fill(doc, 0, 0, width, height, NAVY);
      fill(doc, 0, height - 170, width, 170, NAVY_SOFT);
    }

    panel(doc, MARGIN_X, 44, width - MARGIN_X * 2, 112);
    doc.addImage(PDF_COVER_LOGO_DATA_URI, "PNG", width - 198, 58, 72, 72, undefined, "SLOW");
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(28);
    doc.text(clean(options.coverPage.projectTitle || project.projectName), MARGIN_X + 32, 96, { maxWidth: width - 320 });
    doc.setFont("helvetica", "normal");
    doc.setFontSize(13);
    doc.text(`Prepared for ${clean(options.coverPage.clientName || project.clientName)}`, MARGIN_X + 32, 122, { maxWidth: width - 320 });
    panel(doc, MARGIN_X, height - 150, 270, 96, NAVY);
    color(doc, WHITE);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9.75);
    doc.text("PROPOSAL DATE", MARGIN_X + 18, height - 120);
    doc.text("PREPARED BY", MARGIN_X + 18, height - 80);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.text(clean(options.coverPage.proposalDate || project.proposalDate || formatDate(version.savedAt || version.createdAt)), MARGIN_X + 18, height - 102);
    doc.text(clean(options.coverPage.preparedBy || "Molecule Work Place Solution"), MARGIN_X + 18, height - 62, {
      maxWidth: 230,
    });
  };
  const addTableOfContents = () => {
    openPage("Table of Contents");
    sectionHeading("Table of Contents", bodyTop);
    panel(doc, MARGIN_X, bodyTop + 18, contentWidth, 420);
    let cursorY = bodyTop + 54;
    selectedSections.filter((key) => key !== "tableOfContents").forEach((key, index) => {
      color(doc, NAVY);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text(`${index + 1}. ${PDF_SECTION_LABELS[key]}`, MARGIN_X + 18, cursorY);
      doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
      doc.line(MARGIN_X + 18, cursorY + 10, width - MARGIN_X - 18, cursorY + 10);
      cursorY += 34;
    });
  };

  const addProjectSummary = () => {
    openPage("Project Summary");

    const scopeGrandTotal = version.executionSection.selectedPlan === "buffered"
      ? scopeTotals.planBTotalWithTax
      : scopeTotals.planATotalWithTax;
    const showConsultancy = isProposalSectionRenderable(project, version, "consultancyFee");
    const showWorkScope = isProposalSectionRenderable(project, version, "workScope");
    const showExecution =
      isProposalSectionRenderable(project, version, "executionEstimate") ||
      isProposalSectionRenderable(project, version, "timeline") ||
      isProposalSectionRenderable(project, version, "budgetComparison");
    const grandTotalValue = showWorkScope
      ? formatCurrency(scopeGrandTotal)
      : showConsultancy
        ? formatCurrency(consultancyTotals.grandTotal)
        : `${timelineTotals.totalDays} Days`;
    const cardWidth = (contentWidth - 24) / 2;

    drawSectionLabel("Proposal Overview", bodyTop + 10);
    panel(doc, MARGIN_X, bodyTop + 30, cardWidth, 248, WHITE);
    const infoLeftX = MARGIN_X + 18;
    const infoTopY = bodyTop + 58;
    const infoGap = 22;
    const infoColWidth = Math.floor((cardWidth - 36 - infoGap) / 2);
    const infoRightX = infoLeftX + infoColWidth + infoGap;
    const overviewPairs: Array<[[string, string], [string, string]]> = [
      [["Client", clean(project.clientName)], ["Proposal Date", clean(project.proposalDate)]],
      [["Project", clean(project.projectName)], ["Version", clean(version.versionLabel)]],
      [["Location", clean(project.location)], ["Updated", formatDate(version.savedAt || project.lastEditedAt)]],
      [["Area", `${formatNumber(project.areaSqFt)} SQ.FT`], ["Selected Plan", selectedPlanLabel]],
    ];
    let infoCursorY = infoTopY;
    overviewPairs.forEach(([leftItem, rightItem]) => {
      const leftLines = splitTextLines(leftItem[1], infoColWidth);
      const rightLines = splitTextLines(rightItem[1], infoColWidth);
      const leftHeight = 16 + measureTextHeight(leftLines, 15);
      const rightHeight = 16 + measureTextHeight(rightLines, 15);
      drawKeyValue(leftItem[0], leftItem[1], infoLeftX, infoCursorY, infoColWidth);
      drawKeyValue(rightItem[0], rightItem[1], infoRightX, infoCursorY, infoColWidth);
      infoCursorY += Math.max(leftHeight, rightHeight) + 20;
    });
    drawSectionLabel("Proposal Totals", bodyTop + 10, MARGIN_X + cardWidth + 24);
    panel(doc, MARGIN_X + cardWidth + 24, bodyTop + 30, cardWidth, 214, WHITE);
    let totalsY = bodyTop + 68;
    const totalsX = MARGIN_X + cardWidth + 38;
    const totalsRight = MARGIN_X + cardWidth + 24 + cardWidth - 18;
    const summaryRows = [
      ["Consultancy Fee Total (With Tax)", showConsultancy ? formatCurrency(consultancyTotals.grandTotal) : "Not Included"],
      ["Work Scope Total (Selected Budget With Tax)", showWorkScope ? formatCurrency(scopeGrandTotal) : "Not Included"],
      ["Execution Timeline Total Days", showExecution ? `${timelineTotals.totalDays} Days` : "Not Included"],
      ["Grand Total Proposal Amount", grandTotalValue],
    ];
    summaryRows.forEach(([label, value], index) => {
      if (index > 0) {
        doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
        doc.line(totalsX, totalsY - 16, totalsRight, totalsY - 16);
      }
      color(doc, MUTED);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(9.75);
      doc.text(label, totalsX, totalsY, { maxWidth: cardWidth - 130 });
      color(doc, NAVY);
      doc.setFont("helvetica", index === 3 ? "bold" : "normal");
      doc.setFontSize(index === 3 ? 13 : 10.5);
      doc.text(splitTextLines(value, 156), totalsRight, totalsY + 16, { align: "right", maxWidth: 156, lineHeightFactor: 1.15 });
      totalsY += 46;
    });

    const illustrationImage = options.coverPage.imageDataUrl || options.imagesPage.items[0]?.dataUrl || "";
    if (illustrationImage) {
      drawSectionLabel("Project Illustration", bodyTop + 278);
      panel(doc, MARGIN_X, bodyTop + 298, contentWidth, 250, PANEL);
      doc.addImage(
        illustrationImage,
        getImageFormat(illustrationImage),
        MARGIN_X + 12,
        bodyTop + 310,
        contentWidth - 24,
        226,
        undefined,
        imageCompression,
      );
    }
  };
  const addConsultancyFee = () => {
    openPage("Consultancy Fee");
    let cursorY = drawSectionCardHeader("Consultancy", "Consultancy Fee", bodyTop);

    cursorY = drawSummaryMetricRow(cursorY, [
      ["Services Net Total", formatCurrency(consultancyTotals.servicesSubtotal)],
      ["SST Amount", formatCurrency(consultancyTotals.sstAmount)],
      ["Amount With Tax", formatCurrency(consultancyTotals.grandTotal)],
    ]) + 16;

    const continuation = () => {
      openPage("Consultancy Fee (Continued)");
      return drawSectionCardHeader("Consultancy", "Consultancy Fee Continued", bodyTop);
    };

    version.consultancySection.disciplines
      .filter((discipline) => discipline.rows.length > 0)
      .forEach((discipline) => {
        const tableRows = discipline.rows.map((row) => ({
          deliverable: clean(row.deliverable),
          rate: formatNumber(row.rate),
          area: formatNumber(row.area),
          total: formatCurrency(row.totalCost),
        }));
        const firstRowHeight = tableRows[0]
          ? measureTableRowHeight(
              [
                { key: "deliverable", label: "Deliverables", width: 286 },
                { key: "rate", label: discipline.rateLabel.replace("Rate / ", "").replace("Rate ", ""), width: 80, align: "right" },
                { key: "area", label: discipline.inputLabel.replace(" Input", ""), width: 80, align: "right" },
                { key: "total", label: "Total (PKR)", width: 104, align: "right" },
              ],
              tableRows[0],
            )
          : 42;
        if (cursorY + 34 + firstRowHeight > bodyBottom) cursorY = continuation();

        fill(doc, MARGIN_X, cursorY, contentWidth, 32, PANEL);
        doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
        doc.roundedRect(MARGIN_X, cursorY, contentWidth, 32, 10, 10);
        color(doc, NAVY);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text(clean(discipline.name), MARGIN_X + 14, cursorY + 21);
        cursorY += 46;

        cursorY = drawGridTable({
          title: "Consultancy Fee",
          sectionTitle: "Consultancy Fee",
          continuedTitle: "Consultancy Fee (Continued)",
          startY: cursorY,
          columns: [
            { key: "deliverable", label: "Deliverables", width: 286 },
            { key: "rate", label: discipline.rateLabel.replace("Rate / ", "").replace("Rate ", ""), width: 80, align: "right" },
            { key: "area", label: discipline.inputLabel.replace(" Input", ""), width: 80, align: "right" },
            { key: "total", label: "Total (PKR)", width: 104, align: "right" },
          ],
          rows: tableRows,
          zebra: true,
        });
        cursorY += 16;
      });

    cursorY += 6;
    if (cursorY + 150 > bodyBottom) cursorY = continuation();
    drawSummaryRows({
      x: MARGIN_X,
      y: cursorY,
      width: contentWidth,
      goldLastRow: true,
      rows: [
        ["Services Net Total", formatCurrency(consultancyTotals.servicesSubtotal)],
        [`SST Tax Rate (${consultancyTotals.sstRate}%)`, formatCurrency(consultancyTotals.sstAmount)],
        ["Grand Total Including SST", formatCurrency(consultancyTotals.grandTotal), true],
      ],
    });
  };
  const addWorkScope = () => {
    openPage("Work Scope Break-up");
    let cursorY = drawSectionCardHeader("Scope", "Work Scope", bodyTop);
    const rows = getScopeRowsForTotals(version.scopeSection.rows);
    const selectedPlan = version.executionSection.selectedPlan;

    const continuation = () => {
      openPage("Work Scope Break-up (Continued)");
      return drawSectionCardHeader("Scope", "Work Scope Continued", bodyTop);
    };

    const scopeCards = rows
      .map((row) => {
        const parts = [
          selectedPlan !== "buffered" ? clean(row.leftScope || "") : "",
          selectedPlan !== "optimal" ? clean(row.rightScope || "") : "",
        ].filter((value) => value && value !== "-");
        return {
          title: clean(row.groupName),
          body: Array.from(new Set(parts)).join("\n"),
        };
      })
      .filter((card) => card.title !== "-" && card.body);

    const renderScopeCard = (title: string, body: string) => {
      const bodyLines = doc.splitTextToSize(body, (contentWidth - 52) / 2);
      const cardHeight = Math.max(96, 42 + bodyLines.length * 13);
      return { bodyLines, cardHeight };
    };

    for (let index = 0; index < scopeCards.length; index += 2) {
      const left = scopeCards[index];
      const right = scopeCards[index + 1];
      const leftBlock = renderScopeCard(left.title, left.body);
      const rightBlock = right ? renderScopeCard(right.title, right.body) : null;
      const rowHeight = Math.max(leftBlock.cardHeight, rightBlock?.cardHeight || 0);
      if (cursorY + rowHeight > bodyBottom) cursorY = continuation();
      const cardWidth = (contentWidth - 12) / 2;

      panel(doc, MARGIN_X, cursorY, cardWidth, rowHeight, WHITE);
      color(doc, NAVY);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(11);
      doc.text(left.title, MARGIN_X + 14, cursorY + 24);
      color(doc, TEXT);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9.5);
      doc.text(leftBlock.bodyLines, MARGIN_X + 14, cursorY + 44, { maxWidth: cardWidth - 28, lineHeightFactor: 1.35 });

      if (right && rightBlock) {
        panel(doc, MARGIN_X + cardWidth + 12, cursorY, cardWidth, rowHeight, WHITE);
        color(doc, NAVY);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(11);
        doc.text(right.title, MARGIN_X + cardWidth + 26, cursorY + 24);
        color(doc, TEXT);
        doc.setFont("helvetica", "normal");
        doc.setFontSize(9.5);
        doc.text(rightBlock.bodyLines, MARGIN_X + cardWidth + 26, cursorY + 44, { maxWidth: cardWidth - 28, lineHeightFactor: 1.35 });
      }

      cursorY += rowHeight + 12;
    }

    const noteCards = [
      { title: version.scopeSection.exclusionsTitle || "Negative List", body: clean(version.scopeSection.note) },
      { title: "Optimal List", body: clean(version.scopeSection.optimalExclusions) },
      { title: "Buffered Optimal List", body: clean(version.scopeSection.bufferedExclusions) },
    ].filter((card) => card.body && card.body !== "-");

    noteCards.forEach((card) => {
      const lines = doc.splitTextToSize(card.body, contentWidth - 28);
      const height = Math.max(88, 42 + lines.length * 13);
      if (cursorY + height > bodyBottom) cursorY = continuation();
      panel(doc, MARGIN_X, cursorY, contentWidth, height, WHITE);
      color(doc, MUTED);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(7.5);
      doc.text("SCOPE", MARGIN_X + 14, cursorY + 16);
      color(doc, NAVY);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text(card.title, MARGIN_X + 14, cursorY + 36);
      color(doc, TEXT);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(9.5);
      doc.text(lines, MARGIN_X + 14, cursorY + 58, { maxWidth: contentWidth - 28, lineHeightFactor: 1.35 });
      cursorY += height + 12;
    });

    const summaryItems: Array<[string, string]> = [];
    if (selectedPlan !== "buffered") {
      summaryItems.push(["Plan A Total Amount", formatCurrency(scopeTotals.planANetTotal)]);
      summaryItems.push(["Plan A With Tax", formatCurrency(scopeTotals.planATotalWithTax)]);
    }
    if (selectedPlan !== "optimal") {
      summaryItems.push(["Plan B Total Amount", formatCurrency(scopeTotals.planBNetTotal)]);
      summaryItems.push(["Plan B With Tax", formatCurrency(scopeTotals.planBTotalWithTax)]);
    }
    if (summaryItems.length > 0) {
      if (cursorY + 60 > bodyBottom) cursorY = continuation();
      cursorY = drawSummaryMetricRow(cursorY, summaryItems) + 8;
    }
  };
  const addExecutionEstimate = () => {
    openPage("Execution Estimate");
    let cursorY = drawSectionCardHeader("Execution", "Execution Estimate", bodyTop);

    const continuation = () => {
      openPage("Execution Estimate (Continued)");
      return drawSectionCardHeader("Execution", "Execution Estimate Continued", bodyTop);
    };

    const showPlanA = version.executionSection.selectedPlan !== "buffered";
    const showPlanB = version.executionSection.selectedPlan === "buffered" || version.executionSection.selectedPlan === "both";
    const topSummaryWidth = (contentWidth - 12) / 2;
    const topSummaryHeight = drawMetricCard(MARGIN_X, cursorY, topSummaryWidth, [
      ["Total Days", `${timelineTotals.totalDays} Days`],
      ["Approximate Months", `${timelineTotals.totalMonths} Months`],
      ["Updated", formatDate(version.savedAt || project.lastEditedAt)],
    ]);
    drawMetricCard(MARGIN_X + topSummaryWidth + 12, cursorY, topSummaryWidth, [
      ["Plan", selectedPlanLabel],
      ["Execution Mode", selectedPlanLabel],
      ["Project Area", `${formatNumber(project.areaSqFt)} SQ.FT`],
    ]);
    cursorY += topSummaryHeight + 12;

    const scopeSummaryHeight = drawMetricCard(MARGIN_X, cursorY, contentWidth, [
      ["Plan A", formatCurrency(scopeTotals.planATotalWithTax)],
      ["Plan B", formatCurrency(scopeTotals.planBTotalWithTax)],
      ["Selected Scope", showPlanB && !showPlanA ? "Plan B" : showPlanA && !showPlanB ? "Plan A" : "Both"],
    ]);
    cursorY += scopeSummaryHeight + 18;

    cursorY = drawGridTable({
      title: "Execution Estimate",
      sectionTitle: "Execution Estimate",
      continuedTitle: "Execution Estimate (Continued)",
      startY: cursorY,
      columns: [
        { key: "sr", label: "Sr. #", width: 28, align: "center" },
        { key: "activity", label: "Activity", width: 268 },
        { key: "days", label: "Duration (Days)", width: 72, align: "center" },
        { key: "start", label: "Start", width: 118, align: "center" },
        { key: "end", label: "End", width: 118, align: "center" },
      ],
      rows: version.executionSection.timelineRows.map((row, index) => ({
        sr: `${index + 1}`,
        activity: clean(row.activity),
        days: `${row.days}`,
        start: clean(row.startDate),
        end: clean(row.endDate),
      })),
      layout: {
        headerHeight: 30,
        cellPaddingY: 10,
        lineHeight: 12,
        minRowHeight: 40,
        rowGap: 6,
        fontSize: 9.25,
        headerFontSize: 8.75,
      },
    });
    cursorY += 20;

    if (cursorY + 126 > bodyBottom) cursorY = continuation();
    fill(doc, MARGIN_X, cursorY, contentWidth, 32, PANEL);
    doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
    doc.roundedRect(MARGIN_X, cursorY, contentWidth, 32, 10, 10);
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(12);
    doc.text("Budget Plan Summary (With Tax)", MARGIN_X + 14, cursorY + 21);
    cursorY += 44;

    const columns: TableColumn[] = [{ key: "field", label: "Description", width: 180 }];
    if (showPlanA) { columns.push({ key: "planA", label: "Plan A (Optimal)", width: showPlanB ? 162.5 : 325, align: "right" }); }
    if (showPlanB) { columns.push({ key: "planB", label: "Plan B (Buffered)", width: 162.5, align: "right" }); }
    cursorY = drawGridTable({
      title: "Execution Estimate",
      sectionTitle: "Execution Estimate",
      continuedTitle: "Execution Estimate (Continued)",
      startY: cursorY,
      columns,
      rows: [
        {
          field: "Net Total",
          planA: showPlanA ? formatCurrency(scopeTotals.planANetTotal) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBNetTotal) : "",
        },
        {
          field: `GST @ ${scopeTotals.gstRate}%`,
          planA: showPlanA ? formatCurrency(scopeTotals.planATaxAmount) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBTaxAmount) : "",
        },
        {
          field: "Total With Tax",
          planA: showPlanA ? formatCurrency(scopeTotals.planATotalWithTax) : "",
          planB: showPlanB ? formatCurrency(scopeTotals.planBTotalWithTax) : "",
        },
      ],
    });
  };
  const addPaymentSchedule = () => {
    openPage("Payment Schedule");
    sectionHeading("Payment Schedule", bodyTop);
    let cursorY = bodyTop + 24;
    const paymentSummary = calculatePaymentScheduleSummary(version.paymentSchedule);

    drawSummaryRows({
      x: MARGIN_X,
      y: cursorY,
      width: contentWidth,
      rows: [
        ["Proposal Grand Total", formatCurrency(version.paymentSchedule.grandTotal)],
        ["Total Percentage", `${paymentSummary.allocatedPercentage}%`],
        ["Total Amount", formatCurrency(paymentSummary.totalAmount), true],
      ],
      goldLastRow: true,
    });
    cursorY += 108;

    cursorY = drawGridTable({
      title: "Payment Schedule",
      continuedTitle: "Payment Schedule (Continued)",
      startY: cursorY,
      columns: [
        { key: "name", label: "Installment", width: 96 },
        { key: "percentage", label: "Percentage", width: 72, align: "center" },
        { key: "amount", label: "Amount", width: 128, align: "right" },
        { key: "dueDate", label: "Due Date", width: 66, align: "center" },
        { key: "description", label: "Description / Milestone", width: contentWidth - 96 - 72 - 128 - 66 },
      ],
      rows: version.paymentSchedule.rows.map((row) => ({
        name: clean(row.name),
        percentage: `${row.percentage}%`,
        amount: formatCurrency(row.amount),
        dueDate: clean(row.dueDate || "-"),
        description: clean(row.description || "-"),
      })),
    });

    if (version.paymentSchedule.notes.trim()) {
      const lines = doc.splitTextToSize(version.paymentSchedule.notes.trim(), contentWidth - 24);
      const noteHeight = Math.max(84, 28 + lines.length * 14);
      if (cursorY + noteHeight + 18 > bodyBottom) {
        openPage("Payment Schedule (Continued)");
        sectionHeading("Payment Schedule", bodyTop);
        cursorY = bodyTop + 24;
      }
      panel(doc, MARGIN_X, cursorY + 18, contentWidth, noteHeight);
      color(doc, NAVY);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(12);
      doc.text("Payment Notes", MARGIN_X + 16, cursorY + 42);
      color(doc, TEXT);
      doc.setFont("helvetica", "normal");
      doc.setFontSize(10.25);
      drawTextBlock(lines, MARGIN_X + 16, cursorY + 64, contentWidth - 32);
    }
  };

  const addImagesPage = () => {
    const itemsPerPage = options.imagesPage.layout === "four-up" ? 4 : options.imagesPage.layout === "two-up" ? 2 : 1;
    for (let index = 0; index < options.imagesPage.items.length; index += itemsPerPage) {
      openPage("Project Images");
      sectionHeading("Project Images", bodyTop);
      const items = options.imagesPage.items.slice(index, index + itemsPerPage);
      if (itemsPerPage === 1) {
        const item = items[0];
        const imageHeight = options.imagesPage.layout === "full-width" ? 360 : 300;
        doc.addImage(item.dataUrl, getImageFormat(item.dataUrl), MARGIN_X, bodyTop + 26, contentWidth, imageHeight, undefined, imageCompression);
        color(doc, NAVY);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(12);
        doc.text(clean(item.caption || item.name), MARGIN_X, bodyTop + 26 + imageHeight + 22, { maxWidth: contentWidth });
        continue;
      }

      const cardWidth = (contentWidth - 16) / 2;
      const cardHeight = itemsPerPage === 2 ? 280 : 180;
      items.forEach((item, itemIndex) => {
        const column = itemIndex % 2;
        const row = Math.floor(itemIndex / 2);
        const x = MARGIN_X + column * (cardWidth + 16);
        const y = bodyTop + 26 + row * (cardHeight + 42);
        panel(doc, x, y, cardWidth, cardHeight + 34);
        doc.addImage(item.dataUrl, getImageFormat(item.dataUrl), x + 10, y + 10, cardWidth - 20, cardHeight - 20, undefined, imageCompression);
        color(doc, NAVY);
        doc.setFont("helvetica", "bold");
        doc.setFontSize(10.25);
        doc.text(clean(item.caption || item.name), x + 10, y + cardHeight + 22, { maxWidth: cardWidth - 20 });
      });
    }
  };

  const addTextPage = (title: string, subtitle: string, paragraphs: string[]) => {
    openPage(title);
    sectionHeading(title, bodyTop);
    panel(doc, MARGIN_X, bodyTop + 22, contentWidth, Math.min(520, bodyBottom - bodyTop - 24));
    color(doc, MUTED);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.text(subtitle, MARGIN_X + 18, bodyTop + 52, { maxWidth: contentWidth - 36 });
    color(doc, TEXT);
    doc.setFontSize(10.25);
    let cursorY = bodyTop + 86;
    paragraphs.forEach((paragraph) => {
      const lines = doc.splitTextToSize(clean(paragraph), contentWidth - 36);
      cursorY = drawTextBlock(lines, MARGIN_X + 18, cursorY, contentWidth - 36, 14) + 12;
    });
  };

  const addSignaturePage = () => {
    openPage("Signature Page");
    sectionHeading("Signature Page", bodyTop);
    panel(doc, MARGIN_X, bodyTop + 22, contentWidth, 340);
    color(doc, MUTED);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(12);
    doc.text("Sign below to confirm proposal acceptance and authorize the next coordination stage.", MARGIN_X + 18, bodyTop + 52, {
      maxWidth: contentWidth - 36,
    });
    doc.setDrawColor(BORDER[0], BORDER[1], BORDER[2]);
    doc.line(MARGIN_X + 18, bodyTop + 180, MARGIN_X + 230, bodyTop + 180);
    doc.line(MARGIN_X + 318, bodyTop + 180, MARGIN_X + 530, bodyTop + 180);
    color(doc, NAVY);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10.25);
    doc.text(clean(project.clientName || "Client Representative"), MARGIN_X + 18, bodyTop + 200);
    doc.text(clean(options.coverPage.preparedBy || "Prepared By"), MARGIN_X + 318, bodyTop + 200);
    color(doc, MUTED);
    doc.setFont("helvetica", "normal");
    doc.text("Client Signature", MARGIN_X + 18, bodyTop + 218);
    doc.text("Prepared By", MARGIN_X + 318, bodyTop + 218);
  };

  selectedSections.forEach((section) => {
    switch (section) {
      case "coverPage":
        addCoverPage();
        break;
      case "tableOfContents":
        addTableOfContents();
        break;
      case "projectSummary":
        addProjectSummary();
        break;
      case "consultancyFee":
        addConsultancyFee();
        break;
      case "workScopeBreakup":
        addWorkScope();
        break;
      case "projectImages":
        addImagesPage();
        break;
      case "executionEstimate":
        addExecutionEstimate();
        break;
      case "paymentSchedule":
        addPaymentSchedule();
        break;
      case "companyProfile":
        addTextPage("Company Profile", "A concise overview of the team behind this proposal.", [
          `${"Molecule Work Place Solution"} prepares coordinated commercial and technical proposals for workplace, infrastructure, and built-environment projects.`,
          `This proposal package has been configured for ${project.clientName || "the client"} and reflects the active commercial assumptions, scope lines, and execution planning currently stored in the app.`,
          "Our process prioritizes clarity, presentable documentation, and decision-ready reporting from early proposal issue through execution planning.",
        ]);
        break;
      case "teamPage":
        addTextPage("Team Page", "Suggested delivery structure for client review.", [
          "Project Lead: Oversees client communication, major coordination decisions, and proposal alignment.",
          "Technical Coordination: Consolidates consultancy scope, work scope break-up, and execution sequencing into a single decision-ready pack.",
          "Commercial Support: Maintains costing logic, tax assumptions, and issue control before final release.",
        ]);
        break;
      case "termsAndConditions":
        addTextPage("Terms & Conditions", "Commercial notes for proposal issuance.", [
          "All pricing, durations, and assumptions in this proposal are based on the current project version and may require reconfirmation if the scope changes.",
          "Authority fees, third-party approvals, specialist testing, and any items not expressly included in the selected sections should be treated as excluded unless agreed in writing.",
          "This proposal should be reviewed together with the included consultancy, scope, and execution pages before approval or mobilization.",
        ]);
        break;
      case "signaturePage":
        addSignaturePage();
        break;
      default:
        break;
    }
  });

  return doc.output("blob");
}












































