// ===========================
// MOCPO Google Apps Script Backend
// ===========================
// Deploy as Web App:
// Execute as: Me
// Who has access: Anyone
//
// Paste the deployed Web App URL into your Next.js .env.local:
// NEXT_PUBLIC_APPS_SCRIPT_URL=https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec
//
// Saves into:
// TARGET_PARENT_FOLDER_ID / Client Name / Project Name / Version X / files

const TARGET_PARENT_FOLDER_ID = "1qav5vUFnVdcZLbXb_noxSJhmNrLzcIbS";

function doGet(e) {
  try {
    const action = e.parameter.action;

    if (action === "testConnection") {
      return handleTestConnection();
    }

    if (action === "listClients") {
      return handleListClients();
    }

    if (action === "listProjects") {
      return handleListProjects(e.parameter.clientName);
    }

    if (action === "listVersions") {
      return handleListVersions(e.parameter.clientName, e.parameter.projectName);
    }

    if (action === "getVersionData") {
      return handleGetVersionData(
        e.parameter.clientName,
        e.parameter.projectName,
        e.parameter.versionNumber
      );
    }

    return sendJson({ success: false, error: "Unknown GET action" });
  } catch (error) {
    return sendJson({ success: false, error: error.message || error.toString() });
  }
}

function doPost(e) {
  try {
    if (!e || !e.postData || !e.postData.contents) {
      return sendJson({ success: false, error: "Missing POST body" });
    }

    const payload = JSON.parse(e.postData.contents);
    const action = payload.action;

    if (action === "saveProposalFiles") {
      return handleSaveProposalFiles(payload);
    }

    if (action === "saveVersion") {
      return handleSaveVersion(payload);
    }

    return sendJson({ success: false, error: "Unknown POST action" });
  } catch (error) {
    return sendJson({ success: false, error: error.message || error.toString() });
  }
}

function handleTestConnection() {
  const parentFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);

  return sendJson({
    success: true,
    message: "Connection OK",
    folderName: parentFolder.getName(),
    folderId: parentFolder.getId(),
    folderUrl: parentFolder.getUrl(),
  });
}

function handleSaveProposalFiles(payload) {
  const clientName = cleanName(payload.clientName);
  const projectName = cleanName(payload.projectName);
  const versionNumber = payload.versionNumber;
  const pdfBase64 = payload.pdfBase64;
  const xlsxBase64 = payload.xlsxBase64;
  const pdfFileName = cleanName(payload.pdfFileName || (projectName + ".pdf"));
  const xlsxFileName = cleanName(payload.xlsxFileName || (projectName + ".xlsx"));

  if (!clientName) {
    return sendJson({ success: false, error: "Missing clientName" });
  }

  if (!projectName) {
    return sendJson({ success: false, error: "Missing projectName" });
  }

  const safeVersionNumber = parseInt(versionNumber, 10);
  if (isNaN(safeVersionNumber) || safeVersionNumber < 1) {
    return sendJson({ success: false, error: "versionNumber must be a positive number" });
  }

  if (!pdfBase64 && !xlsxBase64) {
    return sendJson({ success: false, error: "At least one of pdfBase64 or xlsxBase64 is required" });
  }

  const parentFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const clientFolder = getOrCreateFolder(parentFolder, clientName);
  const projectFolder = getOrCreateFolder(clientFolder, projectName);
  const versionFolder = getOrCreateFolder(projectFolder, "Version " + safeVersionNumber);
  const savedFiles = [];

  if (pdfBase64) {
    const pdfBytes = Utilities.base64Decode(pdfBase64);
    const pdfBlob = Utilities.newBlob(pdfBytes, MimeType.PDF, ensureExtension(pdfFileName, ".pdf"));
    const pdfFile = upsertBinaryFile(versionFolder, pdfBlob.getName(), pdfBlob);

    savedFiles.push({
      type: "pdf",
      fileName: pdfFile.getName(),
      fileId: pdfFile.getId(),
      fileUrl: pdfFile.getUrl(),
    });
  }

  if (xlsxBase64) {
    const xlsxBytes = Utilities.base64Decode(xlsxBase64);
    const xlsxBlob = Utilities.newBlob(
      xlsxBytes,
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ensureExtension(xlsxFileName, ".xlsx")
    );
    const xlsxFile = upsertBinaryFile(versionFolder, xlsxBlob.getName(), xlsxBlob);

    savedFiles.push({
      type: "xlsx",
      fileName: xlsxFile.getName(),
      fileId: xlsxFile.getId(),
      fileUrl: xlsxFile.getUrl(),
    });
  }

  return sendJson({
    success: true,
    message: "Proposal files saved successfully",
    clientFolderName: clientFolder.getName(),
    clientFolderId: clientFolder.getId(),
    projectFolderName: projectFolder.getName(),
    projectFolderId: projectFolder.getId(),
    versionFolderName: versionFolder.getName(),
    versionFolderId: versionFolder.getId(),
    versionFolderUrl: versionFolder.getUrl(),
    files: savedFiles,
  });
}

function handleSaveVersion(payload) {
  const clientName = cleanName(payload.clientName);
  const projectName = cleanName(payload.projectName);
  const versionNumber = payload.versionNumber;
  const proposalData = payload.proposalData;

  if (!clientName || !projectName || versionNumber === undefined || proposalData === undefined) {
    return sendJson({ success: false, error: "Missing required fields: clientName, projectName, versionNumber, proposalData" });
  }

  const safeVersionNumber = parseInt(versionNumber, 10);
  if (isNaN(safeVersionNumber) || safeVersionNumber < 1) {
    return sendJson({ success: false, error: "versionNumber must be a positive number" });
  }

  const rootFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const clientFolder = getOrCreateFolder(rootFolder, clientName);
  const projectFolder = getOrCreateFolder(clientFolder, projectName);
  const versionFolder = getOrCreateFolder(projectFolder, "Version " + safeVersionNumber);

  const fileName = "proposal-data.json";
  const wrappedData = {
    meta: {
      clientName: clientName,
      projectName: projectName,
      versionNumber: safeVersionNumber,
      savedAt: new Date().toISOString(),
    },
    proposalData: proposalData,
  };

  const fileContent = JSON.stringify(wrappedData, null, 2);
  const file = upsertJsonFile(versionFolder, fileName, fileContent);

  return sendJson({
    success: true,
    message: "Version " + safeVersionNumber + " saved successfully",
    path: clientName + "/" + projectName + "/Version " + safeVersionNumber,
    fileName: fileName,
    fileId: file.getId(),
    fileUrl: file.getUrl(),
    folderId: versionFolder.getId(),
    folderUrl: versionFolder.getUrl(),
  });
}

function handleListClients() {
  const rootFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const folders = rootFolder.getFolders();
  const clients = [];

  while (folders.hasNext()) {
    const folder = folders.next();
    clients.push({ name: folder.getName(), folderId: folder.getId(), folderUrl: folder.getUrl() });
  }

  clients.sort(function(a, b) { return a.name.localeCompare(b.name); });
  return sendJson({ success: true, clients: clients });
}

function handleListProjects(clientName) {
  clientName = cleanName(clientName);
  if (!clientName) {
    return sendJson({ success: false, error: "Missing clientName" });
  }

  const rootFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const clientFolders = rootFolder.getFoldersByName(clientName);
  if (!clientFolders.hasNext()) {
    return sendJson({ success: true, projects: [] });
  }

  const clientFolder = clientFolders.next();
  const projectFolders = clientFolder.getFolders();
  const projects = [];

  while (projectFolders.hasNext()) {
    const folder = projectFolders.next();
    projects.push({ name: folder.getName(), folderId: folder.getId(), folderUrl: folder.getUrl() });
  }

  projects.sort(function(a, b) { return a.name.localeCompare(b.name); });
  return sendJson({ success: true, projects: projects });
}

function handleListVersions(clientName, projectName) {
  clientName = cleanName(clientName);
  projectName = cleanName(projectName);
  if (!clientName || !projectName) {
    return sendJson({ success: false, error: "Missing clientName or projectName" });
  }

  const rootFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const clientFolders = rootFolder.getFoldersByName(clientName);
  if (!clientFolders.hasNext()) {
    return sendJson({ success: true, versions: [] });
  }

  const clientFolder = clientFolders.next();
  const projectFolders = clientFolder.getFoldersByName(projectName);
  if (!projectFolders.hasNext()) {
    return sendJson({ success: true, versions: [] });
  }

  const projectFolder = projectFolders.next();
  const versionFolders = projectFolder.getFolders();
  const versions = [];

  while (versionFolders.hasNext()) {
    const folder = versionFolders.next();
    const folderName = folder.getName();
    const match = folderName.match(/^Version\s+(\d+)$/i);

    if (match) {
      versions.push({
        name: folderName,
        versionNumber: parseInt(match[1], 10),
        folderId: folder.getId(),
        folderUrl: folder.getUrl(),
      });
    }
  }

  versions.sort(function(a, b) { return a.versionNumber - b.versionNumber; });
  return sendJson({ success: true, versions: versions });
}

function handleGetVersionData(clientName, projectName, versionNumber) {
  clientName = cleanName(clientName);
  projectName = cleanName(projectName);
  if (!clientName || !projectName || versionNumber === undefined) {
    return sendJson({ success: false, error: "Missing clientName, projectName, or versionNumber" });
  }

  const safeVersionNumber = parseInt(versionNumber, 10);
  if (isNaN(safeVersionNumber) || safeVersionNumber < 1) {
    return sendJson({ success: false, error: "versionNumber must be a positive number" });
  }

  const rootFolder = DriveApp.getFolderById(TARGET_PARENT_FOLDER_ID);
  const clientFolders = rootFolder.getFoldersByName(clientName);
  if (!clientFolders.hasNext()) {
    return sendJson({ success: false, error: "Client not found" });
  }

  const clientFolder = clientFolders.next();
  const projectFolders = clientFolder.getFoldersByName(projectName);
  if (!projectFolders.hasNext()) {
    return sendJson({ success: false, error: "Project not found" });
  }

  const projectFolder = projectFolders.next();
  const versionFolderName = "Version " + safeVersionNumber;
  const versionFolders = projectFolder.getFoldersByName(versionFolderName);
  if (!versionFolders.hasNext()) {
    return sendJson({ success: false, error: "Version not found" });
  }

  const versionFolder = versionFolders.next();
  const files = versionFolder.getFilesByName("proposal-data.json");
  if (!files.hasNext()) {
    return sendJson({ success: false, error: "proposal-data.json not found" });
  }

  const file = files.next();
  const content = file.getBlob().getDataAsString();
  const data = JSON.parse(content);

  return sendJson({
    success: true,
    data: data,
    fileId: file.getId(),
    fileUrl: file.getUrl(),
    folderId: versionFolder.getId(),
    folderUrl: versionFolder.getUrl(),
  });
}

function getOrCreateFolder(parentFolder, folderName) {
  const folders = parentFolder.getFoldersByName(folderName);
  if (folders.hasNext()) {
    return folders.next();
  }
  return parentFolder.createFolder(folderName);
}

function upsertJsonFile(folder, fileName, fileContent) {
  const files = folder.getFilesByName(fileName);
  while (files.hasNext()) {
    files.next().setTrashed(true);
  }
  return folder.createFile(fileName, fileContent, MimeType.JSON);
}

function upsertBinaryFile(folder, fileName, blob) {
  const files = folder.getFilesByName(fileName);
  while (files.hasNext()) {
    files.next().setTrashed(true);
  }
  blob.setName(fileName);
  return folder.createFile(blob);
}

function ensureExtension(fileName, extension) {
  const lower = fileName.toLowerCase();
  if (lower.endsWith(extension)) {
    return fileName;
  }
  return fileName + extension;
}

function cleanName(value) {
  if (value === undefined || value === null) {
    return "";
  }

  return String(value)
    .trim()
    .replace(/[\\/:*?"<>|#%{}~&]/g, "-")
    .replace(/\s+/g, " ");
}

function sendJson(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}
