# Google Drive Integration Setup Guide

This guide walks you through setting up Google Drive integration for MOCPO.

## Prerequisites

- A Google account with Google Drive access
- Access to Google Apps Script
- Node.js project running locally

## Step 1: Create Drive Folder

1. Open [Google Drive](https://drive.google.com)
2. Click **New** → **Folder**
3. Name it `MOCPO Proposals`
4. Open the folder and copy the folder ID from the URL:
   ```
   https://drive.google.com/drive/folders/1Fsg9zCWwhXxr6IAU5fuvIGrCvAPb6kCp?dmr=1&ec=wgc-drive-%5Bmodule%5D-goto
                                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                           This is your folder ID
   ```

## Step 2: Deploy Google Apps Script

### 2a. Create a Script Project

1. Go to [Google Apps Script](https://script.google.com)
2. Click **Create project**
3. Name it "MOCPO Drive Sync"

### 2b. Copy the Code

1. Open [Code.gs](./Code.gs) from this folder
2. Copy all the code
3. Paste it into the Google Apps Script editor
4. Replace the placeholder with your folder ID:

```javascript
// Line 15 - Replace with your folder ID
const ROOT_FOLDER_ID = "1Fsg9zCWwhXxr6IAU5fuvIGrCvAPb6kCp"; // Your ID here
```

### 2c. Deploy as Web App

1. Click **Deploy** button (top right)
2. Select **New deployment**
3. Choose deployment type: **Web app**
4. Set execution as: **Me** (your Google account)
5. Set access as: **Anyone**
6. Click **Deploy**
7. Copy the deployment URL:
   ```
   https://script.google.com/macros/d/DEPLOYMENT_ID/usercontent
   ```

## Step 3: Configure MOCPO

1. Open your MOCPO project folder
2. Open `.env.local` (create it if it doesn't exist)
3. Add the Apps Script URL:

```bash
# Google Drive Sync
NEXT_PUBLIC_APPS_SCRIPT_URL=https://script.google.com/macros/d/YOUR_DEPLOYMENT_ID/usercontent
```

## Step 4: Start Using Drive Sync

1. Run the app:
   ```bash
   npm run dev
   ```

2. **Save to Drive:**
   - Create or edit a proposal
   - Click **Save Version**
   - See toast notification: `Version X saved to Drive.`

3. **Load from Drive:**
   - Go to **Proposal History** page
   - Scroll down to **Google Drive sync** section
   - Browse your clients, projects, and versions
   - Click a version to load it

## Troubleshooting

### "Drive sync failed" message

**Possible causes:**
- Apps Script deployment URL is incorrect
- Google Drive folder was deleted
- Apps Script permissions changed
- Network error

**Fix:**
1. Check `.env.local` - verify the URL is correct
2. Re-authenticate with Google
3. Verify the `MOCPO Proposals` folder still exists
4. Redeploy the Apps Script

### Empty Drive browser

**Possible causes:**
- NEXT_PUBLIC_APPS_SCRIPT_URL is not set
- No proposals have been saved to Drive yet
- Apps Script had an error

**Fix:**
1. Save a proposal first
2. Check that the Apps Script URL is correct
3. Look at Apps Script logs for errors

### Folder structure not created

**Possible causes:**
- Root folder ID is incorrect
- Apps Script doesn't have write permissions

**Fix:**
1. Verify ROOT_FOLDER_ID in Code.gs matches your folder ID
2. Manually create the folder structure in Drive for testing:
   ```
   MOCPO Proposals/
   └── Test Client/
       └── Test Project/
           └── Version 1/
   ```

## How the Integration Works

### Save Flow

```
User clicks "Save Version"
    ↓
Version saved to localStorage (always works)
    ↓
Async: Send to Apps Script
    ↓
Apps Script creates folders:
  MOCPO Proposals/Client/Project/Version X/
    ↓
Apps Script saves proposal-data.json
    ↓
Toast notification: Success or Error
```

### Load Flow

```
User goes to Proposal History
    ↓
Clicks "Google Drive sync" section
    ↓
Fetches clients from Drive
    ↓
Clicking client fetches projects
    ↓
Clicking project fetches versions
    ↓
Clicking version loads proposal-data.json
    ↓
Proposal loaded into editor
```

## API Reference

### Save Version

**POST** to Apps Script URL

```json
{
  "action": "saveVersion",
  "clientName": "Engro",
  "projectName": "Reko Diq",
  "versionNumber": 3,
  "proposalData": { /* full version object */ }
}
```

### List Clients

**GET** with `?action=listClients`

Response:
```json
{
  "success": true,
  "clients": [
    { "name": "Engro", "folderId": "..." },
    { "name": "Other Client", "folderId": "..." }
  ]
}
```

### List Projects

**GET** with `?action=listProjects&clientName=Engro`

### List Versions

**GET** with `?action=listVersions&clientName=Engro&projectName=Reko%20Diq`

### Get Version Data

**GET** with `?action=getVersionData&clientName=Engro&projectName=Reko%20Diq&versionNumber=3`

## Security Notes

- The Apps Script is deployed as "Anyone" for simplicity
- The Drive folder ID is public (visible in deploy URL)
- Anyone with the Apps Script URL can:
  - Save proposals to the Drive folder
  - Read proposal data
  - Create folders
- **Recommendation:** Keep the URL private and share only with trusted users
- **For production:** Use OAuth for authentication instead

## Tips

- **Backup:** Proposals are backed up in Drive automatically
- **Offline:** App works perfectly offline using localStorage
- **Multiple Devices:** Access the same proposals from different devices via Drive
- **PDF/Excel Export:** Still exports use the current proposal data
