# Visual Reference & Quick Start

## 📊 Tab 1 Layout Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Consultancy Fee Proposal (Tab 1)                                           │
│  "Load standard deliverables → all fields editable → Excel export"          │
│  [Save Draft] [Create V2] [Preview Proposal]                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────┬──────────────────────────────────┬──────────────┐
│                            │                                  │              │
│  STANDARD DELIVERABLES     │  MAIN CONTENT AREA               │  FEE SUMMARY │
│  ┌──────────────────────┐  │  ┌───────────────────────────┐   │              │
│  │ Architecture         │  │  │ ARCHITECTURE              │   │ Project Name │
│  │ ┌──────────────────┐ │  │  │ ─────────────────         │   │ Client Name  │
│  │ │  + Load          │ │  │  │ Phase | Deliverable | ... │   │ Location     │
│  │ └──────────────────┘ │  │  │ ONE   | Init...     | ... │   │ Version: V1  │
│  │                      │  │  │ TWO   | Concept...  | ... │   │              │
│  │ Interior             │  │  │ [... more rows ...]       │   │ Subtotal:    │
│  │ ┌──────────────────┐ │  │  │                           │   │ PKR 450,000  │
│  │ │  + Load          │ │  │  │ [+ Add Field]             │   │              │
│  │ └──────────────────┘ │  │  │ [Edit Fields] [Lock]      │   │ Tax (16%):   │
│  │                      │  │  │ [Unload]                  │   │ PKR 72,000   │
│  │ MEP Design (1 row)   │  │  └───────────────────────────┘   │              │
│  │ ┌──────────────────┐ │  │                                  │ Discount (3%)│
│  │ │  ✓ Loaded   │ ✗   │ │  ┌───────────────────────────┐   │ (PKR -13,500)│
│  │ └──────────────────┘ │  │  │ INTERIOR                  │   │              │
│  │                      │  │  │ ─────────────────         │   │ GRAND TOTAL: │
│  │ Structure            │  │  │ Phase | Deliverable | ... │   │ PKR 508,500  │
│  │ ┌──────────────────┐ │  │  │ ONE   | Concept...  | ... │   │              │
│  │ │  + Load          │ │  │  │ [... more rows ...]       │   │              │
│  │ └──────────────────┘ │  │  │                           │   │ [Save Draft] │
│  │                      │  │  │ [+ Add Field]             │   │              │
│  │ Facade Engineering   │  │  │ [Edit Fields] [Lock]      │   │ [Preview PDF]│
│  │ ┌──────────────────┐ │  │  │ [Unload]                  │   │              │
│  │ │  + Load          │ │  │  └───────────────────────────┘   │ [Download]   │
│  │ └──────────────────┘ │  │                                  │              │
│  │                      │  │  ... (more disciplines)          │              │
│  │ Landscaping          │  │                                  │              │
│  │ ┌──────────────────┐ │  │                                  │              │
│  │ │  + Load          │ │  │                                  │              │
│  │ └──────────────────┘ │  │                                  │              │
│  │                      │  │                                  │              │
│  │ Top Supervision      │  │                                  │              │
│  │ ┌──────────────────┐ │  │                                  │              │
│  │ │  + Load          │ │  │                                  │              │
│  │ └──────────────────┘ │  │                                  │              │
│  │                      │  │                                  │              │
│  │ Resident Engineering │  │                                  │              │
│  │ ┌──────────────────┐ │  │                                  │              │
│  │ │  + Load          │ │  │                                  │              │
│  │ └──────────────────┘ │  │                                  │              │
│  │                      │  │  ─────────────────────────────┐  │              │
│  │ PROJECT PARAMETERS   │  │                               │  │              │
│  │ ─────────────────────│  │  [BOTTOM ACTION BAR]          │  │              │
│  │ Total Area: [  5000  ]  │  [Save] [Preview PDF] [PDF]   │  │              │
│  │                      │  │  [XLSX] [Final Proposal]      │  │              │
│  │ Duration: [   24  ]  │  │                               │  │              │
│  │                      │  │                               │  │              │
│  │ Proposal Date:       │  │                               │  │              │
│  │ [2026-05-23]         │  │                               │  │              │
│  │                      │  │                               │  │              │
│  └──────────────────────┘  └───────────────────────────────┘  └──────────────┘
   Width: 280px               Width: Flexible (1fr)              Width: 360px
   Position: Sticky            Scrollable                         Position: Sticky
```

---

## 🎯 Quick Start Workflow

### Step 1: Load a Discipline ⬇️
```
Click on "Load" button next to "Architecture"
           ↓
Architecture card appears in center with 5 phases
           ↓
Shows:  "ONE - PROJECT INITIATION - Rate 12 - Edit [Edit Fields] [Unload]"
        "TWO - CONCEPT DESIGN - Rate 18"
        ... etc
```

### Step 2: Edit Values ⬇️
```
Click "[Edit Fields]" button
           ↓
All fields become editable
           ↓
- Click on phase label to change "ONE" → "PHASE 1"
- Click on deliverable text to add/edit description
- Enter new rate (e.g., 15 instead of 12)
- Enter new area (e.g., 5000 instead of default)
```

### Step 3: Add Custom Row ⬇️
```
Click "[+ Add Field]" button
           ↓
New empty row appears
           ↓
Fill in:
- Phase label: "CUSTOM"
- Deliverable: "My custom deliverable text"
- Rate: 25
- Area: 3000
```

### Step 4: Lock & Finalize ⬇️
```
Click "[Lock Values]" button
           ↓
All fields become read-only
           ↓
Card shows checkmark on "Load" button in left sidebar
```

### Step 5: Download Excel ⬇️
```
Click "[Download XLSX]" button at bottom
           ↓
Excel file downloads with:
- Your company logo (top-right)
- Professional header with company name
- Professional footer with date and page numbers
- All your data
- Yellow-highlighted editable cells
- Formula-driven totals
```

---

## 🎨 Visual States

### Standard Deliverable Card - Unloaded
```
┌────────────────────────┐
│ Architecture           │
│ not loaded             │
│ [+]     Load           │
└────────────────────────┘
Color: White background, gray border
```

### Standard Deliverable Card - Loaded
```
┌────────────────────────┐  ← Blue border
│ Architecture           │
│ 5 rows                 │
│ [✓]     [✗] Unload    │
└────────────────────────┘  ← Blue background
```

### Discipline Card - Edit Mode
```
┌─────────────────────────────────────────┐
│ ARCHITECTURE (edit mode)                 │
│ 5 rows · PKR 350,000                    │
│                                          │
│ Rate/PKR/SQ.FT | Area/SQ.FT Input       │
│ ────────────────────────────────────────│
│ ONE     [Editable Textarea]     15  5000│
│ TWO     [Editable Textarea]     18  5000│
│ [+ Add Field] [Lock Values] [Unload]   │
│                                          │
│ Included scope notes:                    │
│ - Project initiation                     │
│ - Concept design                         │
└─────────────────────────────────────────┘
```

### Discipline Card - Locked Mode
```
┌─────────────────────────────────────────┐
│ ARCHITECTURE (locked)                    │
│ 5 rows · PKR 350,000                    │
│                                          │
│ Rate/PKR/SQ.FT | Area/SQ.FT Input       │
│ ────────────────────────────────────────│
│ ONE     Project Initiation...   15  5000│
│ TWO     Concept Design...       18  5000│
│ [Edit Fields] [Unload]                  │
│                                          │
│ Included scope notes:                    │
│ - Project initiation                     │
│ - Concept design                         │
└─────────────────────────────────────────┘
```

---

## 📄 Excel Export Preview

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MOLECULE WORKPLACE SOLUTION - CONSULTANCY FEE PROPOSAL        [LOGO]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
                                                  PROJECT PARAMETERS
Phase         Deliverable              Rate/PKR  Area    Total Cost
────────────────────────────────────────────────────────────────────
           ARCHITECTURE                                              (Gold heading)
ONE     - PROJECT INITIATION      [  12  ]  [ 5000 ]   60,000      (Yellow inputs)
        1. Site Inspection
        2. Survey & Analysis
TWO     - CONCEPT DESIGN          [  18  ]  [ 5000 ]   90,000
        1. Planning & layout
THREE   - DESIGN DEVELOPMENT      [  36  ]  [ 5000 ]  180,000
        1. Elevations & Finishes
        2. 2D Sections
        3. 3D Design & Renders
FOUR    - DRAWING DEVELOPMENT     [  36  ]  [ 5000 ]  180,000
        1. Architecture Working Drawings
FIVE    - BOQ DEVELOPMENT         [  18  ]  [ 5000 ]   90,000
        1. Architecture
                                          SUB TOTAL:  600,000     (Gold row)

           INTERIOR
ONE     - CONCEPT DESIGN          [  40  ]  [ 5000 ]  200,000
        ... etc ...

GRAND SUMMARY - CONSULTANCY FEE
────────────────────────────────────────────────────────────────────
S.No  Discipline/Scope    Source    Total Cost (PKR)
1     Architecture         600,000   600,000
2     Interior            500,000   500,000
3     MEP Design          200,000   200,000
                                                GRAND TOTAL: 1,300,000  (Navy row)

Legend: yellow cells are editable inputs. Totals are formula-driven and recalculate automatically.

────────────────────────────────────────────────────────────────────
Molecule Workplace Solution        Page 1 of 1         23 May 2026
Confidential consultancy fee proposal
```

---

## ⌨️ Keyboard Shortcuts (Inferred)

- **Tab**: Move to next editable field
- **Shift+Tab**: Move to previous editable field
- **Ctrl+S**: Save draft (if implemented)
- **Enter**: Submit textarea input
- **Escape**: Cancel edit mode

---

## 🚨 Common Issues & Solutions

### Issue: "Load button not working"
**Solution**: Make sure you're clicking the correct Load button for the discipline you want

### Issue: "Changes not saving to Excel"
**Solution**: Click [Save Draft] button at the top, then [Download XLSX]

### Issue: "Can't edit values"
**Solution**: Click [Edit Fields] button first to enable edit mode

### Issue: "Excel totals not updating"
**Solution**: They use formulas. Change the yellow cells and press Enter in Excel

### Issue: "Logo not showing in Excel"
**Solution**: Check that logo file exists at: `public/brand/molecule-workplace-solution.jpeg`

---

## 📋 Checklist Before Downloading Excel

- [ ] Load all required disciplines (Architecture, Interior, MEP, etc.)
- [ ] Edit all rates to correct values
- [ ] Edit all areas to correct values
- [ ] Add any custom rows needed
- [ ] Review all deliverable descriptions
- [ ] Lock all disciplines to prevent accidental changes
- [ ] Verify project parameters (name, client, area, duration)
- [ ] Click [Save Draft]
- [ ] Click [Download XLSX]
- [ ] Open Excel and verify:
  - [ ] Logo appears (top-right)
  - [ ] Header shows company name and version
  - [ ] Footer shows date and page numbers
  - [ ] All your data is there
  - [ ] Yellow cells are editable
  - [ ] Totals recalculate when you change yellow cells

---

**Ready to Go! 🚀**

Your Consultancy Fee Proposal system is now fully implemented with:
- ✅ Load/unload controls
- ✅ Editable fields
- ✅ Add row functionality
- ✅ Professional Excel export
- ✅ Company logo integration
- ✅ Custom headers & footers
- ✅ Vertical layout for standard deliverables

Start by clicking "Load" on Architecture in the left sidebar!
