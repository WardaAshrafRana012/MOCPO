"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, ChevronDown, ChevronUp, Eye, Lock, PencilLine, Plus, Trash2 } from "lucide-react";

import { SectionHeader } from "@/components/shared/section-header";
import { useProposalExportActions } from "@/components/shared/use-proposal-export-actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  calculateConsultancyTotals,
  calculateFinalEstimate,
  calculateTimelineTotals,
  getExecutionBudgetTotals,
  getExecutionPlanLabel,
  getProposalWarnings,
  getSelectedExecutionCost,
  getTimelinePlanLabel,
} from "@/lib/calculations";
import { standardTimelineActivities } from "@/lib/seeds";
import type { ExecutionBudgetPlan, ExecutionPlan, TimelineRow } from "@/lib/types";
import { formatCurrency, formatDateTime, formatNumber, getEditableNumberInputValue } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

function SummaryPill({
  label,
  value,
  className = "",
  valueClassName = "",
}: {
  label: string;
  value: string;
  className?: string;
  valueClassName?: string;
}) {
  return (
    <div className={`min-w-0 rounded-2xl border border-slate-200 bg-white px-4 py-4 shadow-sm ${className}`}>
      <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-slate-500">{label}</p>
      <p className={`mt-2 text-base font-semibold leading-snug text-slate-950 break-words ${valueClassName}`}>{value}</p>
    </div>
  );
}

function TimelineEditor({
  title,
  rows,
  totalProjectDurationDays,
  isLocked,
  isOpen,
  onToggleOpen,
  onToggleLock,
  onSetTotalProjectDurationDays,
  onUpdateRow,
  onAddRow,
  onRemoveRow,
  onDistributeDays,
}: {
  title: string;
  rows: TimelineRow[];
  totalProjectDurationDays: number;
  isLocked: boolean;
  isOpen: boolean;
  onToggleOpen: () => void;
  onToggleLock: (isLocked: boolean) => void;
  onSetTotalProjectDurationDays: (days: number) => void;
  onUpdateRow: (rowId: string, field: "activity" | "days" | "startDate" | "remarks", value: number | string) => void;
  onAddRow: () => void;
  onRemoveRow: (rowId: string) => void;
  onDistributeDays: (days: number) => void;
}) {
  const totals = calculateTimelineTotals(rows);
  const mismatch = totalProjectDurationDays > 0 && totals.totalDays !== totalProjectDurationDays;

  return (
    <Card className="border-white/80">
      <CardHeader className="gap-5 border-b border-slate-200/80 pb-5">
        <div className="flex flex-col gap-5">
        <button type="button" onClick={onToggleOpen} className="flex w-full items-start justify-between gap-4 text-left">
          <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-500">Tentative Timeline</p>
          <CardTitle className="mt-2 text-2xl leading-tight">{title}</CardTitle>
          <p className="mt-3 max-w-sm text-sm leading-6 text-slate-500">
            Set the overall duration, then align each activity so the schedule feels clear and client-ready.
          </p>
          </div>
          <span className="mt-1 shrink-0 rounded-full border border-slate-200 bg-white p-2 text-slate-600 shadow-sm">
            {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </span>
        </button>
        <div className="grid gap-3 sm:grid-cols-2">
          <Button variant="secondary" onClick={() => onDistributeDays(totalProjectDurationDays)} className="min-h-11 w-full">
            Redistribute Days
          </Button>
          <Button variant="secondary" onClick={onAddRow} className="min-h-11 w-full">
            <Plus className="h-4 w-4" />
            Add Activity
          </Button>
          <Button variant={isLocked ? "secondary" : "accent"} onClick={() => onToggleLock(!isLocked)} className="min-h-11 w-full sm:col-span-2">
            {isLocked ? <PencilLine className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
            {isLocked ? "Edit Timeline" : "Lock Timeline"}
          </Button>
        </div>
        </div>
      </CardHeader>
      {isOpen ? (
      <CardContent className="space-y-5 pt-5">
        <div className="grid gap-4">
          <div className="rounded-3xl border border-slate-200 bg-slate-50 px-5 py-5 shadow-sm">
            <Label htmlFor="total-project-duration-days" className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
              Total Project Duration (Days)
            </Label>
            <Input
              id="total-project-duration-days"
              type="number"
              min={0}
              value={getEditableNumberInputValue(totalProjectDurationDays)}
              onChange={(event) => onSetTotalProjectDurationDays(Number(event.target.value || 0))}
              className="mt-3 h-12 bg-white text-lg font-semibold"
            />
            <p className="mt-3 text-sm text-slate-500">
              Approximate duration: {formatNumber(Number((totalProjectDurationDays / 30).toFixed(1)))} months
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <SummaryPill
              label="Approximate Duration"
              value={`${formatNumber(Number((totalProjectDurationDays / 30).toFixed(1)))} Months`}
            />
            <SummaryPill
              label="Allocated Activity Days"
              value={`${formatNumber(totals.totalDays)} Days`}
            />
            <SummaryPill label="Activities" value={String(rows.length)} className="sm:col-span-2" />
          </div>
        </div>

        {mismatch ? (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
            Activity days total {formatNumber(totals.totalDays)} but total project duration is {formatNumber(totalProjectDurationDays)} days.
          </div>
        ) : (
          <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
            Timeline totals match the overall project duration.
          </div>
        )}

        <div className="overflow-x-auto rounded-3xl border border-slate-300 bg-white">
          <table className="min-w-[980px] border-collapse text-sm">
            <thead>
              <tr className="bg-slate-900 text-white">
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Sr. No</th>
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Activity Name</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Days</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Start Date</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">End Date</th>
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Remarks</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, index) => (
                <tr key={row.id}>
                  <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{index + 1}</td>
                  <td className="border border-slate-300 px-3 py-3">
                    {isLocked ? (
                      <span className="font-medium text-slate-900">{row.activity}</span>
                    ) : (
                      <>
                        <Input
                          value={row.activity}
                          list="timeline-activity-options"
                          onChange={(event) => onUpdateRow(row.id, "activity", event.target.value)}
                          className="border-0 bg-transparent px-0 shadow-none focus-visible:ring-1"
                        />
                        <datalist id="timeline-activity-options">
                          {standardTimelineActivities.map((activity) => (
                            <option key={activity} value={activity} />
                          ))}
                        </datalist>
                      </>
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    {isLocked ? (
                      formatNumber(row.days)
                    ) : (
                      <Input
                        type="number"
                        min={0}
                        value={getEditableNumberInputValue(row.days)}
                        onChange={(event) => onUpdateRow(row.id, "days", Number(event.target.value || 0))}
                        className="border-0 bg-transparent text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    {isLocked ? (
                      row.startDate || "-"
                    ) : (
                      <Input
                        type="date"
                        value={row.startDate}
                        onChange={(event) => onUpdateRow(row.id, "startDate", event.target.value)}
                        className="border-0 bg-transparent text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center font-semibold text-slate-950">{row.endDate || "-"}</td>
                  <td className="border border-slate-300 px-3 py-3">
                    {isLocked ? (
                      row.remarks || "-"
                    ) : (
                      <Input
                        value={row.remarks}
                        onChange={(event) => onUpdateRow(row.id, "remarks", event.target.value)}
                        className="border-0 bg-transparent px-0 shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    <Button type="button" variant="ghost" size="icon" onClick={() => onRemoveRow(row.id)} disabled={rows.length <= 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
      ) : null}
    </Card>
  );
}

function BudgetPlanCard({
  plan,
  isSelected,
  isLocked,
  onUpdatePlan,
  onAddRow,
  onUpdateRow,
  onRemoveRow,
  onRemovePlan,
}: {
  plan: ExecutionBudgetPlan;
  isSelected: boolean;
  isLocked: boolean;
  onUpdatePlan: (field: "title" | "optionLabel", value: string) => void;
  onAddRow: () => void;
  onUpdateRow: (rowId: string, field: "description" | "quantity" | "rate" | "remarks", value: number | string) => void;
  onRemoveRow: (rowId: string) => void;
  onRemovePlan: () => void;
}) {
  const total = plan.rows.reduce((sum, row) => sum + row.totalAmount, 0);

  return (
    <Card className={`border-white/80 overflow-hidden ${isSelected ? "ring-2 ring-slate-900/10" : ""}`}>
      <CardHeader className="gap-4 border-b border-slate-200/80 pb-5">
        <div className="space-y-4">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
            <div className="min-w-0 flex-1 space-y-3">
            {isLocked ? (
              <>
                <CardTitle className="text-xl">{plan.title}</CardTitle>
                <CardDescription>{plan.optionLabel}</CardDescription>
              </>
            ) : (
              <div className="grid gap-3 xl:grid-cols-2">
                <Input value={plan.title} onChange={(event) => onUpdatePlan("title", event.target.value)} />
                <Input value={plan.optionLabel} onChange={(event) => onUpdatePlan("optionLabel", event.target.value)} />
              </div>
            )}
            </div>
            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-right">
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Grand Total</p>
              <p className="mt-1 text-lg font-semibold text-slate-950">{formatCurrency(total)}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="secondary" onClick={onAddRow} className="min-h-11 px-4">
              <Plus className="h-4 w-4" />
              Add Cost Item
            </Button>
            <Button variant="ghost" size="icon" onClick={onRemovePlan} className="min-h-11 min-w-11">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 pt-5">
        <div className="overflow-x-auto rounded-3xl border border-slate-300 bg-white">
          <table className="min-w-[640px] border-collapse text-sm">
            <thead>
              <tr className="bg-slate-900 text-white">
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Sr. No</th>
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Description</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Quantity</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Rate</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Total</th>
                <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Remarks</th>
                <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Actions</th>
              </tr>
            </thead>
            <tbody>
              {plan.rows.map((row, index) => (
                <tr key={row.id}>
                  <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{index + 1}</td>
                  <td className="border border-slate-300 px-3 py-3">
                    {isLocked ? (
                      row.description
                    ) : (
                      <Input
                        value={row.description}
                        onChange={(event) => onUpdateRow(row.id, "description", event.target.value)}
                        className="border-0 bg-transparent px-0 shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    {isLocked ? (
                      formatNumber(row.quantity)
                    ) : (
                      <Input
                        type="number"
                        min={0}
                        value={getEditableNumberInputValue(row.quantity)}
                        onChange={(event) => onUpdateRow(row.id, "quantity", Number(event.target.value || 0))}
                        className="border-0 bg-transparent text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    {isLocked ? (
                      formatCurrency(row.rate)
                    ) : (
                      <Input
                        type="number"
                        min={0}
                        value={getEditableNumberInputValue(row.rate)}
                        onChange={(event) => onUpdateRow(row.id, "rate", Number(event.target.value || 0))}
                        className="border-0 bg-transparent text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center font-semibold text-slate-950">{formatCurrency(row.totalAmount)}</td>
                  <td className="border border-slate-300 px-3 py-3">
                    {isLocked ? (
                      row.remarks || "-"
                    ) : (
                      <Input
                        value={row.remarks}
                        onChange={(event) => onUpdateRow(row.id, "remarks", event.target.value)}
                        className="border-0 bg-transparent px-0 shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-3 py-3 text-center">
                    <Button type="button" variant="ghost" size="icon" onClick={() => onRemoveRow(row.id)} disabled={plan.rows.length <= 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
              <tr className="bg-slate-100">
                <td className="border border-slate-300 px-3 py-3" />
                <td className="border border-slate-300 px-3 py-3 font-semibold text-slate-900">GRAND TOTAL</td>
                <td className="border border-slate-300 px-3 py-3" />
                <td className="border border-slate-300 px-3 py-3" />
                <td className="border border-slate-300 px-3 py-3 text-center font-semibold text-slate-900">{formatCurrency(total)}</td>
                <td className="border border-slate-300 px-3 py-3" />
                <td className="border border-slate-300 px-3 py-3" />
              </tr>
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function ExecutionPreview({
  projectName,
  selectedPlan,
  updatedAt,
  totalProjectDurationDays,
  timelineRows,
  budgetPlans,
  consultancyFee,
  finalEstimate,
}: {
  projectName: string;
  selectedPlan: ExecutionPlan;
  updatedAt: string;
  totalProjectDurationDays: number;
  timelineRows: TimelineRow[];
  budgetPlans: ExecutionBudgetPlan[];
  consultancyFee: number;
  finalEstimate: number;
}) {
  const { budgetA, budgetB, budgetATotal, budgetBTotal } = getExecutionBudgetTotals({
    importedConsultancyFee: consultancyFee,
    importedOptimalCost: 0,
    importedBufferedCost: 0,
    selectedPlan,
    totalProjectDurationDays,
    timelineRows,
    budgetPlans,
    isLocked: true,
  });
  const selectedBudgetLabel = getExecutionPlanLabel(selectedPlan);
  const timelineTitle = getTimelinePlanLabel(selectedPlan);

  return (
    <Card className="border-white/80">
      <CardHeader className="border-b border-slate-200/80 pb-5">
        <CardTitle className="text-2xl">Client Comparison Preview</CardTitle>
        <CardDescription>
          {projectName || "Untitled Project"} | Updated {formatDateTime(updatedAt)}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6 pt-5">
        <div className="grid gap-3 sm:grid-cols-3">
          <SummaryPill label="Selected Budget" value={selectedBudgetLabel} />
          <SummaryPill
            label="Total Project Duration"
            value={`${formatNumber(totalProjectDurationDays)} Days`}
          />
          <SummaryPill label="Final Estimate" value={formatCurrency(finalEstimate)} />
        </div>

        {timelineTitle ? <section className="space-y-3">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">Timeline Section</p>
            <h3 className="mt-1 text-lg font-semibold text-slate-950">{timelineTitle}</h3>
          </div>
          <div className="overflow-hidden rounded-[28px] border border-slate-300 bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="min-w-[760px] border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-900 text-white">
                    <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Sr. No</th>
                    <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Activity Name</th>
                    <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Total Days</th>
                    <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Start Date</th>
                    <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">End Date</th>
                  </tr>
                </thead>
                <tbody>
                  {timelineRows.map((row, index) => (
                    <tr key={row.id} className="bg-white">
                      <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{index + 1}</td>
                      <td className="border border-slate-300 px-3 py-3 text-slate-800">{row.activity}</td>
                      <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{formatNumber(row.days)}</td>
                      <td className="border border-slate-300 px-3 py-3 text-center text-slate-700">{row.startDate || "-"}</td>
                      <td className="border border-slate-300 px-3 py-3 text-center text-slate-700">{row.endDate || "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section> : null}

        <section className="space-y-4">
          <div>
            <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-slate-500">Budget Section</p>
            <h3 className="mt-1 text-lg font-semibold text-slate-950">Budget Plan</h3>
          </div>
          {selectedPlan === "both" && budgetA && budgetB ? (
            <div className="rounded-[28px] border border-slate-300 bg-white shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4">
                <div>
                  <p className="text-base font-semibold text-slate-950">Budget Comparison Table</p>
                  <p className="text-xs uppercase tracking-[0.16em] text-slate-500">Budget Plan A and Budget Plan B side by side</p>
                </div>
                <div className="text-right text-sm font-semibold text-slate-950">
                  <p>Budget Plan A {formatCurrency(budgetATotal)}</p>
                  <p>Budget Plan B {formatCurrency(budgetBTotal)}</p>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-[1040px] border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-900 text-white">
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">S.No</th>
                      <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Description</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan A Qty</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan A Rate</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan A Amount</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan B Qty</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan B Rate</th>
                      <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Budget Plan B Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.from({ length: Math.max(budgetA.rows.length, budgetB.rows.length) }).map((_, index) => {
                      const rowA = budgetA.rows[index];
                      const rowB = budgetB.rows[index];
                      return (
                        <tr key={`${rowA?.id ?? "a"}-${rowB?.id ?? "b"}-${index}`} className="bg-white">
                          <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{index + 1}</td>
                          <td className="border border-slate-300 px-3 py-3 text-slate-800">{rowA?.description || rowB?.description || "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center">{rowA ? formatNumber(rowA.quantity) : "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center">{rowA ? formatCurrency(rowA.rate) : "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{rowA ? formatCurrency(rowA.totalAmount) : "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center">{rowB ? formatNumber(rowB.quantity) : "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center">{rowB ? formatCurrency(rowB.rate) : "-"}</td>
                          <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{rowB ? formatCurrency(rowB.totalAmount) : "-"}</td>
                        </tr>
                      );
                    })}
                    <tr className="bg-slate-100 font-semibold text-slate-950">
                      <td className="border border-slate-300 px-3 py-3" colSpan={4}>Budget Plan A Total</td>
                      <td className="border border-slate-300 px-3 py-3 text-center">{formatCurrency(budgetATotal)}</td>
                      <td className="border border-slate-300 px-3 py-3" colSpan={2}>Budget Plan B Total</td>
                      <td className="border border-slate-300 px-3 py-3 text-center">{formatCurrency(budgetBTotal)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            budgetPlans
              .filter((plan) =>
                selectedPlan === "buffered" ? plan.key === "budget-b" : plan.key === "budget-a",
              )
              .map((plan) => {
                const total = plan.rows.reduce((sum, row) => sum + row.totalAmount, 0);
                return (
                  <div key={plan.id} className="rounded-[28px] border border-slate-300 bg-white shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 px-5 py-4">
                      <div>
                        <p className="text-base font-semibold text-slate-950">{plan.title}</p>
                        <p className="text-xs uppercase tracking-[0.16em] text-slate-500">{plan.optionLabel}</p>
                      </div>
                      <p className="text-sm font-semibold text-slate-950">Grand Total Amount {formatCurrency(total)}</p>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="min-w-[760px] border-collapse text-sm">
                        <thead>
                          <tr className="bg-slate-900 text-white">
                            <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Sr. No</th>
                            <th className="border border-slate-300 px-3 py-3 text-left text-[11px] uppercase tracking-[0.16em]">Description</th>
                            <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Quantity</th>
                            <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Rate</th>
                            <th className="border border-slate-300 px-3 py-3 text-center text-[11px] uppercase tracking-[0.16em]">Total Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          {plan.rows.length > 0 ? (
                            plan.rows.map((row, index) => (
                              <tr key={row.id} className="bg-white">
                                <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{index + 1}</td>
                                <td className="border border-slate-300 px-3 py-3 text-slate-800">{row.description}</td>
                                <td className="border border-slate-300 px-3 py-3 text-center text-slate-700">{formatNumber(row.quantity)}</td>
                                <td className="border border-slate-300 px-3 py-3 text-center text-slate-700">{formatCurrency(row.rate)}</td>
                                <td className="border border-slate-300 px-3 py-3 text-center font-medium text-slate-900">{formatCurrency(row.totalAmount)}</td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={5} className="border border-slate-300 px-4 py-8 text-center text-slate-500">
                                No budget rows added yet.
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })
          )}
        </section>
      </CardContent>
    </Card>
  );
}

export function ExecutionPage({
  mode = "page",
  sectionLocked = false,
}: {
  mode?: "page" | "wizard" | "ai-workspace";
  sectionLocked?: boolean;
}) {
  const [executionSetupOpen, setExecutionSetupOpen] = useState(true);
  const [timelineOpen, setTimelineOpen] = useState(true);
  const project = useProposalStore((state) => state.project);
  const updateProjectFields = useProposalStore((state) => state.updateProjectFields);
  const setExecutionLocked = useProposalStore((state) => state.setExecutionLocked);
  const setExecutionPlan = useProposalStore((state) => state.setExecutionPlan);
  const setTotalProjectDurationDays = useProposalStore((state) => state.setTotalProjectDurationDays);
  const updateTimelineRow = useProposalStore((state) => state.updateTimelineRow);
  const addTimelineRow = useProposalStore((state) => state.addTimelineRow);
  const removeTimelineRow = useProposalStore((state) => state.removeTimelineRow);
  const distributeTimelineDays = useProposalStore((state) => state.distributeTimelineDays);
  const importExecutionBudgetsFromScope = useProposalStore((state) => state.importExecutionBudgetsFromScope);
  const addExecutionBudgetPlan = useProposalStore((state) => state.addExecutionBudgetPlan);
  const removeExecutionBudgetPlan = useProposalStore((state) => state.removeExecutionBudgetPlan);
  const updateExecutionBudgetPlan = useProposalStore((state) => state.updateExecutionBudgetPlan);
  const addExecutionBudgetRow = useProposalStore((state) => state.addExecutionBudgetRow);
  const updateExecutionBudgetRow = useProposalStore((state) => state.updateExecutionBudgetRow);
  const removeExecutionBudgetRow = useProposalStore((state) => state.removeExecutionBudgetRow);

  const version = project.draftVersion;
  const execution = version.executionSection;
  const warnings = getProposalWarnings(project, version);
  const timelineTotals = calculateTimelineTotals(execution.timelineRows);
  const consultancyTotals = calculateConsultancyTotals(version.consultancySection, project.taxRate, project.discountRate, project.projectDurationMonths);
  const selectedPlanCost = getSelectedExecutionCost(execution);
  const finalEstimate = calculateFinalEstimate(execution);
  const budgetAExists = execution.budgetPlans.some((plan) => plan.key === "budget-a");
  const budgetBExists = execution.budgetPlans.some((plan) => plan.key === "budget-b");
  const hasScopeRows = version.scopeSection.rows.some((row) => row.kind === "line" && row.groupId);
  const showBudgetControls = hasScopeRows;
  const mismatch = execution.totalProjectDurationDays > 0 && timelineTotals.totalDays !== execution.totalProjectDurationDays;
  const bannerWarning = mismatch ? "Timeline allocation does not match the total project duration." : null;
  const { previewProposal } = useProposalExportActions();
  const isWizard = mode === "wizard" || mode === "ai-workspace";
  const hideExecutionSetupCard = mode === "ai-workspace";
  const isReadOnly = sectionLocked || execution.isLocked;

  const orderedBudgetPlans = useMemo(
    () =>
      [...execution.budgetPlans].sort((a, b) => {
        const sortKey = (plan: ExecutionBudgetPlan) => (plan.key === "budget-a" ? 0 : plan.key === "budget-b" ? 1 : 2);
        return sortKey(a) - sortKey(b);
      }),
    [execution.budgetPlans],
  );

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow={isWizard ? "Step 5" : "Tab 3"}
        title="Execution Estimate"
        actions={
          !isWizard ? (
            <Button onClick={() => previewProposal("execution")}>
              <Eye className="h-4 w-4" />
              Open Preview
            </Button>
          ) : null
        }
      />

      {bannerWarning ? (
        <div className="flex items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
          <AlertTriangle className="h-4 w-4" />
          {bannerWarning}
        </div>
      ) : null}

      <div className={isWizard ? "space-y-6" : "grid gap-6 xl:grid-cols-[minmax(0,420px)_minmax(0,1fr)]"}>
        <div className="space-y-6">
          {!hideExecutionSetupCard ? (
            <Card className="border-white/80">
              <CardHeader className="border-b border-slate-200/80 pb-5">
                <button
                  type="button"
                  onClick={() => setExecutionSetupOpen((current) => !current)}
                  className="flex w-full items-start justify-between gap-4 text-left"
                >
                  <div>
                    <CardTitle className="text-2xl">Execution setup</CardTitle>
                    <CardDescription className="mt-1">
                      {showBudgetControls
                        ? "Build multiple client-facing budget options inside the same proposal."
                        : "Timeline-only mode is active because Workscope Break-up is not selected."}
                    </CardDescription>
                  </div>
                  <span className="rounded-full border border-slate-200 bg-white p-2 text-slate-600 shadow-sm">
                    {executionSetupOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </span>
                </button>
              </CardHeader>
              {executionSetupOpen ? (
                <CardContent className="space-y-6 pt-5">
                  {showBudgetControls ? (
                    <>
                      <div className="space-y-2">
                        <Label>Selected Budget For Final Estimate</Label>
                        <Select value={execution.selectedPlan ?? undefined} onValueChange={(value) => setExecutionPlan(value as ExecutionPlan)} disabled={isReadOnly}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select budget plan" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="both">Plan A and Plan B</SelectItem>
                            <SelectItem value="optimal">Budget Plan A</SelectItem>
                            <SelectItem value="buffered">Budget Plan B</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-2">
                        <Button variant="outline" onClick={importExecutionBudgetsFromScope} disabled={!hasScopeRows || isReadOnly} className="sm:col-span-2">
                          Import Scope Into Execution Estimate
                        </Button>
                        <Button variant="secondary" onClick={() => addExecutionBudgetPlan("budget-a")} disabled={budgetAExists || isReadOnly}>
                          <Plus className="h-4 w-4" />
                          Add Budget Plan A
                        </Button>
                        <Button variant="secondary" onClick={() => addExecutionBudgetPlan("budget-b")} disabled={budgetBExists || isReadOnly}>
                          <Plus className="h-4 w-4" />
                          Add Budget Plan B
                        </Button>
                      </div>
                    </>
                  ) : null}

                  <div className={`grid gap-4 ${showBudgetControls ? "sm:grid-cols-2" : ""}`}>
                    <SummaryPill
                      label="Consultancy Fee"
                      value={formatCurrency(execution.importedConsultancyFee)}
                      className="bg-gradient-to-br from-white via-white to-slate-50"
                      valueClassName="text-xl"
                    />
                    {showBudgetControls ? (
                      <SummaryPill
                        label="Selected Budget Total"
                        value={formatCurrency(selectedPlanCost)}
                        className="bg-gradient-to-br from-white via-white to-slate-50"
                        valueClassName="text-xl"
                      />
                    ) : null}
                  </div>
                </CardContent>
              ) : null}
            </Card>
          ) : null}

          {true ? (
            <TimelineEditor
              title="Project Timeline"
              rows={execution.timelineRows}
              totalProjectDurationDays={execution.totalProjectDurationDays}
              isLocked={isReadOnly}
              isOpen={timelineOpen}
              onToggleOpen={() => setTimelineOpen((current) => !current)}
              onToggleLock={setExecutionLocked}
              onSetTotalProjectDurationDays={setTotalProjectDurationDays}
              onUpdateRow={updateTimelineRow}
              onAddRow={addTimelineRow}
              onRemoveRow={removeTimelineRow}
              onDistributeDays={distributeTimelineDays}
            />
          ) : null}

          {showBudgetControls ? (
            <div className="grid gap-6">
              {orderedBudgetPlans.map((plan) => (
                <BudgetPlanCard
                  key={plan.id}
                  plan={plan}
                  isSelected={
                    execution.selectedPlan === "both" ||
                    (plan.key === "budget-a" && execution.selectedPlan === "optimal") ||
                    (plan.key === "budget-b" && execution.selectedPlan === "buffered")
                  }
                  isLocked={isReadOnly}
                  onUpdatePlan={(field, value) => updateExecutionBudgetPlan(plan.id, field, value)}
                  onAddRow={() => addExecutionBudgetRow(plan.id)}
                  onUpdateRow={(rowId, field, value) => updateExecutionBudgetRow(plan.id, rowId, field, value)}
                  onRemoveRow={(rowId) => removeExecutionBudgetRow(plan.id, rowId)}
                  onRemovePlan={() => removeExecutionBudgetPlan(plan.id)}
                />
              ))}
            </div>
          ) : null}

          <Card className="border-white/80">
            <CardHeader>
              <CardTitle>Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                rows={6}
                value={project.notes}
                onChange={(event) => updateProjectFields({ notes: event.target.value })}
                placeholder="Add execution assumptions, budget comparison remarks, or timeline notes."
                disabled={isReadOnly}
              />
            </CardContent>
          </Card>

          <Card className="border-white/80">
            <CardHeader>
              <CardTitle>Validation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {warnings.length > 0 ? (
                warnings.map((warning) => (
                  <div key={warning} className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                    {warning}
                  </div>
                ))
              ) : (
                <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900">
                  Execution estimate, budgets, and timeline look aligned.
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        {!isWizard ? (
          <ExecutionPreview
            projectName={project.projectName}
            selectedPlan={execution.selectedPlan}
            updatedAt={project.lastEditedAt}
            totalProjectDurationDays={execution.totalProjectDurationDays}
            timelineRows={execution.timelineRows}
            budgetPlans={orderedBudgetPlans}
            consultancyFee={consultancyTotals.grandTotal}
            finalEstimate={finalEstimate}
          />
        ) : null}
      </div>
    </div>
  );
}



