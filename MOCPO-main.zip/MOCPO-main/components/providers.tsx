"use client";

import type { ReactNode } from "react";
import { useEffect } from "react";
import { Toaster } from "sonner";

import { PdfOptionsProvider } from "@/components/shared/pdf-options-provider";
import type { ProjectRecord } from "@/lib/types";
import { useProposalStore } from "@/store/proposal-store";

export function Providers({ children }: { children: ReactNode }) {
  useEffect(() => {
    let active = true;

    const loadProjectsFromMongo = async () => {
      try {
        const response = await fetch("/api/proposals", { cache: "no-store" });
        const payload = (await response.json()) as { ok?: boolean; projects?: ProjectRecord[] };

        if (!active || !payload.ok || !Array.isArray(payload.projects) || payload.projects.length === 0) {
          return;
        }

        const [project, ...rest] = payload.projects;
        useProposalStore.setState((state) => ({
          ...state,
          project,
          proposals: [project, ...rest],
          activeProjectId: project.projectId,
        }));
      } catch (error) {
        console.error("Failed to hydrate proposals from MongoDB:", error);
      }
    };

    loadProjectsFromMongo();

    return () => {
      active = false;
    };
  }, []);

  return (
    <PdfOptionsProvider>
      {children}
      <Toaster richColors position="top-right" duration={15000} />
    </PdfOptionsProvider>
  );
}
