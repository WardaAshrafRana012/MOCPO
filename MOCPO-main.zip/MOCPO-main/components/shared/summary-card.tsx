import { ArrowDownRight, ArrowUpRight } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface SummaryCardProps {
  label: string;
  value: string;
  hint?: string;
  accent?: "navy" | "gold" | "emerald";
  trend?: "up" | "down";
}

const accentMap = {
  navy: "from-slate-900 to-blue-900 text-white",
  gold: "from-amber-400 to-orange-400 text-slate-950",
  emerald: "from-emerald-400 to-teal-400 text-slate-950",
};

export function SummaryCard({ label, value, hint, accent = "navy", trend }: SummaryCardProps) {
  return (
    <Card className="overflow-hidden border-white/70">
      <CardContent className="relative p-0">
        <div className={cn("absolute inset-x-0 top-0 h-1 bg-gradient-to-r", accentMap[accent])} />
        <div className="flex items-start justify-between p-4">
          <div>
            <p className="text-[11px] text-slate-500">{label}</p>
            <p className="mt-2 text-xl font-semibold text-slate-950">{value}</p>
            {hint ? <p className="mt-1 text-xs text-slate-500">{hint}</p> : null}
          </div>
          {trend ? (
            <div
              className={cn(
                "rounded-full p-2",
                trend === "up" ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600",
              )}
            >
              {trend === "up" ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
            </div>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
