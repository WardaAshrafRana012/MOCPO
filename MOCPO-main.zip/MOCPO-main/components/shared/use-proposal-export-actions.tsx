"use client";
import { toast } from "sonner";

import { usePdfOptionsWizard } from "@/components/shared/pdf-options-provider";
import { createDraftPdfBlob } from "@/lib/report";
import { createFileName } from "@/lib/calculations";
import type { DownloadKind, PreviewSectionKey, ProjectRecord, ProposalVersion } from "@/lib/types";
import { downloadBlob } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

const formatVersionMessageLabel = (versionLabel: string) => versionLabel.replace(/^V/i, "Version ");

async function fetchBlob(endpoint: string, payload: { project: ProjectRecord; version: ProposalVersion }) {
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`);
  }

  return response.blob();
}

export function useProposalExportActions() {
  const project = useProposalStore((state) => state.project);
  const { openPdfWizard } = usePdfOptionsWizard();
  const registerDownload = useProposalStore((state) => state.registerDownload);
  const saveDraft = useProposalStore((state) => state.saveDraft);
  const markFinalProposal = useProposalStore((state) => state.markFinalProposal);
  const saveAllSectionsToPreview = useProposalStore((state) => state.saveAllSectionsToPreview);
  const showOnlyPreviewSection = useProposalStore((state) => state.showOnlyPreviewSection);

  const notifyDownload = (kind: DownloadKind, versionLabel: string, filename: string) => {
    registerDownload(kind, versionLabel, filename);
    toast.success(`${kind.toUpperCase()} ready`, {
      description: filename,
    });
  };

  const previewDraftPdf = (version = project.draftVersion) => {
    const fileName = createFileName(project.projectName, version.versionLabel, "pdf");
    const blob = createDraftPdfBlob({ project, version });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank", "noopener,noreferrer");
    notifyDownload("pdf", version.versionLabel, fileName);
  };

  const downloadPdf = async (version = project.draftVersion) => {
    try {
      const fileName = createFileName(project.projectName, version.versionLabel, "pdf");
      const blob = await openPdfWizard(project, version);
      if (!blob) {
        return;
      }
      downloadBlob(blob, fileName);
      notifyDownload("pdf", version.versionLabel, fileName);
    } catch {
      toast.error("Could not generate PDF");
    }
  };

  const downloadXlsx = async (version = project.draftVersion) => {
    try {
      const fileName = createFileName(project.projectName, version.versionLabel, "xlsx");
      const blob = await fetchBlob("/api/export/xlsx", { project, version });
      downloadBlob(blob, fileName);
      notifyDownload("xlsx", version.versionLabel, fileName);
    } catch {
      toast.error("Could not generate XLSX");
    }
  };

  const downloadJson = (version = project.draftVersion) => {
    const fileName = createFileName(project.projectName, version.versionLabel, "proposal.json");
    const blob = new Blob([JSON.stringify(project, null, 2)], { type: "application/json" });
    downloadBlob(blob, fileName);
    notifyDownload("json", version.versionLabel, fileName);
  };

  const saveAndToast = () => {
    saveAllSectionsToPreview();
    const versionLabel = saveDraft();
    toast.success(`Changes saved to ${formatVersionMessageLabel(versionLabel)}.`);
  };

  const previewProposal = (section?: PreviewSectionKey) => {
    if (section) {
      showOnlyPreviewSection(section);
    }
    const versionLabel = saveDraft();
    toast.success(`Changes saved to ${formatVersionMessageLabel(versionLabel)}. Opening Preview Proposal.`);
    window.open("/preview-proposal", "_blank", "noopener,noreferrer");
  };

  const generateFinalProposal = (navigateToPreview = true) => {
    saveAllSectionsToPreview();
    saveDraft();
    markFinalProposal();
    if (navigateToPreview) {
      window.open("/preview-proposal", "_blank", "noopener,noreferrer");
    }
    toast.success("Final proposal is ready for review");
  };

  return {
    project,
    downloadJson,
    downloadPdf,
    downloadXlsx,
    generateFinalProposal,
    previewDraftPdf,
    previewProposal,
    saveAndToast,
  };
}
