/**
 * Hook to watch and display Drive sync status as toast notifications
 */

"use client";

import { useEffect } from "react";
import { toast } from "sonner";
import { useProposalStore } from "@/store/proposal-store";

let lastMessageAt = 0;
const DRIVE_SYNC_TOAST_ID = "drive-sync-status";

export function useDriveSyncStatusNotifier() {
  const driveSyncStatus = useProposalStore((state) => state.driveSyncStatus);

  useEffect(() => {
    if (
      driveSyncStatus.lastMessage &&
      driveSyncStatus.lastMessageAt > lastMessageAt
    ) {
      lastMessageAt = driveSyncStatus.lastMessageAt;

      if (driveSyncStatus.isSyncing) {
        toast.loading(driveSyncStatus.lastMessage, {
          id: DRIVE_SYNC_TOAST_ID,
          duration: Infinity,
        });
      } else if (driveSyncStatus.lastMessage.includes("failed")) {
        toast.error(driveSyncStatus.lastMessage, {
          id: DRIVE_SYNC_TOAST_ID,
        });
      } else {
        toast.success(driveSyncStatus.lastMessage, {
          id: DRIVE_SYNC_TOAST_ID,
        });
      }
    }
  }, [driveSyncStatus]);
}
