﻿"use client";

import { useEffect, useMemo, useState } from "react";
import { usePathname } from "next/navigation";

import { getProposalMemorySuggestions, useProposalMemory } from "@/components/shared/use-proposal-memory";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatDateTime, getEditableNumberInputValue } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

export function ProjectToolbar() {
  const project = useProposalStore((state) => state.project);
  const proposals = useProposalStore((state) => state.proposals);
  const updateProjectFields = useProposalStore((state) => state.updateProjectFields);
  const proposalMemory = useProposalMemory(proposals);
  const [lastEditedLabel, setLastEditedLabel] = useState<string | null>(null);
  const pathname = usePathname() ?? "";
  const showWorkspaceCard = ["/consultancy-fee", "/scope-breakup", "/execution-estimate"].includes(pathname);

  const visibleClientSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.clients, project.clientName),
    [proposalMemory.clients, project.clientName],
  );
  const visibleProjectSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.projects, project.projectName),
    [proposalMemory.projects, project.projectName],
  );
  const visibleLocationSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.locations, project.location),
    [proposalMemory.locations, project.location],
  );

  useEffect(() => {
    setLastEditedLabel(formatDateTime(project.lastEditedAt));
  }, [project.lastEditedAt]);

  if (!showWorkspaceCard) {
    return null;
  }

  return (
    <Card className="border-slate-200 bg-white">
      <CardContent className="space-y-5 p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">Shared project record</p>
            <h2 className="mt-2 text-xl font-semibold text-slate-950">Proposal workspace</h2>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="rounded-full border border-slate-200 bg-slate-100 px-3 py-1 text-xs font-semibold uppercase tracking-[0.14em] text-slate-700">
              {project.draftVersion.versionLabel}
            </div>
            <div className="text-sm text-slate-500">
              Last edited {lastEditedLabel ?? "syncing..."}
            </div>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          <div className="space-y-2">
            <Label htmlFor="clientName">Client name</Label>
            <Input
              id="clientName"
              type="text"
              list="toolbar-client-memory"
              autoComplete="off"
              value={project.clientName}
              onChange={(event) => updateProjectFields({ clientName: event.target.value })}
            />
            {visibleClientSuggestions.length > 0 ? (
              <datalist id="toolbar-client-memory">
                {visibleClientSuggestions.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="projectName">Project name</Label>
            <Input
              id="projectName"
              type="text"
              list="toolbar-project-memory"
              autoComplete="off"
              value={project.projectName}
              onChange={(event) => updateProjectFields({ projectName: event.target.value })}
            />
            {visibleProjectSuggestions.length > 0 ? (
              <datalist id="toolbar-project-memory">
                {visibleProjectSuggestions.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="areaSqFt">Area SQ.FT</Label>
            <Input
              id="areaSqFt"
              type="number"
              value={getEditableNumberInputValue(project.areaSqFt)}
              onChange={(event) => updateProjectFields({ areaSqFt: Number(event.target.value || 0) })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              type="text"
              list="toolbar-location-memory"
              autoComplete="off"
              value={project.location}
              onChange={(event) => updateProjectFields({ location: event.target.value })}
            />
            {visibleLocationSuggestions.length > 0 ? (
              <datalist id="toolbar-location-memory">
                {visibleLocationSuggestions.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            ) : null}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
