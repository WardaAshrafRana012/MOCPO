"use client";

import { cn } from "@/lib/utils";

type StepItem = {
  key: string;
  label: string;
  title: string;
};

export function StepIndicator({
  steps,
  activeKey,
  onStepClick,
}: {
  steps: StepItem[];
  activeKey: string;
  onStepClick?: (key: string) => void;
}) {
  const activeIndex = steps.findIndex((step) => step.key === activeKey);

  return (
    <div className="overflow-x-auto">
      <div className="flex min-w-max gap-2">
        {steps.map((step, index) => {
          const isActive = step.key === activeKey;
          const isComplete = index < activeIndex;

          return (
            <button
              key={step.key}
              type="button"
              onClick={() => onStepClick?.(step.key)}
              className={cn(
                "rounded-2xl border px-4 py-3 text-left transition",
                isActive
                  ? "border-[#1F2937] bg-[#1F2937] text-white shadow-[0_14px_32px_rgba(31,41,55,0.18)]"
                  : isComplete
                    ? "border-[#d8c3a5] bg-[#f6efe6] text-[#16202A]"
                    : "border-[#E8E8E8] bg-white text-[#5F6B78] hover:border-[#d2d7dd]",
              )}
            >
              <p className={cn("text-[11px] font-semibold uppercase tracking-[0.16em]", isActive ? "text-white/70" : "text-[#7a8896]")}>
                {step.label}
              </p>
              <p className={cn("mt-1 text-sm font-semibold", isActive ? "text-white" : "text-[#16202A]")}>{step.title}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
