import { Badge } from "@/components/ui/badge";
import type { ProposalStatus } from "@/lib/types";

export function StatusBadge({ status }: { status: ProposalStatus }) {
  const variant = status === "final" ? "success" : status === "saved" ? "default" : "warning";
  return <Badge variant={variant}>{status}</Badge>;
}
