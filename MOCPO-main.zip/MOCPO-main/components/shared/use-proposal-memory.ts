﻿"use client";

import { useEffect, useState } from "react";

import type { ProjectRecord } from "@/lib/types";

const PROPOSAL_MEMORY_STORAGE_KEY = "mocpo-proposal-memory";

export type ProposalMemory = {
  clients: string[];
  projects: string[];
  locations: string[];
};

const emptyMemory: ProposalMemory = {
  clients: [],
  projects: [],
  locations: [],
};

function normalizeValues(values: string[]) {
  return Array.from(
    new Set(
      values
        .map((value) => value.trim())
        .filter(Boolean),
    ),
  ).sort((left, right) => left.localeCompare(right));
}

function readProposalMemory(): ProposalMemory {
  if (typeof window === "undefined") {
    return emptyMemory;
  }

  try {
    const stored = window.localStorage.getItem(PROPOSAL_MEMORY_STORAGE_KEY);
    if (!stored) {
      return emptyMemory;
    }

    const parsed = JSON.parse(stored) as Partial<ProposalMemory>;
    return {
      clients: normalizeValues(parsed.clients ?? []),
      projects: normalizeValues(parsed.projects ?? []),
      locations: normalizeValues(parsed.locations ?? []),
    };
  } catch {
    return emptyMemory;
  }
}

function collectProposalMemory(proposals: ProjectRecord[]): ProposalMemory {
  return {
    clients: normalizeValues(proposals.map((proposal) => proposal.clientName)),
    projects: normalizeValues(proposals.map((proposal) => proposal.projectName)),
    locations: normalizeValues(proposals.map((proposal) => proposal.location)),
  };
}

function mergeProposalMemory(left: ProposalMemory, right: ProposalMemory): ProposalMemory {
  return {
    clients: normalizeValues([...left.clients, ...right.clients]),
    projects: normalizeValues([...left.projects, ...right.projects]),
    locations: normalizeValues([...left.locations, ...right.locations]),
  };
}

export function getProposalMemorySuggestions(values: string[], query: string) {
  const normalizedQuery = query.trim().toLowerCase();
  if (normalizedQuery.length < 2) {
    return [];
  }

  return values.filter((value) => value.toLowerCase().includes(normalizedQuery)).slice(0, 8);
}

export function useProposalMemory(proposals: ProjectRecord[]) {
  const [memory, setMemory] = useState<ProposalMemory>(emptyMemory);

  useEffect(() => {
    const storedMemory = readProposalMemory();
    const proposalMemory = collectProposalMemory(proposals);
    const nextMemory = mergeProposalMemory(storedMemory, proposalMemory);
    setMemory(nextMemory);

    if (typeof window !== "undefined") {
      window.localStorage.setItem(PROPOSAL_MEMORY_STORAGE_KEY, JSON.stringify(nextMemory));
    }
  }, [proposals]);

  return memory;
}
