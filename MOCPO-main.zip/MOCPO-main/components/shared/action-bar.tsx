import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

export function ActionBar({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "sticky bottom-2 z-30 rounded-xl border border-slate-200 bg-white/95 px-3 py-3 shadow-[0_12px_32px_rgba(15,23,42,0.10)] backdrop-blur-xl sm:bottom-0 sm:rounded-2xl sm:px-4 sm:py-4",
        className,
      )}
    >
      <div className="grid grid-cols-1 gap-2 sm:flex sm:flex-wrap sm:items-center sm:gap-3 max-sm:[&_button]:h-auto max-sm:[&_button]:min-h-10 max-sm:[&_button]:whitespace-normal max-sm:[&_button]:px-2 [&_button]:w-full sm:[&_button]:w-auto">
        {children}
      </div>
    </div>
  );
}
