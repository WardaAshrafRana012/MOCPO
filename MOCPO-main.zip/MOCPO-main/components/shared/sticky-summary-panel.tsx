import type { ReactNode } from "react";
import { AlertTriangle } from "lucide-react";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export function StickySummaryPanel({
  title,
  rows,
  warnings = [],
  footer,
}: {
  title: string;
  rows: { label: string; value: string }[];
  warnings?: string[];
  footer?: ReactNode;
}) {
  return (
    <Card className="sticky top-28 border-white/80">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-3">
          {rows.map((row) => (
            <div key={row.label} className="flex items-center justify-between gap-3 text-sm">
              <span className="text-slate-500">{row.label}</span>
              <span className="font-semibold text-slate-950">{row.value}</span>
            </div>
          ))}
        </div>
        {warnings.length > 0 ? (
          <>
            <Separator />
            <div className="space-y-2 rounded-2xl bg-amber-50 p-4 text-sm text-amber-800">
              <div className="flex items-center gap-2 font-semibold">
                <AlertTriangle className="h-4 w-4" />
                Missing field warnings
              </div>
              <ul className="space-y-2 pl-5">
                {warnings.map((warning) => (
                  <li key={warning} className="list-disc">
                    {warning}
                  </li>
                ))}
              </ul>
            </div>
          </>
        ) : null}
        {footer ? (
          <>
            <Separator />
            {footer}
          </>
        ) : null}
      </CardContent>
    </Card>
  );
}
