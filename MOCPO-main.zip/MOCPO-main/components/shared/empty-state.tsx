import { Inbox } from "lucide-react";

import { Card, CardContent } from "@/components/ui/card";

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <Card className="border-dashed border-slate-300 bg-white/60">
      <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
        <div className="rounded-full bg-slate-100 p-3 text-slate-500">
          <Inbox className="h-5 w-5" />
        </div>
        <div>
          <h3 className="text-base font-semibold text-slate-950">{title}</h3>
          <p className="mt-2 max-w-md text-sm text-slate-500">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}
