"use client";

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  GripVertical,
  ImagePlus,
  Layers3,
  LayoutTemplate,
  Sparkles,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { createDraftPdfBlob } from "@/lib/report";
import {
  applySavedPdfTemplate,
  createDefaultPdfOptions,
  getSelectedPdfSections,
  PDF_SECTION_LABELS,
  PDF_TEMPLATE_STORAGE_KEY,
  sanitizePdfTemplateOptions,
  type PdfImageLayout,
  type PdfSectionKey,
  type ProposalPdfOptions,
  type SavedPdfTemplate,
} from "@/lib/pdf-options";
import type { ProjectRecord, ProposalVersion } from "@/lib/types";
import { cn } from "@/lib/utils";

type WizardRequest = {
  project: ProjectRecord;
  version: ProposalVersion;
  resolve: (blob: Blob | null) => void;
};

type PdfOptionsWizardContextValue = {
  openPdfWizard: (project: ProjectRecord, version: ProposalVersion) => Promise<Blob | null>;
};

const PdfOptionsWizardContext = createContext<PdfOptionsWizardContextValue | null>(null);

const WIZARD_STEPS = [
  { id: "cover", label: "Cover", description: "Cover page and saved templates", icon: LayoutTemplate },
  { id: "summary", label: "Summary", description: "Summary text and project images", icon: Sparkles },
  { id: "sections", label: "Sections", description: "Extra pages and final order", icon: Layers3 },
  { id: "settings", label: "Settings", description: "PDF size, quality, and final output", icon: CheckCircle2 },
] as const;

function createId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function TemplateCard({
  checked,
  title,
  description,
  onClick,
}: {
  checked: boolean;
  title: string;
  description: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-2xl border px-4 py-4 text-left transition",
        checked ? "border-slate-900 bg-slate-950 text-white shadow-lg" : "border-slate-200 bg-white hover:border-slate-300",
      )}
    >
      <div className="text-sm font-semibold">{title}</div>
      <div className={cn("mt-1 text-sm", checked ? "text-slate-200" : "text-slate-500")}>{description}</div>
    </button>
  );
}

function ToggleRow({
  checked,
  label,
  description,
  onChange,
}: {
  checked: boolean;
  label: string;
  description: string;
  onChange: (checked: boolean) => void;
}) {
  return (
    <label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-4">
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} className="mt-1 h-4 w-4 rounded border-slate-300" />
      <div>
        <div className="text-sm font-semibold text-slate-900">{label}</div>
        <div className="mt-1 text-sm text-slate-500">{description}</div>
      </div>
    </label>
  );
}

export function PdfOptionsProvider({ children }: { children: ReactNode }) {
  const [request, setRequest] = useState<WizardRequest | null>(null);
  const [open, setOpen] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);
  const [options, setOptions] = useState<ProposalPdfOptions | null>(null);
  const [templates, setTemplates] = useState<SavedPdfTemplate[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const dragSectionRef = useRef<PdfSectionKey | null>(null);
  const dragImageRef = useRef<string | null>(null);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(PDF_TEMPLATE_STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw) as SavedPdfTemplate[];
      if (Array.isArray(parsed)) {
        setTemplates(parsed);
      }
    } catch (error) {
      console.error("Failed to load saved PDF templates:", error);
    }
  }, []);

  const persistTemplates = (nextTemplates: SavedPdfTemplate[]) => {
    setTemplates(nextTemplates);
    window.localStorage.setItem(PDF_TEMPLATE_STORAGE_KEY, JSON.stringify(nextTemplates));
  };

  const openPdfWizard = (project: ProjectRecord, version: ProposalVersion) => {
    return new Promise<Blob | null>((resolve) => {
      setRequest({ project, version, resolve });
      setOptions(createDefaultPdfOptions(project));
      setStepIndex(0);
      setOpen(true);
    });
  };

  const closeWizard = (result: Blob | null) => {
    request?.resolve(result);
    setRequest(null);
    setOptions(null);
    setStepIndex(0);
    setIsGenerating(false);
    setOpen(false);
  };

  const contextValue = useMemo<PdfOptionsWizardContextValue>(() => ({ openPdfWizard }), []);

  const selectedSections = request && options ? getSelectedPdfSections(request.project, request.version, options) : [];

  const updateOptions = (updater: (current: ProposalPdfOptions) => ProposalPdfOptions) => {
    setOptions((current) => (current ? updater(current) : current));
  };

  const moveSection = (fromKey: PdfSectionKey, toKey: PdfSectionKey) => {
    updateOptions((current) => {
      const nextOrder = [...current.sectionOrder];
      const fromIndex = nextOrder.indexOf(fromKey);
      const toIndex = nextOrder.indexOf(toKey);
      if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) {
        return current;
      }
      nextOrder.splice(fromIndex, 1);
      nextOrder.splice(toIndex, 0, fromKey);
      return { ...current, sectionOrder: nextOrder };
    });
  };

  const moveImage = (fromId: string, toId: string) => {
    updateOptions((current) => {
      const nextItems = [...current.imagesPage.items];
      const fromIndex = nextItems.findIndex((item) => item.id === fromId);
      const toIndex = nextItems.findIndex((item) => item.id === toId);
      if (fromIndex < 0 || toIndex < 0 || fromIndex === toIndex) {
        return current;
      }
      const [item] = nextItems.splice(fromIndex, 1);
      nextItems.splice(toIndex, 0, item);
      return {
        ...current,
        imagesPage: {
          ...current.imagesPage,
          items: nextItems,
        },
      };
    });
  };

  const onUploadCover = async (file: File | null) => {
    if (!file) return;
    const dataUrl = await fileToDataUrl(file);
    updateOptions((current) => ({
      ...current,
      coverPage: {
        ...current.coverPage,
        imageDataUrl: dataUrl,
      },
    }));
  };

  const onUploadImages = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const files = Array.from(fileList);
    const items = await Promise.all(
      files.map(async (file) => ({
        id: createId("pdf-image"),
        name: file.name,
        dataUrl: await fileToDataUrl(file),
        caption: file.name.replace(/\.[^.]+$/, ""),
      })),
    );
    updateOptions((current) => ({
      ...current,
      imagesPage: {
        ...current.imagesPage,
        enabled: true,
        items: [...current.imagesPage.items, ...items],
      },
    }));
  };

  const onSelectTemplate = (templateId: string) => {
    if (!request) return;
    if (templateId === "none") {
      setOptions(createDefaultPdfOptions(request.project));
      return;
    }
    const template = templates.find((item) => item.id === templateId);
    if (!template) return;
    setOptions(applySavedPdfTemplate(template, request.project));
  };

  const saveTemplateIfNeeded = (currentOptions: ProposalPdfOptions) => {
    if (!currentOptions.settings.saveAsTemplate) return currentOptions;
    const trimmedName = currentOptions.settings.templateName.trim();
    if (!trimmedName) {
      toast.error("Template name is required to save PDF settings.");
      return null;
    }
    const nextTemplate: SavedPdfTemplate = {
      id: currentOptions.settings.selectedTemplateId || createId("pdf-template"),
      name: trimmedName,
      updatedAt: new Date().toISOString(),
      options: sanitizePdfTemplateOptions({
        ...currentOptions,
        settings: {
          ...currentOptions.settings,
          saveAsTemplate: false,
        },
      }),
    };
    const withoutCurrent = templates.filter((item) => item.id !== nextTemplate.id);
    persistTemplates([nextTemplate, ...withoutCurrent]);
    toast.success(`Saved PDF template "${trimmedName}".`);
    return {
      ...currentOptions,
      settings: {
        ...currentOptions.settings,
        selectedTemplateId: nextTemplate.id,
        saveAsTemplate: false,
      },
    };
  };

  const onGeneratePdf = async () => {
    if (!request || !options) return;
    const hasSelectedSections = getSelectedPdfSections(request.project, request.version, options).length > 0;
    if (!hasSelectedSections) {
      toast.error("Select at least one PDF section before generating.");
      return;
    }

    const preparedOptions = saveTemplateIfNeeded(options);
    if (!preparedOptions) return;

    try {
      setIsGenerating(true);
      const blob = createDraftPdfBlob(
        { project: request.project, version: request.version },
        preparedOptions,
      );
      closeWizard(blob);
    } catch (error) {
      console.error("Failed to generate PDF:", error);
      toast.error("Could not generate the PDF with the selected options.");
      setIsGenerating(false);
    }
  };

  const canGoBack = stepIndex > 0;
  const canGoNext = stepIndex < WIZARD_STEPS.length - 1;

  return (
    <PdfOptionsWizardContext.Provider value={contextValue}>
      {children}
      <Dialog
        open={open}
        onOpenChange={(nextOpen) => {
          if (!nextOpen) {
            closeWizard(null);
          }
        }}
      >
        <DialogContent className="h-[92vh] max-h-[92vh] max-w-6xl overflow-hidden rounded-[32px] border-0 bg-transparent p-0 shadow-none">
          {request && options ? (
            <div className="grid h-full min-h-0 overflow-hidden rounded-[32px] border border-slate-200 bg-white shadow-[0_32px_120px_rgba(15,23,42,0.16)] lg:grid-cols-[1.35fr_0.65fr]">
              <div className="flex min-h-0 min-w-0 flex-col">
                <DialogHeader className="border-b border-slate-200 bg-[radial-gradient(circle_at_top_left,_rgba(245,158,11,0.16),_transparent_28%),linear-gradient(135deg,#0f172a,#1e3a5f)] px-8 py-7 text-left">
                  <DialogTitle className="text-2xl font-semibold text-white">PDF Options</DialogTitle>
                  <DialogDescription className="mt-2 max-w-2xl text-slate-200">
                    Choose the cover, summary, images, section order, and PDF settings before generating the final proposal.
                  </DialogDescription>
                  <div className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                    {WIZARD_STEPS.map((step, index) => {
                      const Icon = step.icon;
                      const active = index === stepIndex;
                      const complete = index < stepIndex;
                      return (
                        <button
                          key={step.id}
                          type="button"
                          onClick={() => setStepIndex(index)}
                          className={cn(
                            "rounded-2xl border px-4 py-3 text-left transition",
                            active
                              ? "border-white/40 bg-white/16 text-white"
                              : complete
                                ? "border-emerald-300/30 bg-emerald-400/10 text-white"
                                : "border-white/10 bg-white/6 text-slate-200 hover:bg-white/10",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <Icon className="h-4 w-4" />
                            <span className="text-sm font-semibold">{step.label}</span>
                          </div>
                          <div className="mt-2 text-xs text-slate-200">{step.description}</div>
                        </button>
                      );
                    })}
                  </div>
                </DialogHeader>

                <ScrollArea className="min-h-0 flex-1">
                  <div className="space-y-8 px-8 py-8">
                    {stepIndex === 0 ? (
                      <section className="space-y-6">
                        <div className="grid gap-4 lg:grid-cols-[1fr_1fr]">
                          <div className="rounded-3xl border border-slate-200 bg-slate-50/80 p-5">
                            <div className="text-sm font-semibold text-slate-900">Saved PDF Template</div>
                            <div className="mt-2 text-sm text-slate-500">Reuse a saved setup for recurring proposals, then tweak only the few fields that change.</div>
                            <div className="mt-4">
                              <Select value={options.settings.selectedTemplateId || "none"} onValueChange={onSelectTemplate}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select saved PDF template" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="none">Start from current defaults</SelectItem>
                                  {templates.map((template) => (
                                    <SelectItem key={template.id} value={template.id}>
                                      {template.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <div className="rounded-3xl border border-slate-200 bg-slate-50/80 p-5">
                            <div className="text-sm font-semibold text-slate-900">Cover Page</div>
                            <div className="mt-2 text-sm text-slate-500">Add a dedicated opening page before the proposal summary.</div>
                            <label className="mt-4 inline-flex items-center gap-3 rounded-full bg-white px-4 py-2 ring-1 ring-slate-200">
                              <input
                                type="checkbox"
                                checked={options.coverPage.enabled}
                                onChange={(event) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    coverPage: {
                                      ...current.coverPage,
                                      enabled: event.target.checked,
                                    },
                                  }))
                                }
                              />
                              <span className="text-sm font-medium text-slate-900">Add Cover Page</span>
                            </label>
                          </div>
                        </div>

                        {options.coverPage.enabled ? (
                          <div className="grid gap-5 xl:grid-cols-[0.95fr_1.05fr]">
                            <div className="rounded-3xl border border-slate-200 bg-white p-5">
                              <div className="text-sm font-semibold text-slate-900">Cover Template</div>
                              <div className="mt-4 grid gap-3 sm:grid-cols-3">
                                <TemplateCard
                                  checked={options.coverPage.template === "branded"}
                                  title="Branded"
                                  description="Bold hero cover with image and project details."
                                  onClick={() =>
                                    updateOptions((current) => ({
                                      ...current,
                                      coverPage: { ...current.coverPage, template: "branded" },
                                    }))
                                  }
                                />
                                <TemplateCard
                                  checked={options.coverPage.template === "classic"}
                                  title="Classic"
                                  description="Balanced professional layout with a calmer header."
                                  onClick={() =>
                                    updateOptions((current) => ({
                                      ...current,
                                      coverPage: { ...current.coverPage, template: "classic" },
                                    }))
                                  }
                                />
                                <TemplateCard
                                  checked={options.coverPage.template === "minimal"}
                                  title="Minimal"
                                  description="Simple clean title page with restrained styling."
                                  onClick={() =>
                                    updateOptions((current) => ({
                                      ...current,
                                      coverPage: { ...current.coverPage, template: "minimal" },
                                    }))
                                  }
                                />
                              </div>

                              <div className="mt-5 rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-5">
                                <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                                  <ImagePlus className="h-4 w-4" />
                                  Upload Cover Image
                                </div>
                                <div className="mt-2 text-sm text-slate-500">Use a project rendering, concept sketch, or site image for a more polished first page.</div>
                                <Input type="file" accept="image/*" className="mt-4" onChange={(event) => onUploadCover(event.target.files?.[0] ?? null)} />
                                {options.coverPage.imageDataUrl ? (
                                  <img src={options.coverPage.imageDataUrl} alt="Cover preview" className="mt-4 h-40 w-full rounded-2xl object-cover" />
                                ) : null}
                              </div>
                            </div>

                            <div className="rounded-3xl border border-slate-200 bg-white p-5">
                              <div className="grid gap-4 md:grid-cols-2">
                                <div className="md:col-span-2">
                                  <label className="text-sm font-medium text-slate-700">Project title</label>
                                  <Input
                                    value={options.coverPage.projectTitle}
                                    onChange={(event) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        coverPage: { ...current.coverPage, projectTitle: event.target.value },
                                      }))
                                    }
                                    placeholder="Powerplant Master Proposal"
                                    className="mt-2"
                                  />
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-slate-700">Client name</label>
                                  <Input
                                    value={options.coverPage.clientName}
                                    onChange={(event) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        coverPage: { ...current.coverPage, clientName: event.target.value },
                                      }))
                                    }
                                    placeholder="Enter client name"
                                    className="mt-2"
                                  />
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-slate-700">Proposal date</label>
                                  <Input
                                    value={options.coverPage.proposalDate}
                                    onChange={(event) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        coverPage: { ...current.coverPage, proposalDate: event.target.value },
                                      }))
                                    }
                                    placeholder="2026-07-06"
                                    className="mt-2"
                                  />
                                </div>
                                <div className="md:col-span-2">
                                  <label className="text-sm font-medium text-slate-700">Prepared by / company name</label>
                                  <Input
                                    value={options.coverPage.preparedBy}
                                    onChange={(event) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        coverPage: { ...current.coverPage, preparedBy: event.target.value },
                                      }))
                                    }
                                    placeholder="Molecule Work Place Solution"
                                    className="mt-2"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        ) : null}
                      </section>
                    ) : null}

                    {stepIndex === 1 ? (
                      <section className="space-y-6">
                        <div className="rounded-3xl border border-slate-200 bg-white p-5">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                              <div className="text-sm font-semibold text-slate-900">Project Summary</div>
                              <div className="mt-1 text-sm text-slate-500">Add a narrative summary before the technical proposal pages.</div>
                            </div>
                            <label className="inline-flex items-center gap-3 rounded-full bg-slate-50 px-4 py-2 ring-1 ring-slate-200">
                              <input
                                type="checkbox"
                                checked={options.projectSummary.enabled}
                                onChange={(event) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    projectSummary: {
                                      ...current.projectSummary,
                                      enabled: event.target.checked,
                                    },
                                  }))
                                }
                              />
                              <span className="text-sm font-medium text-slate-900">Add Project Summary</span>
                            </label>
                          </div>

                          {options.projectSummary.enabled ? (
                            <div className="mt-5 space-y-4">
                              <div className="grid gap-3 md:grid-cols-3">
                                {[
                                  { key: "auto", label: "Auto-generate summary", description: "Build a short summary from the proposal data already in the app." },
                                  { key: "manual", label: "Write summary manually", description: "Provide your own narrative for the PDF." },
                                  { key: "skip", label: "Skip summary text", description: "Keep the proposal summary page but without a narrative block." },
                                ].map((item) => (
                                  <label key={item.key} className="rounded-2xl border border-slate-200 px-4 py-4">
                                    <div className="flex items-start gap-3">
                                      <input
                                        type="radio"
                                        name="pdf-summary-mode"
                                        checked={options.projectSummary.mode === item.key}
                                        onChange={() =>
                                          updateOptions((current) => ({
                                            ...current,
                                            projectSummary: { ...current.projectSummary, mode: item.key as typeof current.projectSummary.mode },
                                          }))
                                        }
                                        className="mt-1"
                                      />
                                      <div>
                                        <div className="text-sm font-semibold text-slate-900">{item.label}</div>
                                        <div className="mt-1 text-sm text-slate-500">{item.description}</div>
                                      </div>
                                    </div>
                                  </label>
                                ))}
                              </div>
                              {options.projectSummary.mode === "manual" ? (
                                <div>
                                  <label className="text-sm font-medium text-slate-700">Manual summary</label>
                                  <Textarea
                                    value={options.projectSummary.manualSummary}
                                    onChange={(event) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        projectSummary: { ...current.projectSummary, manualSummary: event.target.value },
                                      }))
                                    }
                                    placeholder="Write a concise project overview, scope context, delivery intent, and any client-facing positioning you want in the PDF."
                                    className="mt-2 min-h-[180px]"
                                  />
                                </div>
                              ) : null}
                            </div>
                          ) : null}
                        </div>

                        <div className="rounded-3xl border border-slate-200 bg-white p-5">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                              <div className="text-sm font-semibold text-slate-900">Project Images</div>
                              <div className="mt-1 text-sm text-slate-500">Add renderings, reference shots, or site images with captions.</div>
                            </div>
                            <label className="inline-flex items-center gap-3 rounded-full bg-slate-50 px-4 py-2 ring-1 ring-slate-200">
                              <input
                                type="checkbox"
                                checked={options.imagesPage.enabled}
                                onChange={(event) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    imagesPage: { ...current.imagesPage, enabled: event.target.checked },
                                  }))
                                }
                              />
                              <span className="text-sm font-medium text-slate-900">Add Images Page</span>
                            </label>
                          </div>

                          {options.imagesPage.enabled ? (
                            <div className="mt-5 space-y-5">
                              <div className="grid gap-4 md:grid-cols-[1fr_220px]">
                                <div>
                                  <label className="text-sm font-medium text-slate-700">Upload multiple images</label>
                                  <Input type="file" accept="image/*" multiple className="mt-2" onChange={(event) => onUploadImages(event.target.files)} />
                                </div>
                                <div>
                                  <label className="text-sm font-medium text-slate-700">Image layout</label>
                                  <Select
                                    value={options.imagesPage.layout}
                                    onValueChange={(value) =>
                                      updateOptions((current) => ({
                                        ...current,
                                        imagesPage: { ...current.imagesPage, layout: value as PdfImageLayout },
                                      }))
                                    }
                                  >
                                    <SelectTrigger className="mt-2">
                                      <SelectValue placeholder="Choose layout" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="single">1 image per page</SelectItem>
                                      <SelectItem value="two-up">2 images per page</SelectItem>
                                      <SelectItem value="four-up">4 images per page</SelectItem>
                                      <SelectItem value="full-width">Full-width image</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>

                              <div className="grid gap-4">
                                {options.imagesPage.items.length === 0 ? (
                                  <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-5 py-8 text-sm text-slate-500">
                                    No images added yet. Upload one or more files to create an image section.
                                  </div>
                                ) : (
                                  options.imagesPage.items.map((item, index) => (
                                    <div
                                      key={item.id}
                                      draggable
                                      onDragStart={() => {
                                        dragImageRef.current = item.id;
                                      }}
                                      onDragOver={(event) => event.preventDefault()}
                                      onDrop={() => {
                                        if (dragImageRef.current) {
                                          moveImage(dragImageRef.current, item.id);
                                        }
                                        dragImageRef.current = null;
                                      }}
                                      className="grid gap-4 rounded-2xl border border-slate-200 bg-slate-50 p-4 lg:grid-cols-[120px_1fr_auto]"
                                    >
                                      <img src={item.dataUrl} alt={item.name} className="h-[110px] w-full rounded-2xl object-cover" />
                                      <div>
                                        <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                                          <GripVertical className="h-4 w-4 text-slate-400" />
                                          Image {index + 1}
                                        </div>
                                        <div className="mt-1 text-xs text-slate-500">{item.name}</div>
                                        <Input
                                          value={item.caption}
                                          onChange={(event) =>
                                            updateOptions((current) => ({
                                              ...current,
                                              imagesPage: {
                                                ...current.imagesPage,
                                                items: current.imagesPage.items.map((image) =>
                                                  image.id === item.id ? { ...image, caption: event.target.value } : image,
                                                ),
                                              },
                                            }))
                                          }
                                          placeholder="Add image caption"
                                          className="mt-3"
                                        />
                                      </div>
                                      <div className="flex items-start justify-end gap-2">
                                        <Button
                                          type="button"
                                          variant="outline"
                                          size="icon"
                                          onClick={() =>
                                            updateOptions((current) => ({
                                              ...current,
                                              imagesPage: {
                                                ...current.imagesPage,
                                                items: current.imagesPage.items.filter((image) => image.id !== item.id),
                                              },
                                            }))
                                          }
                                        >
                                          <Trash2 className="h-4 w-4" />
                                        </Button>
                                      </div>
                                    </div>
                                  ))
                                )}
                              </div>
                            </div>
                          ) : null}
                        </div>
                      </section>
                    ) : null}

                    {stepIndex === 2 ? (
                      <section className="space-y-6">
                        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                          <ToggleRow
                            checked={options.extraPages.tableOfContents}
                            label="Table of Contents"
                            description="Add a clean contents page for the selected PDF sections."
                            onChange={(checked) =>
                              updateOptions((current) => ({
                                ...current,
                                extraPages: { ...current.extraPages, tableOfContents: checked },
                              }))
                            }
                          />
                          <ToggleRow
                            checked={options.extraPages.companyProfile}
                            label="Company Profile"
                            description="Add a branded overview page about your company and delivery approach."
                            onChange={(checked) =>
                              updateOptions((current) => ({
                                ...current,
                                extraPages: { ...current.extraPages, companyProfile: checked },
                              }))
                            }
                          />
                          <ToggleRow
                            checked={options.extraPages.teamPage}
                            label="Team Page"
                            description="Insert a page describing the project team and responsibilities."
                            onChange={(checked) =>
                              updateOptions((current) => ({
                                ...current,
                                extraPages: { ...current.extraPages, teamPage: checked },
                              }))
                            }
                          />
                          <ToggleRow
                            checked={options.extraPages.termsAndConditions}
                            label="Terms & Conditions"
                            description="Include a final page with payment, validity, and scope notes."
                            onChange={(checked) =>
                              updateOptions((current) => ({
                                ...current,
                                extraPages: { ...current.extraPages, termsAndConditions: checked },
                              }))
                            }
                          />
                          <ToggleRow
                            checked={options.extraPages.signaturePage}
                            label="Signature Page"
                            description="Add signature lines for client approval and prepared-by signoff."
                            onChange={(checked) =>
                              updateOptions((current) => ({
                                ...current,
                                extraPages: { ...current.extraPages, signaturePage: checked },
                              }))
                            }
                          />
                        </div>

                        <div className="rounded-3xl border border-slate-200 bg-white p-5">
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              <div className="text-sm font-semibold text-slate-900">Section Order</div>
                              <div className="mt-1 text-sm text-slate-500">Drag selected sections to set the final PDF flow before generating.</div>
                            </div>
                          </div>

                          <div className="mt-5 grid gap-3">
                            {selectedSections.map((key, index) => (
                              <div
                                key={key}
                                draggable
                                onDragStart={() => {
                                  dragSectionRef.current = key;
                                }}
                                onDragOver={(event) => event.preventDefault()}
                                onDrop={() => {
                                  if (dragSectionRef.current) {
                                    moveSection(dragSectionRef.current, key);
                                  }
                                  dragSectionRef.current = null;
                                }}
                                className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3"
                              >
                                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-sm font-semibold text-slate-700 ring-1 ring-slate-200">
                                  {index + 1}
                                </div>
                                <GripVertical className="h-4 w-4 text-slate-400" />
                                <div className="flex-1">
                                  <div className="text-sm font-semibold text-slate-900">{PDF_SECTION_LABELS[key]}</div>
                                </div>
                                <div className="flex gap-2">
                                  <Button type="button" variant="outline" size="icon" onClick={() => index > 0 && moveSection(key, selectedSections[index - 1])}>
                                    <ArrowUp className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="icon"
                                    onClick={() => index < selectedSections.length - 1 && moveSection(key, selectedSections[index + 1])}
                                  >
                                    <ArrowDown className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </section>
                    ) : null}

                    {stepIndex === 3 ? (
                      <section className="space-y-6">
                        <div className="grid gap-5 xl:grid-cols-2">
                          <div className="rounded-3xl border border-slate-200 bg-white p-5">
                            <div className="text-sm font-semibold text-slate-900">PDF Settings</div>
                            <div className="mt-5 grid gap-4 md:grid-cols-2">
                              <div>
                                <label className="text-sm font-medium text-slate-700">Page size</label>
                                <Select
                                  value={options.settings.pageSize}
                                  onValueChange={(value) =>
                                    updateOptions((current) => ({
                                      ...current,
                                      settings: { ...current.settings, pageSize: value as ProposalPdfOptions["settings"]["pageSize"] },
                                    }))
                                  }
                                >
                                  <SelectTrigger className="mt-2">
                                    <SelectValue placeholder="Select page size" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="a4">A4</SelectItem>
                                    <SelectItem value="letter">Letter</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <label className="text-sm font-medium text-slate-700">Image quality</label>
                                <Select
                                  value={options.settings.imageQuality}
                                  onValueChange={(value) =>
                                    updateOptions((current) => ({
                                      ...current,
                                      settings: { ...current.settings, imageQuality: value as ProposalPdfOptions["settings"]["imageQuality"] },
                                    }))
                                  }
                                >
                                  <SelectTrigger className="mt-2">
                                    <SelectValue placeholder="Select image quality" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="high">High</SelectItem>
                                    <SelectItem value="medium">Medium</SelectItem>
                                    <SelectItem value="low">Low</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>

                            <div className="mt-5 grid gap-3">
                              <ToggleRow
                                checked={options.settings.showPageNumbers}
                                label="Show page numbers"
                                description="Display page numbers in the footer of the generated PDF."
                                onChange={(checked) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    settings: { ...current.settings, showPageNumbers: checked },
                                  }))
                                }
                              />
                              <ToggleRow
                                checked={options.settings.showHeaderFooter}
                                label="Show header and footer"
                                description="Keep the branded page header and footer on generated pages."
                                onChange={(checked) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    settings: { ...current.settings, showHeaderFooter: checked },
                                  }))
                                }
                              />
                            </div>
                          </div>

                          <div className="rounded-3xl border border-slate-200 bg-white p-5">
                            <div className="text-sm font-semibold text-slate-900">Save as Template</div>
                            <div className="mt-2 text-sm text-slate-500">Store this PDF setup in localStorage and bring it back the next time you generate a proposal.</div>
                            <label className="mt-4 inline-flex items-center gap-3 rounded-full bg-slate-50 px-4 py-2 ring-1 ring-slate-200">
                              <input
                                type="checkbox"
                                checked={options.settings.saveAsTemplate}
                                onChange={(event) =>
                                  updateOptions((current) => ({
                                    ...current,
                                    settings: { ...current.settings, saveAsTemplate: event.target.checked },
                                  }))
                                }
                              />
                              <span className="text-sm font-medium text-slate-900">Save these PDF settings as template</span>
                            </label>
                            {options.settings.saveAsTemplate ? (
                              <div className="mt-4">
                                <label className="text-sm font-medium text-slate-700">Template name</label>
                                <Input
                                  value={options.settings.templateName}
                                  onChange={(event) =>
                                    updateOptions((current) => ({
                                      ...current,
                                      settings: { ...current.settings, templateName: event.target.value },
                                    }))
                                  }
                                  placeholder="Executive Proposal Pack"
                                  className="mt-2"
                                />
                              </div>
                            ) : null}
                          </div>
                        </div>
                      </section>
                    ) : null}
                  </div>
                </ScrollArea>

                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 px-8 py-5">
                  <Button type="button" variant="ghost" onClick={() => closeWizard(null)}>
                    Cancel
                  </Button>
                  <div className="flex flex-wrap items-center gap-3">
                    <Button type="button" variant="outline" onClick={() => canGoBack && setStepIndex((current) => current - 1)} disabled={!canGoBack || isGenerating}>
                      Back
                    </Button>
                    {canGoNext ? (
                      <Button type="button" onClick={() => setStepIndex((current) => current + 1)} disabled={isGenerating}>
                        Next
                      </Button>
                    ) : (
                      <Button type="button" variant="accent" onClick={onGeneratePdf} disabled={isGenerating}>
                        {isGenerating ? "Generating PDF..." : "Generate PDF"}
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <aside className="min-h-0 overflow-y-auto border-t border-slate-200 bg-slate-50/70 lg:border-l lg:border-t-0">
                <div className="px-6 py-6">
                  <div className="text-sm font-semibold text-slate-900">Selected Section Order</div>
                  <div className="mt-2 text-sm text-slate-500">This is the order your final PDF will follow.</div>
                </div>
                <div className="px-6 pb-6">
                  <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
                    <div className="space-y-3">
                      {selectedSections.length === 0 ? (
                        <div className="rounded-2xl border border-dashed border-slate-300 px-4 py-8 text-center text-sm text-slate-500">
                          No sections selected yet.
                        </div>
                      ) : (
                        selectedSections.map((key, index) => (
                          <div key={key} className="flex items-center gap-3 rounded-2xl bg-slate-50 px-3 py-3">
                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-sm font-semibold text-slate-700 ring-1 ring-slate-200">
                              {index + 1}
                            </div>
                            <div className="text-sm font-medium text-slate-800">{PDF_SECTION_LABELS[key]}</div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  <div className="mt-5 rounded-3xl border border-slate-200 bg-white p-4">
                    <div className="text-sm font-semibold text-slate-900">Current Output</div>
                    <div className="mt-3 grid gap-3 text-sm text-slate-600">
                      <div className="flex items-center justify-between gap-3">
                        <span>Page size</span>
                        <span className="font-semibold text-slate-900">{options.settings.pageSize.toUpperCase()}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3">
                        <span>Image quality</span>
                        <span className="font-semibold capitalize text-slate-900">{options.settings.imageQuality}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3">
                        <span>Header / footer</span>
                        <span className="font-semibold text-slate-900">{options.settings.showHeaderFooter ? "Shown" : "Hidden"}</span>
                      </div>
                      <div className="flex items-center justify-between gap-3">
                        <span>Page numbers</span>
                        <span className="font-semibold text-slate-900">{options.settings.showPageNumbers ? "Shown" : "Hidden"}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </aside>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </PdfOptionsWizardContext.Provider>
  );
}

export function usePdfOptionsWizard() {
  const context = useContext(PdfOptionsWizardContext);
  if (!context) {
    throw new Error("usePdfOptionsWizard must be used within PdfOptionsProvider.");
  }
  return context;
}

async function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}
