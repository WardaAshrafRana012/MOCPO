/**
 * Component to browse and load proposals from Google Drive
 * Shows a hierarchical view of Drive folder structure
 */

"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ChevronRight,
  Download,
  FolderOpen,
  Loader2,
  Search,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";

import { SectionHeader } from "@/components/shared/section-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  getVersionDataFromDrive,
  isDriveSyncEnabled,
  listClientsFromDrive,
  listProjectsFromDrive,
  listVersionsFromDrive,
} from "@/lib/drive-sync";
import type { ProjectRecord } from "@/lib/types";
import { useProposalStore } from "@/store/proposal-store";

export function DriveProposalBrowser() {
  const importProjectData = useProposalStore(
    (state) => state.importProjectData
  );

  const [isEnabled, setIsEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [clients, setClients] = useState<Array<{ name: string; folderId: string }>>(
    []
  );
  const [selectedClient, setSelectedClient] = useState<string>("");
  const [projects, setProjects] = useState<Array<{ name: string; folderId: string }>>(
    []
  );
  const [selectedProject, setSelectedProject] = useState<string>("");
  const [versions, setVersions] = useState<
    Array<{ name: string; versionNumber: number; folderId: string }>
  >([]);
  const [clientSearch, setClientSearch] = useState("");
  const [projectSearch, setProjectSearch] = useState("");
  const [versionSearch, setVersionSearch] = useState("");

  // Check if Drive sync is enabled
  useEffect(() => {
    const enabled = isDriveSyncEnabled();
    setIsEnabled(enabled);
    if (enabled) {
      loadClients();
    }
  }, []);

  const loadClients = async () => {
    setIsLoading(true);
    try {
      const data = await listClientsFromDrive();
      setClients(data);
      if (data.length > 0) {
        setSelectedClient(data[0].name);
      }
    } catch (error) {
      toast.error("Failed to load clients from Drive");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadProjects = async (clientName: string) => {
    setIsLoading(true);
    try {
      const data = await listProjectsFromDrive(clientName);
      setProjects(data);
      setSelectedProject(data.length > 0 ? data[0].name : "");
    } catch (error) {
      toast.error("Failed to load projects from Drive");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadVersions = async (clientName: string, projectName: string) => {
    setIsLoading(true);
    try {
      const data = await listVersionsFromDrive(clientName, projectName);
      setVersions(data);
    } catch (error) {
      toast.error("Failed to load versions from Drive");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadVersion = async (
    clientName: string,
    projectName: string,
    versionNumber: number
  ) => {
    setIsLoading(true);
    try {
      const data = await getVersionDataFromDrive(
        clientName,
        projectName,
        versionNumber
      );
      if (data) {
        importProjectData(data as ProjectRecord);
        toast.success(`Loaded ${projectName} ${versionNumber} from Drive`);
      } else {
        toast.error("Failed to load version data from Drive");
      }
    } catch (error) {
      toast.error("Failed to load version from Drive");
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const visibleClients = useMemo(() => {
    const query = clientSearch.trim().toLowerCase();
    if (!query) return clients;
    return clients.filter((c) => c.name.toLowerCase().includes(query));
  }, [clients, clientSearch]);

  const visibleProjects = useMemo(() => {
    const query = projectSearch.trim().toLowerCase();
    if (!query) return projects;
    return projects.filter((p) => p.name.toLowerCase().includes(query));
  }, [projects, projectSearch]);

  const visibleVersions = useMemo(() => {
    const query = versionSearch.trim().toLowerCase();
    if (!query) return versions;
    return versions.filter((v) =>
      v.name.toLowerCase().includes(query) ||
      v.versionNumber.toString().includes(query)
    );
  }, [versions, versionSearch]);

  if (!isEnabled) {
    return (
      <div className="space-y-6">
        <SectionHeader
          eyebrow="Cloud Storage"
          title="Google Drive sync"
          description="Connect your proposals to Google Drive for cloud backup and access from multiple devices."
        />
        <Card className="border-slate-200 bg-slate-50">
          <CardContent className="px-6 py-8 text-center">
            <p className="text-sm text-slate-600">
              Google Drive sync is not configured. Add{" "}
              <code className="bg-slate-200 px-2 py-1 text-xs">
                NEXT_PUBLIC_APPS_SCRIPT_URL
              </code>{" "}
              to your{" "}
              <code className="bg-slate-200 px-2 py-1 text-xs">.env.local</code>{" "}
              file to enable this feature.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="Cloud Storage"
        title="Google Drive sync"
        description="Browse and load your proposals from Google Drive"
      />

      <div className="grid gap-6 xl:grid-cols-[320px_360px_minmax(0,1fr)]">
        {/* Clients */}
        <Card className="border-white/80">
          <CardHeader>
            <CardTitle>Clients</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                value={clientSearch}
                onChange={(e) => setClientSearch(e.target.value)}
                placeholder="Search clients"
                className="pl-9"
                disabled={isLoading}
              />
            </div>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {visibleClients.length > 0 ? (
                visibleClients.map((client) => (
                  <button
                    key={client.folderId}
                    type="button"
                    onClick={() => {
                      setSelectedClient(client.name);
                      loadProjects(client.name);
                    }}
                    className={`w-full rounded-2xl border p-4 text-left transition ${
                      selectedClient === client.name
                        ? "border-blue-300 bg-blue-50"
                        : "border-slate-200 bg-white hover:bg-slate-50"
                    }`}
                    disabled={isLoading}
                  >
                    <div className="flex items-start gap-3">
                      <div className="rounded-xl bg-white p-2 text-slate-700 shadow-sm">
                        <UserRound className="h-4 w-4" />
                      </div>
                      <p className="truncate font-semibold text-slate-950">
                        {client.name}
                      </p>
                    </div>
                  </button>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
                  No clients found
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Projects */}
        <Card className="border-white/80">
          <CardHeader>
            <CardTitle>Projects</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                value={projectSearch}
                onChange={(e) => setProjectSearch(e.target.value)}
                placeholder="Search projects"
                className="pl-9"
                disabled={isLoading}
              />
            </div>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {visibleProjects.length > 0 ? (
                visibleProjects.map((project) => (
                  <button
                    key={project.folderId}
                    type="button"
                    onClick={() => {
                      setSelectedProject(project.name);
                      loadVersions(selectedClient, project.name);
                    }}
                    className={`w-full rounded-2xl border p-4 text-left transition ${
                      selectedProject === project.name
                        ? "border-blue-300 bg-blue-50"
                        : "border-slate-200 bg-white hover:bg-slate-50"
                    }`}
                    disabled={isLoading}
                  >
                    <div className="flex items-start gap-3">
                      <div className="rounded-xl bg-white p-2 text-slate-700 shadow-sm">
                        <FolderOpen className="h-4 w-4" />
                      </div>
                      <p className="truncate font-semibold text-slate-950">
                        {project.name}
                      </p>
                    </div>
                  </button>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
                  {projects.length === 0
                    ? "Select a client first"
                    : "No projects found"}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Versions */}
        <Card className="border-white/80">
          <CardHeader>
            <CardTitle>Versions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input
                value={versionSearch}
                onChange={(e) => setVersionSearch(e.target.value)}
                placeholder="Search versions"
                className="pl-9"
                disabled={isLoading}
              />
            </div>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {visibleVersions.length > 0 ? (
                visibleVersions.map((version) => (
                  <button
                    key={version.folderId}
                    type="button"
                    onClick={() =>
                      loadVersion(
                        selectedClient,
                        selectedProject,
                        version.versionNumber
                      )
                    }
                    className="w-full rounded-2xl border border-slate-200 bg-white p-4 text-left transition hover:bg-slate-50 disabled:opacity-50"
                    disabled={isLoading}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <ChevronRight className="h-4 w-4 text-slate-400" />
                        <div>
                          <p className="font-semibold text-slate-950">
                            {version.name}
                          </p>
                        </div>
                      </div>
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin text-slate-400" />
                      ) : (
                        <Download className="h-4 w-4 text-slate-400" />
                      )}
                    </div>
                  </button>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
                  {versions.length === 0
                    ? "Select a project first"
                    : "No versions found"}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
