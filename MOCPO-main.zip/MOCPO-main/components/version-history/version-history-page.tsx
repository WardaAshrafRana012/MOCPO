﻿"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, FolderOpen, Loader2, PencilLine, RefreshCcw, Search, Trash2, UserRound } from "lucide-react";
import { toast } from "sonner";

import { SectionHeader } from "@/components/shared/section-header";
import { useProposalExportActions } from "@/components/shared/use-proposal-export-actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { getProposalSummaryCards } from "@/lib/proposal-summary-cards";
import { formatDateTime, formatNumber } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

const formatVersionMessageLabel = (versionLabel: string) => versionLabel.replace(/^V/i, "Version ");

function getClientFolderKey(clientName: string) {
  return clientName.trim().toLowerCase();
}

export function VersionHistoryPage() {
  const router = useRouter();
  const project = useProposalStore((state) => state.project);
  const proposals = useProposalStore((state) => state.proposals);
  const activeProjectId = useProposalStore((state) => state.activeProjectId);
  const selectProposal = useProposalStore((state) => state.selectProposal);
  const deleteClientFolder = useProposalStore((state) => state.deleteClientFolder);
  const deleteProject = useProposalStore((state) => state.deleteProject);
  const deleteSavedVersion = useProposalStore((state) => state.deleteSavedVersion);
  const restoreSavedVersion = useProposalStore((state) => state.restoreSavedVersion);
  const { downloadPdf, downloadXlsx } = useProposalExportActions();

  const [clientSearch, setClientSearch] = useState("");
  const [projectSearch, setProjectSearch] = useState("");
  const [versionSearch, setVersionSearch] = useState("");
  const [selectedClientKey, setSelectedClientKey] = useState("");
  const [selectedProjectId, setSelectedProjectId] = useState(activeProjectId);
  const [isSheetSyncing, setIsSheetSyncing] = useState(false);

  const proposalList = useMemo(() => proposals.filter((proposal) => proposal.savedVersions.length > 0), [proposals]);

  const clientGroups = useMemo(() => {
    const groups = new Map<string, { key: string; clientName: string; projects: typeof proposalList }>();

    for (const proposalItem of proposalList) {
      const clientName = proposalItem.clientName || "No client name";
      const key = getClientFolderKey(clientName);
      const existing = groups.get(key) ?? { key, clientName, projects: [] as typeof proposalList };
      existing.projects.push(proposalItem);
      groups.set(key, existing);
    }

    return Array.from(groups.values()).sort((left, right) => left.clientName.localeCompare(right.clientName));
  }, [proposalList]);

  const visibleClients = useMemo(() => {
    const query = clientSearch.trim().toLowerCase();
    if (!query) return clientGroups;

    return clientGroups.filter((client) => client.clientName.toLowerCase().includes(query));
  }, [clientGroups, clientSearch]);

  const effectiveClientKey = selectedClientKey || visibleClients[0]?.key || "";
  const selectedClient = visibleClients.find((client) => client.key === effectiveClientKey) ?? null;

  const visibleProjects = useMemo(() => {
    const query = projectSearch.trim().toLowerCase();
    if (query) {
      return proposalList.filter((proposalItem) =>
        proposalItem.projectName.toLowerCase().includes(query) ||
        proposalItem.clientName.toLowerCase().includes(query),
      );
    }

    return selectedClient?.projects ?? [];
  }, [projectSearch, proposalList, selectedClient]);

  const effectiveProjectId = visibleProjects.some((proposalItem) => proposalItem.projectId === selectedProjectId)
    ? selectedProjectId
    : visibleProjects[0]?.projectId ?? "";
  const selectedProject = visibleProjects.find((proposalItem) => proposalItem.projectId === effectiveProjectId) ?? null;
  const selectedProjectForVersions = selectedProject ?? project;

  const versions = useMemo(() => {
    const query = versionSearch.trim().toLowerCase();
    const allVersions = selectedProjectForVersions?.savedVersions ?? [];
    if (!query) return allVersions;

    return allVersions.filter((version) =>
      version.versionLabel.toLowerCase().includes(query) ||
      formatDateTime(version.savedAt).toLowerCase().includes(query),
    );
  }, [selectedProjectForVersions, versionSearch]);

  const openProject = (proposalItem: typeof proposalList[number]) => {
    setClientSearch("");
    setProjectSearch("");
    setSelectedClientKey(getClientFolderKey(proposalItem.clientName || "No client name"));
    setSelectedProjectId(proposalItem.projectId);
    setVersionSearch("");
    selectProposal(proposalItem.projectId);
  };

  const syncSheetToBackend = async () => {
    setIsSheetSyncing(true);

    try {
      const response = await fetch("/api/google/sheets/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({}),
      });
      const result = await response.json().catch(() => ({ ok: false, message: "Invalid backend response." }));

      if (!response.ok || !result.ok) {
        toast.error(result.message || "Sheet sync failed.");
        return;
      }

      toast.success(result.message || "Sheet synced to backend.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Sheet sync failed.");
    } finally {
      setIsSheetSyncing(false);
    }
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="Archive"
        title="Proposal history"
        actions={(
          <Button type="button" variant="secondary" onClick={syncSheetToBackend} disabled={isSheetSyncing}>
            {isSheetSyncing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCcw className="h-4 w-4" />}
            Refresh Backend Sync
          </Button>
        )}
      />

      <div className="grid gap-6 xl:grid-cols-[320px_360px_minmax(0,1fr)]">
        <Card className="border-white/80">
          <CardHeader>
            <CardTitle>Client Folders</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input value={clientSearch} onChange={(event) => setClientSearch(event.target.value)} placeholder="Search client folders" className="pl-9" />
            </div>
            <div className="space-y-2">
              {visibleClients.length > 0 ? (
                visibleClients.map((client) => (
                  <div
                    key={client.key}
                    className={`rounded-2xl border p-4 transition ${
                      client.key === effectiveClientKey ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-white"
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="rounded-xl bg-white p-2 text-slate-700 shadow-sm">
                        <UserRound className="h-4 w-4" />
                      </div>
                      <button
                        type="button"
                        className="min-w-0 flex-1 text-left"
                        onClick={() => {
                          setSelectedClientKey(client.key);
                          setSelectedProjectId(client.projects[0]?.projectId ?? "");
                          setProjectSearch("");
                          setVersionSearch("");
                        }}
                      >
                        <p className="truncate font-semibold text-slate-950">{client.clientName}</p>
                        <p className="mt-1 text-xs text-slate-500">{client.projects.length} project{client.projects.length === 1 ? "" : "s"}</p>
                      </button>
                      <Button type="button" variant="ghost" size="icon" onClick={() => deleteClientFolder(client.key)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
                  No client folders match this search.
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="border-white/80">
          <CardHeader className="space-y-3">
            <CardTitle>Projects</CardTitle>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <Input value={projectSearch} onChange={(event) => setProjectSearch(event.target.value)} placeholder="Search projects" className="pl-9" />
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {visibleProjects.length > 0 ? (
              visibleProjects.map((proposalItem) => {
                const active = proposalItem.projectId === effectiveProjectId;
                const isCrossClientSearch = projectSearch.trim().length > 0;

                return (
                  <div
                    key={proposalItem.projectId}
                    className={`rounded-2xl border p-4 transition ${active ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-white"}`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="rounded-xl bg-white p-2 text-slate-700 shadow-sm">
                        <FolderOpen className="h-4 w-4" />
                      </div>
                      <button
                        type="button"
                        className="min-w-0 flex-1 text-left"
                        onClick={() => openProject(proposalItem)}
                      >
                        <p className="truncate font-semibold text-slate-950">{proposalItem.projectName || "Untitled proposal"}</p>
                        <p className="mt-1 text-sm text-slate-500">{formatNumber(proposalItem.areaSqFt)} SQ.FT</p>
                        <p className="mt-1 text-xs text-slate-500">
                          {isCrossClientSearch ? `${proposalItem.clientName || "No client name"} - ` : ""}
                          Latest {proposalItem.savedVersions[0]?.versionLabel ?? proposalItem.draftVersion.versionLabel}
                        </p>
                      </button>
                      <Button type="button" variant="ghost" size="icon" onClick={() => deleteProject(proposalItem.projectId)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 px-4 py-8 text-center text-sm text-slate-500">
                No projects match this search.
              </div>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card className="border-white/80">
            <CardHeader className="space-y-3">
              <div>
                <CardTitle>{selectedProjectForVersions?.projectName || "Untitled proposal"}</CardTitle>
                <div className="mt-1 text-sm text-slate-500">
                  {selectedProjectForVersions?.clientName || "No client name"} - {formatNumber(selectedProjectForVersions?.areaSqFt ?? 0)} SQ.FT
                </div>
              </div>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                <Input value={versionSearch} onChange={(event) => setVersionSearch(event.target.value)} placeholder="Search version" className="pl-9" />
              </div>
            </CardHeader>
          </Card>

          {versions.length > 0 ? (
            versions.map((version) => {
              const isActiveVersion = selectedProjectForVersions?.projectId === activeProjectId && version.id === project.draftVersion.id;
              const summaryCards = getProposalSummaryCards(selectedProjectForVersions ?? project, version);

              return (
                <Card key={version.id}>
                  <CardHeader className="flex-row flex-wrap items-center justify-between gap-4">
                    <div>
                      <CardTitle>{version.versionLabel}</CardTitle>
                      <p className="mt-1 text-sm text-slate-500">
                        {isActiveVersion ? `Current saved version - ${formatDateTime(version.savedAt)}` : `Saved ${formatDateTime(version.savedAt)}`}
                      </p>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      <Button asChild variant="secondary">
                        <Link href={`/preview-proposal?versionId=${version.id}`}>
                          <Eye className="h-4 w-4" />
                          View Version
                        </Link>
                      </Button>
                      {!isActiveVersion ? (
                        <Button
                          variant="secondary"
                          onClick={() => {
                            const fromLabel = version.versionLabel;
                            if (selectedProjectForVersions?.projectId && selectedProjectForVersions.projectId !== activeProjectId) {
                              selectProposal(selectedProjectForVersions.projectId);
                            }
                            restoreSavedVersion(version.id);
                            const toLabel = useProposalStore.getState().project.draftVersion.versionLabel;
                            toast.success(`${formatVersionMessageLabel(toLabel)} created from ${formatVersionMessageLabel(fromLabel)}. You are now editing ${formatVersionMessageLabel(toLabel)}.`);
                            router.push("/?stage=sections");
                          }}
                        >
                          <PencilLine className="h-4 w-4" />
                          Start New Version From This
                        </Button>
                      ) : null}
                      <Button variant="outline" onClick={() => downloadPdf(version)}>
                        PDF
                      </Button>
                      <Button variant="outline" onClick={() => downloadXlsx(version)}>
                        XLS
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => selectedProjectForVersions && deleteSavedVersion(selectedProjectForVersions.projectId, version.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                    {summaryCards.map((card) => (
                      <div key={card.key} className="rounded-2xl bg-slate-50 p-4">
                        <p className="text-sm text-slate-500">{card.label}</p>
                        <p className="mt-2 text-lg font-semibold text-slate-950">{card.value}</p>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Card className="border-white/80">
              <CardContent className="px-4 py-8 text-center text-sm text-slate-500">
                No versions match this search.
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}



