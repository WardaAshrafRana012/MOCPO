"use client";

import Link from "next/link";
import { ArrowRight, CheckCircle2, Clock3, TriangleAlert } from "lucide-react";

import { SectionHeader } from "@/components/shared/section-header";
import { SummaryCard } from "@/components/shared/summary-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { calculateConsultancyTotals, calculateFinalEstimate, calculateScopeTotals, getProposalProgress, getProposalWarnings } from "@/lib/calculations";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

const quickLinks = [
  { href: "/version-history", title: "Proposal History", description: "Open old proposals, versions, or start a new proposal." },
  { href: "/proposal-wizard", title: "Proposal Wizard", description: "Create a new proposal in one continuous guided flow." },
  { href: "/preview-proposal", title: "Preview Proposal", description: "Review exports and the final client-ready output." },
];

export function DashboardPage() {
  const project = useProposalStore((state) => state.project);
  const version = project.draftVersion;
  const consultancyTotals = calculateConsultancyTotals(
    version.consultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(version.scopeSection);
  const progress = getProposalProgress(project, version);
  const warnings = getProposalWarnings(project, version);
  const finalEstimate = calculateFinalEstimate(version.executionSection);

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="Dashboard"
        title="Proposal operations at a glance"
        description="Keep the fee sheet, scope plan, estimate, versions, and exports moving from one shared record."
      />

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <SummaryCard label="Project Area" value={`${formatNumber(project.areaSqFt)} SQ.FT`} hint={project.location} />
        <SummaryCard label="Consultancy Fee" value={formatCurrency(consultancyTotals.grandTotal)} hint={`${consultancyTotals.deliverableCount} deliverables`} accent="gold" />
        <SummaryCard label="Execution Cost" value={formatCurrency(scopeTotals.selectedTotal)} hint={`${version.scopeSection.planMode} plan`} />
        <SummaryCard label="Final Estimate" value={formatCurrency(finalEstimate)} hint={project.draftVersion.versionLabel} accent="emerald" />
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.25fr_0.9fr]">
        <Card>
          <CardHeader>
            <CardTitle>Progress & validation</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="rounded-2xl bg-slate-950 p-5 text-white">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-slate-300">Completion</p>
                  <p className="mt-2 text-3xl font-semibold">{progress.percentage}%</p>
                </div>
                <div className="w-full max-w-xs rounded-full bg-white/10">
                  <div className="h-3 rounded-full bg-amber-400" style={{ width: `${progress.percentage}%` }} />
                </div>
              </div>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              {[
                { label: "Shared fields complete", done: Boolean(project.projectName && project.clientName && project.location) },
                { label: "Consultancy seeded", done: version.consultancySection.disciplines.length > 0 },
                { label: "Scope sheet ready", done: version.scopeSection.rows.length > 0 },
                { label: "Timeline locked", done: version.executionSection.isLocked },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-3 rounded-2xl border border-slate-200 p-4">
                  {item.done ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                  ) : (
                    <Clock3 className="h-5 w-5 text-amber-500" />
                  )}
                  <span className="text-sm font-medium text-slate-700">{item.label}</span>
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-amber-50 p-4 text-sm text-amber-800">
              <div className="mb-2 flex items-center gap-2 font-semibold">
                <TriangleAlert className="h-4 w-4" />
                Current warnings
              </div>
              <ul className="space-y-1 pl-5">
                {warnings.length > 0 ? warnings.map((warning) => <li key={warning} className="list-disc">{warning}</li>) : <li className="list-disc">Everything critical is in place.</li>}
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Quick actions</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              {quickLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="group rounded-2xl border border-slate-200 p-4 transition hover:border-amber-200 hover:bg-amber-50"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold text-slate-950">{link.title}</p>
                      <p className="mt-1 text-sm text-slate-500">{link.description}</p>
                    </div>
                    <ArrowRight className="h-4 w-4 text-slate-400 transition group-hover:text-amber-600" />
                  </div>
                </Link>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recent proposal versions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {project.savedVersions.slice(0, 4).map((versionItem) => (
                <div key={versionItem.id} className="flex items-center justify-between rounded-2xl border border-slate-200 p-4">
                  <div>
                    <p className="font-semibold text-slate-900">{versionItem.versionLabel}</p>
                    <p className="text-sm text-slate-500">{formatDateTime(versionItem.savedAt)}</p>
                  </div>
                  <Button asChild variant="ghost" size="sm">
                    <Link href="/version-history">Open</Link>
                  </Button>
                </div>
              ))}
              {project.savedVersions.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
                  Saved versions will show up here after the first version save.
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
