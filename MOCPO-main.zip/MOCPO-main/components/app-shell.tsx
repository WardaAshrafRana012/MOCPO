"use client";

import type { ReactNode } from "react";
import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Bot,
  Eye,
  FileStack,
  LayoutPanelLeft,
  Menu,
  PencilLine,
} from "lucide-react";

import { ProjectToolbar } from "@/components/shared/project-toolbar";
import { useDriveSyncStatusNotifier } from "@/components/shared/use-drive-sync-notifier";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const navigation = [
  { href: "/", label: "Proposal Builder", icon: Bot },
  { href: "/edit-proposal", label: "Edit Proposal", icon: PencilLine },
  { href: "/preview-proposal", label: "Preview Proposal", icon: Eye },
  { href: "/version-history", label: "Proposal History", icon: FileStack },
];

function SidebarNav({ compact = false, onNavigate }: { compact?: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();

  return (
    <nav className="space-y-2">
      {navigation.map((item) => {
        const Icon = item.icon;
        const active = pathname === item.href;

        const link = (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "group flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition-all",
              active
                ? "bg-white text-slate-950 shadow-lg"
                : "text-slate-300 hover:bg-white/10 hover:text-white",
            )}
          >
            <Icon className="h-4 w-4" />
            {!compact ? <span>{item.label}</span> : null}
          </Link>
        );

        if (!compact) return link;

        return (
          <TooltipProvider key={item.href}>
            <Tooltip>
              <TooltipTrigger asChild>{link}</TooltipTrigger>
              <TooltipContent side="right">{item.label}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      })}
    </nav>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [navHidden, setNavHidden] = useState(false);
  const pathname = usePathname() ?? "";
  const showToolbar = ["/consultancy-fee", "/scope-breakup", "/execution-estimate", "/edit-proposal"].includes(pathname);

  // Show Drive sync status notifications
  useDriveSyncStatusNotifier();

  return (
    <div className="min-h-screen bg-[#F7F6F3]">
      <div className="mx-auto flex min-h-screen max-w-[1780px] gap-5 px-3 py-4 lg:px-5 xl:px-6">
        <aside className={`${navHidden ? "hidden" : "hidden lg:flex lg:flex-col"} w-[286px] shrink-0 rounded-[24px] bg-[#16202A] p-5 text-white shadow-[0_24px_70px_rgba(22,32,42,0.18)]`}>
          <div className="mb-8 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => setNavHidden(true)}
              className="flex items-center gap-3 text-left transition-opacity hover:opacity-90"
            >
              <div className="rounded-2xl bg-amber-400/90 p-3 text-slate-950">
                <LayoutPanelLeft className="h-5 w-5" />
              </div>
              <div>
                <p className="text-lg font-semibold">MOCPO</p>
                <p className="text-sm text-slate-400">Proposal operating system</p>
              </div>
            </button>
          </div>
          <SidebarNav />
        </aside>

        <div className="flex min-w-0 flex-1 flex-col gap-5">
          {navHidden ? (
            <div className="hidden items-center gap-2 rounded-[20px] border border-[#E8E8E8] bg-white p-3 shadow-[0_14px_32px_rgba(22,32,42,0.06)] lg:flex">
              <button
                type="button"
                onClick={() => setNavHidden(false)}
                className="flex items-center gap-3 rounded-2xl px-2 py-1 text-left transition-opacity hover:opacity-90"
              >
                <div className="rounded-2xl bg-amber-400/90 p-3 text-slate-950">
                  <LayoutPanelLeft className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-slate-950">MOCPO</p>
                </div>
              </button>
            </div>
          ) : null}
          <div className="flex items-center justify-between rounded-[20px] border border-[#E8E8E8] bg-white px-4 py-3 shadow-[0_14px_32px_rgba(22,32,42,0.06)] lg:hidden">
            <div>
              <p className="text-sm font-semibold text-slate-950">MOCPO</p>
              <p className="text-xs text-slate-500">Proposal workspace</p>
            </div>
            <Sheet>
              <SheetTrigger asChild>
                <Button size="icon" variant="secondary">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="mb-8">
                  <p className="text-lg font-semibold">Navigation</p>
                  <p className="text-sm text-slate-400">Move through the purchase order workflow.</p>
                </div>
                <SidebarNav onNavigate={() => undefined} />
              </SheetContent>
            </Sheet>
          </div>

          {showToolbar ? <ProjectToolbar /> : null}

          <ScrollArea className="flex-1">
            <main className="pb-8">{children}</main>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}
