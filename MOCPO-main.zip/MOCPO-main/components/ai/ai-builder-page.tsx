﻿"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, ArrowRight, Bot, Eye, GitBranchPlus, RefreshCcw, Save, WalletCards } from "lucide-react";
import { toast } from "sonner";

import { ConsultancyPage } from "@/components/consultancy/consultancy-page";
import { ExecutionPage } from "@/components/execution/execution-page";
import { PaymentScheduleDialog } from "@/components/payment-schedule/payment-schedule-dialog";
import { ScopePage } from "@/components/scope/scope-page";
import { ActionBar } from "@/components/shared/action-bar";
import { getProposalMemorySuggestions, useProposalMemory } from "@/components/shared/use-proposal-memory";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { getExecutionPlanLabel } from "@/lib/calculations";
import { withDraftSummary } from "@/lib/ai-proposal-builder";
import { standardDisciplineOrder } from "@/lib/seeds";
import { standardScopeGroupOptions } from "@/lib/scope-sheet";
import type { AIConversationState, AIProposalDraft, ProjectRecord } from "@/lib/types";
import { formatDateTime, formatNumber } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

const formatVersionMessageLabel = (versionLabel: string) => versionLabel.replace(/^V/i, "Version ");

const stageTitles = [
  "Project Title",
  "Work Scope",
  "Consultancy Fee",
  "Work Scope Breakup",
  "Execution Estimate",
  "Review And Create",
] as const;

type StageSelectionState = {
  consultancy: boolean;
  scope: boolean;
  execution: boolean;
};

function buildStageSelectionFromProject(project: ProjectRecord): StageSelectionState {
  const previewSections = project.draftVersion.previewSections;

  return {
    consultancy: previewSections.consultancyFee,
    scope:
      previewSections.workScope ||
      previewSections.negativeList ||
      previewSections.optimalList ||
      previewSections.bufferedOptimalList,
    execution:
      previewSections.executionEstimate ||
      previewSections.timeline ||
      previewSections.budgetComparison ||
      project.draftVersion.executionSection.totalProjectDurationDays > 0,
  };
}

function GlassPanel({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`rounded-[28px] border border-white/60 bg-[rgba(255,255,255,0.76)] shadow-[0_24px_80px_rgba(15,23,42,0.08)] backdrop-blur-[22px] ${className}`}>
      {children}
    </div>
  );
}

function buildDraftFromProject(project: ProjectRecord): AIProposalDraft {
  const conversationDraft = project.aiConversation?.draft;

  return withDraftSummary({
    clientName: conversationDraft?.clientName || project.clientName || "",
    projectName: conversationDraft?.projectName || project.projectName || "",
    areaSqFt: conversationDraft?.areaSqFt || project.areaSqFt || 0,
    location: conversationDraft?.location || project.location || "",
    deliverables: conversationDraft?.deliverables?.length ? conversationDraft.deliverables : [],
    scopeGroupIds: conversationDraft?.scopeGroupIds?.length ? conversationDraft.scopeGroupIds : [],
    executionPlan: conversationDraft?.executionPlan || "Premium",
    selectedPlan: conversationDraft?.selectedPlan ?? project.draftVersion.executionSection.selectedPlan ?? null,
    timelineDays: conversationDraft?.timelineDays || project.draftVersion.executionSection.totalProjectDurationDays || 150,
    notes: conversationDraft?.notes || "AI-generated proposal draft prepared for review and inline editing.",
    includeLandscape: conversationDraft?.includeLandscape ?? null,
    summary: conversationDraft?.summary || "",
  });
}

function getCompletionStageIndex(draft: AIProposalDraft) {
  if (!draft.clientName.trim() || !draft.projectName.trim() || !draft.areaSqFt || !draft.location.trim()) return 0;
  if (draft.deliverables.length === 0) return 2;
  if (draft.scopeGroupIds.length === 0) return 3;
  if (!draft.executionPlan.trim() || !draft.timelineDays) return 4;
  return 5;
}

export function ProposalWorkspace() {
  const router = useRouter();
  const [paymentScheduleOpen, setPaymentScheduleOpen] = useState(false);
  const project = useProposalStore((state) => state.project);
  const saveDraft = useProposalStore((state) => state.saveDraft);
  const createNextVersion = useProposalStore((state) => state.createNextVersion);
  const savePaymentSchedule = useProposalStore((state) => state.savePaymentSchedule);
  const previewSections = project.draftVersion.previewSections;
  const showConsultancyWorkspace = previewSections.consultancyFee;
  const showScopeWorkspace =
    previewSections.workScope ||
    previewSections.negativeList ||
    previewSections.optimalList ||
    previewSections.bufferedOptimalList;
  const showExecutionWorkspace =
    previewSections.executionEstimate ||
    previewSections.timeline ||
    previewSections.budgetComparison;

  const workspaceMetrics = useMemo(
    () => [
      { label: "Client", value: project.clientName || "Pending" },
      { label: "Project", value: project.projectName || "Untitled" },
      { label: "Area", value: `${formatNumber(project.areaSqFt)} sqft` },
      { label: "Location", value: project.location || "Pending" },
      { label: "Version", value: project.draftVersion.versionLabel },
      { label: "Last Saved", value: formatDateTime(project.lastEditedAt) },
    ],
    [project],
  );

  return (
    <div className="space-y-6">
      <GlassPanel>
        <div className="grid gap-5 p-6 lg:grid-cols-[1.25fr_minmax(0,1fr)]">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#A36C2C]">Edit Proposal</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">Edit proposal sections</h2>
            <p className="mt-3 text-sm font-medium text-slate-600">Currently Editing: {formatVersionMessageLabel(project.draftVersion.versionLabel)}</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {workspaceMetrics.map((metric) => (
              <div key={metric.label} className="rounded-2xl border border-slate-200 bg-white/80 px-4 py-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">{metric.label}</p>
                <p className="mt-2 text-sm font-semibold text-slate-950">{metric.value}</p>
              </div>
            ))}
          </div>
        </div>
      </GlassPanel>

      {showConsultancyWorkspace ? (
        <div id="workspace-consultancy">
          <ConsultancyPage mode="ai-workspace" sectionLocked={false} />
        </div>
      ) : null}
      {showScopeWorkspace ? (
        <div id="workspace-scope">
          <ScopePage mode="ai-workspace" sectionLocked={false} lockScopeSelection={false} />
        </div>
      ) : null}
      {showExecutionWorkspace ? (
        <div id="workspace-execution">
          <ExecutionPage mode="ai-workspace" sectionLocked={false} />
        </div>
      ) : null}

      <ActionBar>
        <Button
          variant="secondary"
          onClick={async () => {
            const versionLabel = saveDraft();
            toast.success(`${formatVersionMessageLabel(versionLabel)} saved successfully.`);
            // Sync to Drive asynchronously
            await useProposalStore.getState().syncVersionToDrive();
          }}
        >
          <Save className="h-4 w-4" />
          Save Version
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            const sourceLabel = project.draftVersion.versionLabel;
            createNextVersion();
            const newLabel = useProposalStore.getState().project.draftVersion.versionLabel;
            toast.success(`${formatVersionMessageLabel(newLabel)} created from ${formatVersionMessageLabel(sourceLabel)}. You are now editing ${formatVersionMessageLabel(newLabel)}.`);
            router.push("/?stage=sections");
          }}
        >
          <GitBranchPlus className="h-4 w-4" />
          Create New Version
        </Button>
        <Button variant="outline" onClick={() => setPaymentScheduleOpen(true)}>
          <WalletCards className="h-4 w-4" />
          Add Payment Schedule
        </Button>
        <Button variant="accent" onClick={async () => { const versionLabel = saveDraft(); toast.success(`${formatVersionMessageLabel(versionLabel)} saved successfully. Opening Preview Proposal.`); await useProposalStore.getState().syncVersionToDrive(); router.push("/preview-proposal"); }}>
          <Eye className="h-4 w-4" />
          Preview Proposal
        </Button>
      </ActionBar>

      <PaymentScheduleDialog
        open={paymentScheduleOpen}
        onOpenChange={setPaymentScheduleOpen}
        project={project}
        version={project.draftVersion}
        onSave={(paymentSchedule) => {
          savePaymentSchedule(paymentSchedule);
          toast.success(`Payment schedule saved to ${formatVersionMessageLabel(project.draftVersion.versionLabel)}.`);
        }}
      />
    </div>
  );
}

export function AIBuilderPage() {
  const router = useRouter();
  const project = useProposalStore((state) => state.project);
  const proposals = useProposalStore((state) => state.proposals);
  const createNewProposal = useProposalStore((state) => state.createNewProposal);
  const updateAIConversation = useProposalStore((state) => state.updateAIConversation);
  const generateProposalFromDraft = useProposalStore((state) => state.generateProposalFromDraft);
  const saveDraft = useProposalStore((state) => state.saveDraft);
  const setProposalSectionVisibility = useProposalStore((state) => state.setProposalSectionVisibility);
  const [wizardDraft, setWizardDraft] = useState<AIProposalDraft>(() => buildDraftFromProject(project));
  const [stageIndex, setStageIndex] = useState(0);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [selectedStages, setSelectedStages] = useState<StageSelectionState>(() => buildStageSelectionFromProject(project));
  const [lastKnownVersionId, setLastKnownVersionId] = useState(() => project.draftVersion.id);
  const proposalMemory = useProposalMemory(proposals);
  const clientSuggestions = useMemo(() => getProposalMemorySuggestions(proposalMemory.clients, wizardDraft.clientName), [proposalMemory.clients, wizardDraft.clientName]);
  const projectSuggestions = useMemo(() => getProposalMemorySuggestions(proposalMemory.projects, wizardDraft.projectName), [proposalMemory.projects, wizardDraft.projectName]);
  const locationSuggestions = useMemo(() => getProposalMemorySuggestions(proposalMemory.locations, wizardDraft.location), [proposalMemory.locations, wizardDraft.location]);

  useEffect(() => {
    if (project.draftVersion.id !== lastKnownVersionId) {
      setLastKnownVersionId(project.draftVersion.id);
      setSelectedStages(buildStageSelectionFromProject(project));
      setWizardDraft(buildDraftFromProject(project));
      setStageIndex(1);
    }
  }, [project, project.draftVersion.id, lastKnownVersionId]);

  useEffect(() => {
    setWizardDraft(buildDraftFromProject(project));
    setSelectedStages(buildStageSelectionFromProject(project));
  }, [project]);

  useEffect(() => {
    const requestedStage =
      typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("stage") : null;
    if (requestedStage === "sections") {
      setStageIndex(1);
      return;
    }

    setStageIndex((current) => Math.min(current, getCompletionStageIndex(buildDraftFromProject(project))));
  }, [project]);

  useEffect(() => {
    if (!statusMessage) return;
    const timer = window.setTimeout(() => setStatusMessage(null), 30000);
    return () => window.clearTimeout(timer);
  }, [statusMessage]);

  const visibleStageIndexes = useMemo(() => {
    const nextStages = [0, 1];
    if (selectedStages.consultancy) nextStages.push(2);
    if (selectedStages.scope) nextStages.push(3);
    if (selectedStages.execution) nextStages.push(4);
    nextStages.push(5);
    return nextStages;
  }, [selectedStages]);

  useEffect(() => {
    if (!visibleStageIndexes.includes(stageIndex)) {
      setStageIndex(visibleStageIndexes[0] ?? 0);
    }
  }, [stageIndex, visibleStageIndexes]);

  const currentStagePosition = Math.max(visibleStageIndexes.indexOf(stageIndex), 0);
  const nextStage = visibleStageIndexes[currentStagePosition + 1];
  const nextStepLabel = typeof nextStage === "number" ? stageTitles[nextStage] : null;

  const setField = <K extends keyof AIProposalDraft>(field: K, value: AIProposalDraft[K]) => {
    setWizardDraft((current) =>
      withDraftSummary({
        ...current,
        [field]: value,
      }),
    );
  };

  const toggleDeliverable = (name: AIProposalDraft["deliverables"][number]) => {
    setField(
      "deliverables",
      wizardDraft.deliverables.includes(name)
        ? wizardDraft.deliverables.filter((item) => item !== name)
        : [...wizardDraft.deliverables, name],
    );
  };

  const toggleScope = (scopeId: string) => {
    setField(
      "scopeGroupIds",
      wizardDraft.scopeGroupIds.includes(scopeId)
        ? wizardDraft.scopeGroupIds.filter((item) => item !== scopeId)
        : [...wizardDraft.scopeGroupIds, scopeId],
    );
  };

  const toggleStageSelection = (stage: keyof StageSelectionState) => {
    setSelectedStages((current) => ({
      ...current,
      [stage]: !current[stage],
    }));
  };

  const validateStage = (index: number) => {
    if (index === 0) {
      return Boolean(
        wizardDraft.clientName.trim() &&
          wizardDraft.projectName.trim() &&
          wizardDraft.areaSqFt > 0 &&
          wizardDraft.location.trim(),
      );
    }

    if (index === 1) {
      return selectedStages.consultancy || selectedStages.scope || selectedStages.execution;
    }
    if (index === 2) return wizardDraft.deliverables.length > 0;
    if (index === 3) return wizardDraft.scopeGroupIds.length > 0;
    if (index === 4) {
      if (wizardDraft.timelineDays <= 0) return false;
      return selectedStages.scope ? wizardDraft.selectedPlan !== null : true;
    }
    return true;
  };

  const handleNext = () => {
    if (!validateStage(stageIndex)) {
      toast.error("Please complete this stage first.");
      return;
    }

    const nextVisibleStage = visibleStageIndexes[currentStagePosition + 1];
    if (typeof nextVisibleStage === "number") {
      setStageIndex(nextVisibleStage);
    }
  };

  const handleBack = () => {
    const previousStage = visibleStageIndexes[currentStagePosition - 1];
    if (typeof previousStage === "number") {
      setStageIndex(previousStage);
    }
  };

  const handleCreateProposal = () => {
    const draft = withDraftSummary({
      ...wizardDraft,
      executionPlan: "Premium Turnkey Package",
      selectedPlan: selectedStages.scope ? wizardDraft.selectedPlan : null,
      notes: wizardDraft.notes.trim(),
    });
    const conversation: AIConversationState = {
      messages: [],
      combinedPrompt: "",
      draft,
      missingFields: [],
      readyToGenerate: true,
      status: "ready",
      lastGeneratedAt: new Date().toISOString(),
    };

    updateAIConversation(conversation);
    generateProposalFromDraft(draft, conversation);
    setProposalSectionVisibility("consultancyFee", selectedStages.consultancy);
    setProposalSectionVisibility("workScope", selectedStages.scope);
    setProposalSectionVisibility("negativeList", selectedStages.scope);
    setProposalSectionVisibility("optimalList", selectedStages.scope);
    setProposalSectionVisibility("bufferedOptimalList", selectedStages.scope);
    setProposalSectionVisibility("executionEstimate", selectedStages.execution);
    setProposalSectionVisibility("timeline", selectedStages.execution);
    setProposalSectionVisibility("budgetComparison", selectedStages.execution && selectedStages.scope);
    const versionLabel = saveDraft();

    if (project.savedVersions.length === 0) {
      const messageLabel = formatVersionMessageLabel(versionLabel);
      setStatusMessage(`${messageLabel} created. You are now editing ${messageLabel}.`);
      toast.success(`${messageLabel} created. You are now editing ${messageLabel}.`);
    } else {
      setStatusMessage("Proposal Draft Generated Successfully");
      toast.success("Proposal Draft Generated Successfully");
    }

    router.push("/edit-proposal");
  };

  const currentStageTitle = stageTitles[stageIndex];

  return (
    <div className="space-y-8">
      <GlassPanel className="mx-auto max-w-6xl">
        <div className="grid gap-6 p-6 lg:p-8">
          <div className="space-y-6">
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="rounded-2xl bg-[#16202A] p-3 text-white shadow-[0_18px_44px_rgba(22,32,42,0.16)]">
                  <Bot className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#A36C2C]">Proposal Builder</p>
                </div>
              </div>
            </div>

            <div className="rounded-[24px] border border-slate-200 bg-white/80 p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">Current stage</p>
                  <h2 className="mt-1 text-2xl font-semibold text-slate-950">{currentStageTitle}</h2>
                </div>
                <div className="rounded-full bg-slate-100 px-4 py-2 text-sm font-medium text-slate-700">
                  Step {currentStagePosition + 1} of {visibleStageIndexes.length}
                </div>
              </div>

              <div className="mt-5 space-y-5">
                {stageIndex === 0 ? (
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-900">1. Client Name</p>
                      <Input list="builder-client-memory" autoComplete="off" value={wizardDraft.clientName} onChange={(event) => setField("clientName", event.target.value)} placeholder="Enter client name" />
                      {clientSuggestions.length > 0 ? (
                        <datalist id="builder-client-memory">
                          {clientSuggestions.map((suggestion) => (
                            <option key={suggestion} value={suggestion} />
                          ))}
                        </datalist>
                      ) : null}
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-900">2. Project Name</p>
                      <Input list="builder-project-memory" autoComplete="off" value={wizardDraft.projectName} onChange={(event) => setField("projectName", event.target.value)} placeholder="Enter project name" />
                      {projectSuggestions.length > 0 ? (
                        <datalist id="builder-project-memory">
                          {projectSuggestions.map((suggestion) => (
                            <option key={suggestion} value={suggestion} />
                          ))}
                        </datalist>
                      ) : null}
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-900">3. Area In Square Feet</p>
                      <Input
                        type="number"
                        value={wizardDraft.areaSqFt || ""}
                        onChange={(event) => setField("areaSqFt", Number(event.target.value || 0))}
                        placeholder="Enter project area"
                      />
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-slate-900">4. Location</p>
                      <Input list="builder-location-memory" autoComplete="off" value={wizardDraft.location} onChange={(event) => setField("location", event.target.value)} placeholder="Enter project location" />
                      {locationSuggestions.length > 0 ? (
                        <datalist id="builder-location-memory">
                          {locationSuggestions.map((suggestion) => (
                            <option key={suggestion} value={suggestion} />
                          ))}
                        </datalist>
                      ) : null}
                    </div>
                  </div>
                ) : null}

                {stageIndex === 1 ? (
                  <div className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div>
                      <p className="text-sm font-medium text-slate-900">Choose sections for this proposal</p>
                      <p className="mt-1 text-sm text-slate-600">Only the selected sections will be included in preview and final output.</p>
                    </div>
                    <div className="grid gap-3 sm:grid-cols-3">
                      {[
                        { key: "consultancy" as const, label: "Consultancy Fee" },
                        { key: "scope" as const, label: "Work Scope Breakup" },
                        { key: "execution" as const, label: "Execution Estimate" },
                      ].map((stage) => {
                        const selected = selectedStages[stage.key];
                        return (
                          <button
                            key={stage.key}
                            type="button"
                            onClick={() => toggleStageSelection(stage.key)}
                            className={`rounded-2xl border px-4 py-4 text-left transition ${
                              selected ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white hover:border-amber-200 hover:bg-amber-50"
                            }`}
                          >
                            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">
                              {selected ? "Selected" : "Optional"}
                            </p>
                            <p className="mt-2 font-semibold text-slate-950">{stage.label}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : null}

                {stageIndex === 2 ? (
                  <div className="space-y-4">
                    <p className="text-sm font-medium text-slate-900">Consultancy Fee - Standard Deliverables</p>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {standardDisciplineOrder.map((deliverable, index) => {
                        const selected = wizardDraft.deliverables.includes(deliverable);
                        return (
                          <button
                            key={deliverable}
                            type="button"
                            onClick={() => toggleDeliverable(deliverable)}
                            className={`rounded-2xl border px-4 py-4 text-left transition ${
                              selected ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white hover:border-amber-200 hover:bg-amber-50"
                            }`}
                          >
                            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">{index + 1}</p>
                            <p className="mt-2 font-semibold text-slate-950">{deliverable}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : null}

                {stageIndex === 3 ? (
                  <div className="space-y-4">
                    <p className="text-sm font-medium text-slate-900">
                      {wizardDraft.scopeGroupIds.length > 0 ? "Work Scope Deliverables" : "Work Scope Breakup"}
                    </p>
                    <div className="grid gap-3 sm:grid-cols-2">
                      {standardScopeGroupOptions.map((scope, index) => {
                        const selected = wizardDraft.scopeGroupIds.includes(scope.id);
                        return (
                          <button
                            key={scope.id}
                            type="button"
                            onClick={() => toggleScope(scope.id)}
                            className={`rounded-2xl border px-4 py-4 text-left transition ${
                              selected ? "border-amber-300 bg-amber-50" : "border-slate-200 bg-white hover:border-amber-200 hover:bg-amber-50"
                            }`}
                          >
                            <p className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-500">{index + 1}</p>
                            <p className="mt-2 font-semibold text-slate-950">{scope.name}</p>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : null}

                {stageIndex === 4 ? (
                  <div className={`grid gap-5 ${selectedStages.scope ? "md:grid-cols-2" : ""}`}>
                    {selectedStages.scope ? (
                      <div className="space-y-3">
                        <p className="text-sm font-medium text-slate-900">Import Plan Selection</p>
                        <Button type="button" variant={wizardDraft.selectedPlan === "both" ? "accent" : "outline"} className="w-full justify-start" onClick={() => setField("selectedPlan", "both")}>
                          Plan A + Plan B
                        </Button>
                        <Button type="button" variant={wizardDraft.selectedPlan === "optimal" ? "accent" : "outline"} className="w-full justify-start" onClick={() => setField("selectedPlan", "optimal")}>
                          Plan A
                        </Button>
                        <Button type="button" variant={wizardDraft.selectedPlan === "buffered" ? "accent" : "outline"} className="w-full justify-start" onClick={() => setField("selectedPlan", "buffered")}>
                          Plan B
                        </Button>
                      </div>
                    ) : null}

                    <div className="space-y-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <div>
                        <p className="text-sm font-medium text-slate-900">Timeline Days</p>
                        <p className="mt-1 text-sm text-slate-600">
                          {selectedStages.scope
                            ? "Set the total project timeline, then MOCPO will distribute it across the fixed six-row template."
                            : "Timeline-only mode is active because Workscope Break-up is not selected."}
                        </p>
                      </div>
                      <Input
                        type="number"
                        min={1}
                        value={wizardDraft.timelineDays || ""}
                        onChange={(event) => setField("timelineDays", Math.max(0, Number(event.target.value || 0)))}
                        placeholder="Enter total timeline days"
                      />
                    </div>
                  </div>
                ) : null}

                {stageIndex === 5 ? (
                  <div className="space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Client</p>
                        <p className="mt-2 text-sm font-semibold text-slate-950">{wizardDraft.clientName}</p>
                      </div>
                      <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Project</p>
                        <p className="mt-2 text-sm font-semibold text-slate-950">{wizardDraft.projectName}</p>
                      </div>
                      <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Selected Plan</p>
                        <p className="mt-2 text-sm font-semibold text-slate-950">
                          {selectedStages.scope ? (wizardDraft.selectedPlan ? getExecutionPlanLabel(wizardDraft.selectedPlan) : "Pending") : "Timeline Only"}
                        </p>
                      </div>
                      <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                        <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Version</p>
                        <p className="mt-2 text-sm font-semibold text-slate-950">{project.draftVersion.versionLabel}</p>
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 bg-white px-4 py-4">
                      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Proposal Summary</p>
                      <p className="mt-2 text-sm leading-7 text-slate-700">{withDraftSummary(wizardDraft).summary}</p>
                    </div>
                  </div>
                ) : null}
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <Button variant="ghost" onClick={handleBack} disabled={currentStagePosition === 0}>
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
                <div className="flex gap-3">
                  <Button
                    variant="ghost"
                    onClick={() => {
                      createNewProposal();
                      router.push("/");
                      setStatusMessage("Started a fresh questionnaire. This message will disappear after 30 seconds.");
                      toast.success("New proposal started");
                    }}
                  >
                    <RefreshCcw className="h-4 w-4" />
                    Reset Project
                  </Button>
                  {currentStagePosition < visibleStageIndexes.length - 1 ? (
                    <Button variant="accent" onClick={handleNext}>
                      {nextStepLabel ?? "Next"}
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  ) : (
                    <Button variant="accent" onClick={handleCreateProposal}>
                      Create Proposal
                    </Button>
                  )}
                </div>
              </div>
            </div>

            {statusMessage ? (
              <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-slate-700">
                {statusMessage}
              </div>
            ) : null}
          </div>
        </div>
      </GlassPanel>
    </div>
  );
}



