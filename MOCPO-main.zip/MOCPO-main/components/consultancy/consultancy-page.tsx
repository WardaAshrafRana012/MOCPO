"use client";

import { useMemo } from "react";
import type { ColumnDef } from "@tanstack/react-table";
import { Eye, Lock, PencilLine, Plus, Save, Trash2 } from "lucide-react";

import { ActionBar } from "@/components/shared/action-bar";
import { EmptyState } from "@/components/shared/empty-state";
import { SectionHeader } from "@/components/shared/section-header";
import { useProposalExportActions } from "@/components/shared/use-proposal-export-actions";
import { DataTable } from "@/components/data-table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { calculateConsultancyTotals } from "@/lib/calculations";
import { standardDisciplineOrder } from "@/lib/seeds";
import type { ConsultancyDiscipline, ConsultancyRow, DisciplineName } from "@/lib/types";
import { formatCurrency, formatNumber, getEditableNumberInputValue } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

function ConsultancyTable({
  discipline,
  sectionLocked,
  onEditToggle,
  onRowChange,
  onAddRow,
  onRemoveRow,
}: {
  discipline: ConsultancyDiscipline;
  sectionLocked: boolean;
  onEditToggle: (discipline: DisciplineName, isLocked: boolean) => void;
  onRowChange: (
    discipline: DisciplineName,
    rowId: string,
    field: "phaseLabel" | "deliverable" | "rate" | "area",
    value: number | string,
  ) => void;
  onAddRow: (discipline: DisciplineName) => void;
  onRemoveRow: (discipline: DisciplineName, rowId: string) => void;
}) {
  const isReadOnly = sectionLocked || discipline.isLocked;
  const columns = useMemo<ColumnDef<ConsultancyRow>[]>(
    () => [
      {
        accessorKey: "phaseLabel",
        header: "Phase / S.No",
        cell: ({ row }) =>
          isReadOnly ? (
            <span className="font-medium text-slate-900">{row.original.phaseLabel}</span>
          ) : (
            <Input
              value={row.original.phaseLabel}
              onChange={(event) => onRowChange(discipline.name, row.original.id, "phaseLabel", event.target.value)}
            />
          ),
      },
      {
        accessorKey: "deliverable",
        header: "Design Deliverable / Consultancies",
        cell: ({ row }) =>
          isReadOnly ? (
            <div className="whitespace-pre-line text-sm leading-6 text-slate-700">{row.original.deliverable}</div>
          ) : (
            <Textarea
              className="min-h-[96px]"
              value={row.original.deliverable}
              onChange={(event) => onRowChange(discipline.name, row.original.id, "deliverable", event.target.value)}
            />
          ),
      },
      {
        accessorKey: "rate",
        header: discipline.rateLabel,
        cell: ({ row }) =>
          isReadOnly ? (
            formatNumber(row.original.rate)
          ) : (
            <Input
              type="number"
              value={getEditableNumberInputValue(row.original.rate)}
              onChange={(event) => onRowChange(discipline.name, row.original.id, "rate", Number(event.target.value || 0))}
            />
          ),
      },
      {
        accessorKey: "area",
        header: discipline.inputLabel,
        cell: ({ row }) =>
          isReadOnly ? (
            formatNumber(row.original.area)
          ) : (
            <Input
              type="number"
              value={getEditableNumberInputValue(row.original.area)}
              onChange={(event) => onRowChange(discipline.name, row.original.id, "area", Number(event.target.value || 0))}
            />
          ),
      },
      {
        accessorKey: "totalCost",
        header: "Total Cost PKR",
        cell: ({ row }) => <span className="font-semibold text-slate-950">{formatCurrency(row.original.totalCost)}</span>,
      },
      {
        id: "actions",
        header: "",
        cell: ({ row }) =>
          isReadOnly ? null : (
            <Button variant="ghost" size="icon" onClick={() => onRemoveRow(discipline.name, row.original.id)}>
              <Trash2 className="h-4 w-4" />
            </Button>
          ),
      },
    ],
    [discipline.inputLabel, discipline.name, discipline.rateLabel, isReadOnly, onRemoveRow, onRowChange],
  );

  return (
    <Card className="border-white/80">
      <CardHeader className="gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="space-y-2">
          <CardTitle>{discipline.name}</CardTitle>
          <CardDescription>
            {discipline.rows.length} rows | {formatCurrency(discipline.estimatedAmount)}
          </CardDescription>
        </div>
        <div className="flex flex-wrap gap-3">
          {!isReadOnly ? (
            <Button variant="outline" onClick={() => onAddRow(discipline.name)}>
              <Plus className="h-4 w-4" />
              Add Field
            </Button>
          ) : null}
          <Button variant={isReadOnly ? "secondary" : "accent"} onClick={() => onEditToggle(discipline.name, !discipline.isLocked)}>
            {isReadOnly ? <PencilLine className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
            {isReadOnly ? "Edit Fields" : "Lock Values"}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <DataTable columns={columns} data={discipline.rows} />
        {discipline.notes && discipline.notes.length > 0 ? (
          <div className="rounded-2xl bg-slate-50 p-4">
            <p className="text-sm font-semibold text-slate-900">Included scope notes</p>
            <ul className="mt-3 space-y-2 pl-5 text-sm text-slate-600">
              {discipline.notes.map((note) => (
                <li key={note} className="list-disc">
                  {note}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

function TaxCard({
  subtotal,
  taxRate,
  taxAmount,
  grandTotal,
  isReadOnly,
  onTaxRateChange,
}: {
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  grandTotal: number;
  isReadOnly: boolean;
  onTaxRateChange: (value: number) => void;
}) {
  return (
    <Card className="border-white/80">
      <CardHeader>
        <CardTitle className="text-base">Consultancy Fee Tax</CardTitle>
        <CardDescription>Saved into the current active version.</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-4">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Services Subtotal</p>
            <p className="mt-3 text-lg font-semibold text-slate-950">{formatCurrency(subtotal)}</p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">SST Tax Rate %</p>
            {isReadOnly ? (
              <p className="mt-3 text-lg font-semibold text-slate-950">{formatNumber(taxRate)}</p>
            ) : (
              <Input className="mt-3" type="number" value={getEditableNumberInputValue(taxRate)} onChange={(event) => onTaxRateChange(Number(event.target.value || 0))} />
            )}
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">SST Tax Amount</p>
            <p className="mt-3 text-lg font-semibold text-slate-950">{formatCurrency(taxAmount)}</p>
          </div>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Services Total With Tax</p>
            <p className="mt-3 text-lg font-semibold text-slate-950">{formatCurrency(grandTotal)}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function ConsultancyPage({
  mode = "page",
  sectionLocked = false,
}: {
  mode?: "page" | "wizard" | "ai-workspace";
  sectionLocked?: boolean;
}) {
  const project = useProposalStore((state) => state.project);
  const selectConsultancyDiscipline = useProposalStore((state) => state.selectConsultancyDiscipline);
  const unloadConsultancyDiscipline = useProposalStore((state) => state.unloadConsultancyDiscipline);
  const updateConsultancyTaxRate = useProposalStore((state) => state.updateConsultancyTaxRate);
  const setConsultancyLocked = useProposalStore((state) => state.setConsultancyLocked);
  const updateConsultancyRow = useProposalStore((state) => state.updateConsultancyRow);
  const addConsultancyRow = useProposalStore((state) => state.addConsultancyRow);
  const removeConsultancyRow = useProposalStore((state) => state.removeConsultancyRow);
  const version = project.draftVersion;
  const isWizard = mode === "wizard" || mode === "ai-workspace";
  const { saveAndToast, downloadXlsx, previewProposal } = useProposalExportActions();

  const consultancyTotals = useMemo(
    () =>
      calculateConsultancyTotals(
        version.consultancySection,
        project.taxRate,
        project.discountRate,
        project.projectDurationMonths,
      ),
    [version.consultancySection, project.taxRate, project.discountRate, project.projectDurationMonths],
  );

  const toggleDiscipline = (discipline: DisciplineName) => {
    const selected = version.consultancySection.disciplines.find((item) => item.name === discipline);
    if (selected) {
      unloadConsultancyDiscipline(discipline);
      return;
    }
    selectConsultancyDiscipline(discipline);
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow={isWizard ? "Step 2" : "Tab 1"}
        title="Consultancy Fee"
        actions={
          !isWizard ? (
            <Button onClick={() => previewProposal("consultancy")}>
              <Eye className="h-4 w-4" />
              Open Preview
            </Button>
          ) : null
        }
      />

      <div className={isWizard ? "grid gap-6" : "grid gap-6 xl:grid-cols-[240px_minmax(0,1fr)]"}>
        <Card className="sticky top-28 h-fit border-white/80">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold uppercase tracking-[0.14em] text-slate-500">Standard Deliverables</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5">
            {standardDisciplineOrder.map((discipline) => {
              const selected = version.consultancySection.disciplines.find((item) => item.name === discipline);
              return (
                <button
                  key={discipline}
                  type="button"
                  onClick={() => {
                    if (!sectionLocked) toggleDiscipline(discipline);
                  }}
                  className={`w-full rounded-xl border px-3 py-2.5 text-left transition-all duration-150 ${
                    selected
                      ? "border-slate-800 bg-slate-800 text-white"
                      : "border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className={`truncate text-xs font-semibold ${selected ? "text-white" : "text-slate-900"}`}>{discipline}</span>
                    <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-bold ${selected ? "bg-white/20 text-white" : "bg-slate-100 text-slate-500"}`}>
                      {selected ? "Selected" : "Add"}
                    </span>
                  </div>
                  {selected ? <p className="mt-0.5 text-[10px] text-slate-300">{selected.rows.length} rows</p> : null}
                </button>
              );
            })}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {version.consultancySection.disciplines.length > 0 ? (
            version.consultancySection.disciplines.map((discipline) => (
              <ConsultancyTable
                key={discipline.name}
                discipline={discipline}
                sectionLocked={sectionLocked}
                onEditToggle={setConsultancyLocked}
                onRowChange={updateConsultancyRow}
                onAddRow={addConsultancyRow}
                onRemoveRow={removeConsultancyRow}
              />
            ))
          ) : (
            <EmptyState
              title="No consultancy disciplines selected"
              description="Click any discipline in the Standard Deliverables panel to add it."
            />
          )}

          <TaxCard
            subtotal={consultancyTotals.servicesSubtotal}
            taxRate={consultancyTotals.sstRate}
            taxAmount={consultancyTotals.sstAmount}
            grandTotal={consultancyTotals.servicesTotalWithTax}
            isReadOnly={sectionLocked}
            onTaxRateChange={updateConsultancyTaxRate}
          />
        </div>
      </div>

      {!isWizard ? (
        <ActionBar>
          <Button variant="secondary" onClick={saveAndToast}>
            <Save className="h-4 w-4" />
            Save
          </Button>
          <Button variant="outline" onClick={() => previewProposal("consultancy")}>
            <Eye className="h-4 w-4" />
            Preview Proposal
          </Button>
          <Button variant="outline" onClick={() => downloadXlsx()}>
            Save XLSX
          </Button>
        </ActionBar>
      ) : null}
    </div>
  );
}
