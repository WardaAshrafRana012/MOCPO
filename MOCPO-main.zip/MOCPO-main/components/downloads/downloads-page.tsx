"use client";

import type { ChangeEvent } from "react";
import { useRef } from "react";
import { DownloadCloud, FileCog, RefreshCw, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";

import { SectionHeader } from "@/components/shared/section-header";
import { useProposalExportActions } from "@/components/shared/use-proposal-export-actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { ProjectRecord } from "@/lib/types";
import { formatDateTime } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

export function DownloadsPage() {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const project = useProposalStore((state) => state.project);
  const importProjectData = useProposalStore((state) => state.importProjectData);
  const { downloadJson, downloadPdf, downloadXlsx } = useProposalExportActions();

  const onImportClick = () => fileInputRef.current?.click();

  const onImportFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const text = await file.text();

    try {
      const parsed = JSON.parse(text) as ProjectRecord;
      importProjectData(parsed);
      toast.success("Proposal JSON imported");
    } catch {
      toast.error("Could not import the proposal JSON");
    }
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="Exports"
        title="Downloads"
        description="Use this export center to track generated proposal files, regenerate outputs, and manage portable backups."
        actions={
          <>
            <input ref={fileInputRef} type="file" accept="application/json" className="hidden" onChange={onImportFile} />
            <Button variant="secondary" onClick={onImportClick}>
              <UploadCloud className="h-4 w-4" />
              Import JSON
            </Button>
            <Button onClick={() => downloadJson()}>
              <DownloadCloud className="h-4 w-4" />
              Export JSON
            </Button>
          </>
        }
      />

      <div className="grid gap-6 xl:grid-cols-[1.35fr_0.8fr]">
        <Card className="border-[#E8E8E8]">
          <CardHeader>
            <CardTitle>Export center</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {project.downloads.length > 0 ? (
              <div className="overflow-hidden rounded-[20px] border border-[#E8E8E8]">
                <div className="hidden grid-cols-[minmax(0,2fr)_100px_100px_180px_110px_minmax(0,1.2fr)] gap-3 border-b border-[#E8E8E8] bg-[#F7F6F3] px-4 py-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-[#5F6B78] xl:grid">
                  <div>File Name</div>
                  <div>Type</div>
                  <div>Version</div>
                  <div>Date</div>
                  <div>Status</div>
                  <div>Actions</div>
                </div>
                {project.downloads.map((download) => (
                  <div key={download.id} className="border-b border-[#E8E8E8] bg-white px-4 py-4 last:border-b-0">
                    <div className="grid gap-3 xl:grid-cols-[minmax(0,2fr)_100px_100px_180px_110px_minmax(0,1.2fr)] xl:items-center">
                      <div className="min-w-0">
                        <p className="truncate font-semibold text-[#16202A]">{download.filename}</p>
                        <p className="mt-1 text-sm text-[#5F6B78] xl:hidden">
                          {download.kind.toUpperCase()} | {download.versionLabel} | {formatDateTime(download.createdAt)}
                        </p>
                      </div>
                      <div className="hidden text-sm font-medium text-[#16202A] xl:block">{download.kind.toUpperCase()}</div>
                      <div className="hidden text-sm font-medium text-[#16202A] xl:block">{download.versionLabel}</div>
                      <div className="hidden text-sm text-[#5F6B78] xl:block">{formatDateTime(download.createdAt)}</div>
                      <div>
                        <span className="rounded-full bg-[#edf7f0] px-3 py-1 text-xs font-semibold text-[#2F855A]">Ready</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button variant="outline" size="sm" onClick={() => (download.kind === "pdf" ? downloadPdf() : downloadXlsx())}>
                          <DownloadCloud className="h-4 w-4" />
                          Download
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => (download.kind === "pdf" ? downloadPdf() : downloadXlsx())}>
                          <RefreshCw className="h-4 w-4" />
                          Regenerate
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : null}

            {project.downloads.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-[#E8E8E8] p-5 text-sm text-[#5F6B78]">
                Download activity will populate here once you preview or export files.
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card className="border-[#E8E8E8]">
          <CardHeader>
            <CardTitle>Export notes</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-[#5F6B78]">
            <div className="rounded-2xl border border-[#E8E8E8] bg-[#F7F6F3] p-4">
              <div className="flex items-center gap-2 font-semibold text-[#16202A]">
                <FileCog className="h-4 w-4" />
                Current export behavior
              </div>
              <div className="mt-3 space-y-3">
                <p>PDF exports use the structured proposal payload and register the resulting file in this page.</p>
                <p>XLSX exports preserve section tables, headings, and workbook metadata for the saved proposal version.</p>
                <p>JSON backups remain the portable source of truth for moving proposals between browsers or machines.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
