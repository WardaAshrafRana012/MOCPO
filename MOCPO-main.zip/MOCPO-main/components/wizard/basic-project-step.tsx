﻿"use client";

import { useMemo } from "react";
import type { ReactNode } from "react";
import { Building2, MapPin, Ruler, UserRound } from "lucide-react";

import { SectionHeader } from "@/components/shared/section-header";
import { getProposalMemorySuggestions, useProposalMemory } from "@/components/shared/use-proposal-memory";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useProposalStore } from "@/store/proposal-store";
import { getEditableNumberInputValue } from "@/lib/utils";

function FieldCard({
  id,
  label,
  value,
  type = "text",
  placeholder,
  icon,
  onChange,
  listId,
  suggestions = [],
}: {
  id: string;
  label: string;
  value: string | number;
  type?: "text" | "number";
  placeholder?: string;
  icon: ReactNode;
  onChange: (value: string) => void;
  listId?: string;
  suggestions?: string[];
}) {
  return (
    <Card className="border-slate-200 shadow-sm">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <span className="rounded-xl bg-slate-100 p-2 text-slate-700">{icon}</span>
          {label}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Label htmlFor={id} className="sr-only">
          {label}
        </Label>
        <Input
          id={id}
          type={type}
          list={listId}
          autoComplete="off"
          value={type === "number" ? getEditableNumberInputValue(Number(value)) : String(value)}
          placeholder={placeholder}
          onChange={(event) => onChange(event.target.value)}
          className="h-12 text-base"
        />
        {listId && suggestions.length > 0 ? (
          <datalist id={listId}>
            {suggestions.map((suggestion) => (
              <option key={suggestion} value={suggestion} />
            ))}
          </datalist>
        ) : null}
      </CardContent>
    </Card>
  );
}

export function BasicProjectStep() {
  const project = useProposalStore((state) => state.project);
  const proposals = useProposalStore((state) => state.proposals);
  const updateProjectFields = useProposalStore((state) => state.updateProjectFields);
  const proposalMemory = useProposalMemory(proposals);
  const clientSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.clients, project.clientName),
    [proposalMemory.clients, project.clientName],
  );
  const projectSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.projects, project.projectName),
    [proposalMemory.projects, project.projectName],
  );
  const locationSuggestions = useMemo(
    () => getProposalMemorySuggestions(proposalMemory.locations, project.location),
    [proposalMemory.locations, project.location],
  );
  const validation = {
    clientName: project.clientName.trim().length > 0,
    projectName: project.projectName.trim().length > 0,
    areaSqFt: Number(project.areaSqFt) > 0,
    location: project.location.trim().length > 0,
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow="Step 1"
        title="Basic project information"
        description="Start the proposal as one continuous flow. Add the core project details first, then continue into fees, scope, and execution."
      />

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <FieldCard
            id="wizard-client-name"
            label="Client Name *"
            value={project.clientName}
            placeholder="Enter client name"
            icon={<UserRound className="h-4 w-4" />}
            listId="wizard-client-memory"
            suggestions={clientSuggestions}
            onChange={(value) => updateProjectFields({ clientName: value })}
          />
          {!validation.clientName ? <p className="px-1 text-sm text-[#C53030]">Client name is required.</p> : null}
        </div>
        <div className="space-y-2">
          <FieldCard
            id="wizard-project-name"
            label="Project Name *"
            value={project.projectName}
            placeholder="Enter project name"
            icon={<Building2 className="h-4 w-4" />}
            listId="wizard-project-memory"
            suggestions={projectSuggestions}
            onChange={(value) => updateProjectFields({ projectName: value })}
          />
          {!validation.projectName ? <p className="px-1 text-sm text-[#C53030]">Project name is required.</p> : null}
        </div>
        <div className="space-y-2">
          <FieldCard
            id="wizard-area"
            label="Area (Sq. Ft.) *"
            type="number"
            value={project.areaSqFt}
            placeholder="Enter total area"
            icon={<Ruler className="h-4 w-4" />}
            onChange={(value) => updateProjectFields({ areaSqFt: Number(value || 0) })}
          />
          {!validation.areaSqFt ? <p className="px-1 text-sm text-[#C53030]">Area must be greater than zero.</p> : null}
        </div>
        <div className="space-y-2">
          <FieldCard
            id="wizard-location"
            label="Project Location *"
            value={project.location}
            placeholder="Enter project location"
            icon={<MapPin className="h-4 w-4" />}
            listId="wizard-location-memory"
            suggestions={locationSuggestions}
            onChange={(value) => updateProjectFields({ location: value })}
          />
          {!validation.location ? <p className="px-1 text-sm text-[#C53030]">Project location is required.</p> : null}
        </div>
      </div>

      <Card className="border-slate-200 bg-slate-950 text-white shadow-sm">
        <CardContent className="grid gap-4 p-6 md:grid-cols-4">
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-slate-400">Client</p>
            <p className="mt-2 text-lg font-semibold">{project.clientName || "Pending"}</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-slate-400">Project</p>
            <p className="mt-2 text-lg font-semibold">{project.projectName || "Pending"}</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-slate-400">Area</p>
            <p className="mt-2 text-lg font-semibold">{project.areaSqFt > 0 ? `${project.areaSqFt} SQ.FT` : "Pending"}</p>
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.16em] text-slate-400">Location</p>
            <p className="mt-2 text-lg font-semibold">{project.location || "Pending"}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
