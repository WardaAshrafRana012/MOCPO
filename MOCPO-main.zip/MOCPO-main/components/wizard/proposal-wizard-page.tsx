"use client";

import { AIBuilderPage } from "@/components/ai/ai-builder-page";

export function ProposalWizardPage() {
  return <AIBuilderPage />;
}
