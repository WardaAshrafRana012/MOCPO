﻿"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { EyeOff, Eye, FileUp, Lock, LockOpen, PencilLine, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { ActionBar } from "@/components/shared/action-bar";
import { SectionHeader } from "@/components/shared/section-header";
import { useProposalExportActions } from "@/components/shared/use-proposal-export-actions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  calculateFinalEstimate,
  calculatePaymentScheduleSummary,
  calculateTimelineTotals,
  getExecutionBudgetTotals,
  getExecutionPlanLabel,
  getSelectedExecutionCost,
  getTimelinePlanLabel,
} from "@/lib/calculations";
import {
  getAvailableProposalSections,
  getOrderedProposalSections,
  proposalSectionMeta,
} from "@/lib/proposal-sections";
import { getProposalSummaryCards } from "@/lib/proposal-summary-cards";
import type { ConsultancyDiscipline, ProposalSectionKey, ProposalVersion } from "@/lib/types";
import { getScopeRowsForTotals } from "@/lib/scope-sheet";
import { formatCurrency, formatDateTime, formatNumber } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

function PreviewMetric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white px-4 py-4 shadow-sm">
      <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">{label}</p>
      <p className="mt-2 text-lg font-semibold text-slate-950">{value}</p>
    </div>
  );
}

function getConsultancyColumnLabels(discipline: ConsultancyDiscipline) {
  return {
    rateLabel: discipline.rateLabel.replace("Rate / ", "").replace("Rate ", ""),
    quantityLabel: discipline.inputLabel,
  };
}

function SectionControls({
  locked,
  hidden,
  showEditWhenLocked = false,
  onEdit,
  onToggleLock,
  onToggleHidden,
  onDelete,
}: {
  locked: boolean;
  hidden: boolean;
  showEditWhenLocked?: boolean;
  onEdit: () => void;
  onToggleLock: () => void;
  onToggleHidden: () => void;
  onDelete: () => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {!locked || showEditWhenLocked ? (
        <Button variant="outline" size="sm" onClick={onEdit}>
          <PencilLine className="h-4 w-4" />
          Edit
        </Button>
      ) : null}
      <Button variant="outline" size="sm" onClick={onToggleHidden}>
        {hidden ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
        {hidden ? "Show" : "Hide"}
      </Button>
      <Button variant="outline" size="sm" onClick={onToggleLock}>
        {locked ? <LockOpen className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
        {locked ? "Unlock" : "Lock"}
      </Button>
      {!locked ? (
        <Button variant="outline" size="sm" onClick={onDelete}>
          <Trash2 className="h-4 w-4" />
          Delete
        </Button>
      ) : null}
    </div>
  );
}

function PreviewSectionShell({
  label,
  section,
  children,
  locked,
  hidden,
  readOnly = false,
  showEditWhenLocked = false,
  onEdit,
  onToggleLock,
  onToggleHidden,
  onDelete,
}: {
  label: string;
  section: ProposalSectionKey;
  children: React.ReactNode;
  locked: boolean;
  hidden: boolean;
  readOnly?: boolean;
  showEditWhenLocked?: boolean;
  onEdit: () => void;
  onToggleLock: () => void;
  onToggleHidden: () => void;
  onDelete: () => void;
}) {
  return (
    <div className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm">
      <div className="flex flex-col gap-3 border-b border-slate-200 px-6 py-5 xl:flex-row xl:items-center xl:justify-between">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">{proposalSectionMeta[section].module}</p>
          <h3 className="mt-2 text-xl font-semibold text-slate-950">{label}</h3>
          {!readOnly ? (
            <div className="mt-2 flex flex-wrap gap-2 text-xs font-medium text-slate-500">
              {locked ? <span className="rounded-full bg-slate-100 px-2.5 py-1">Locked</span> : null}
              {hidden ? <span className="rounded-full bg-slate-100 px-2.5 py-1">Hidden</span> : null}
            </div>
          ) : null}
        </div>
        {!readOnly ? (
          <SectionControls
            locked={locked}
            hidden={hidden}
            showEditWhenLocked={showEditWhenLocked}
            onEdit={onEdit}
            onToggleLock={onToggleLock}
            onToggleHidden={onToggleHidden}
            onDelete={onDelete}
          />
        ) : null}
      </div>
      <div className="p-6">{children}</div>
    </div>
  );
}

export function ProposalPreviewPage({
  mode = "page",
  onEditSection,
  versionOverride,
}: {
  mode?: "page" | "workspace";
  onEditSection?: (section: ProposalSectionKey) => void;
  versionOverride?: ProposalVersion;
}) {
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [sectionToDelete, setSectionToDelete] = useState<ProposalSectionKey | null>(null);

  const isWorkspaceMode = mode === "workspace";
  const isReadOnlyPreview = !isWorkspaceMode;
  const searchParams = useSearchParams();
  const versionId = searchParams?.get("versionId") ?? null;
  const project = useProposalStore((state) => state.project);
  const setProposalSectionLocked = useProposalStore((state) => state.setProposalSectionLocked);
  const setProposalSectionVisibility = useProposalStore((state) => state.setProposalSectionVisibility);
  const deleteProposalSection = useProposalStore((state) => state.deleteProposalSection);
  const versionFromQuery = useMemo(() => {
    if (!versionId) {
      return null;
    }

    return project.savedVersions.find((entry) => entry.id === versionId)
      ?? (project.draftVersion.id === versionId ? project.draftVersion : null);
  }, [project.draftVersion, project.savedVersions, versionId]);
  const version = versionOverride ?? versionFromQuery ?? project.draftVersion;
  const sectionStates = version.workspaceSections;
  const availableSections = useMemo(
    () => new Set(getAvailableProposalSections(project, version)),
    [project, version],
  );
  const orderedSections = getOrderedProposalSections(sectionStates);
  const visibleSections = orderedSections.filter(
    (section) =>
      availableSections.has(section) &&
      version.previewSections[section] &&
      !sectionStates[section].hidden &&
      !sectionStates[section].deleted,
  );

  const summaryCards = useMemo(() => getProposalSummaryCards(project, version), [project, version]);
  const timelineTotals = calculateTimelineTotals(version.executionSection.timelineRows);
  const finalEstimate = calculateFinalEstimate(version.executionSection);
  const { budgetA, budgetB, budgetATotal, budgetBTotal } = getExecutionBudgetTotals(version.executionSection);
  const selectedPlanLabel = getExecutionPlanLabel(version.executionSection.selectedPlan);
  const timelineTitle = getTimelinePlanLabel(version.executionSection.selectedPlan);
  const workScopeRows = getScopeRowsForTotals(version.scopeSection.rows);
  const { downloadPdf, downloadXlsx } = useProposalExportActions();

  const goToSection = (section: ProposalSectionKey) => {
    if (isReadOnlyPreview) {
      return;
    }

    if (onEditSection) {
      onEditSection(section);
    }
  };

  const renderSection = (section: ProposalSectionKey) => {
    const state = sectionStates[section];
    const common = {
      section,
      locked: state.locked,
      hidden: state.hidden,
      readOnly: isReadOnlyPreview,
      showEditWhenLocked: isWorkspaceMode,
      onEdit: () => {
        if (isReadOnlyPreview) {
          return;
        }

        if (isWorkspaceMode && state.locked) {
          setProposalSectionLocked(section, false);
        }
        goToSection(section);
      },
      onToggleLock: () => setProposalSectionLocked(section, !state.locked),
      onToggleHidden: () => setProposalSectionVisibility(section, state.hidden),
      onDelete: () => {
        setSectionToDelete(section);
        setDeleteDialogOpen(true);
      },
    };

    switch (section) {
      case "consultancyFee":
        return (
          <PreviewSectionShell key={section} label="Consultancy Fee" {...common}>
            <div className="space-y-4">
              {version.consultancySection.disciplines.map((discipline) => {
                const { rateLabel, quantityLabel } = getConsultancyColumnLabels(discipline);
                return (
                  <div key={discipline.name} className="overflow-x-auto rounded-2xl border border-slate-200">
                    <div className="border-b border-slate-200 bg-slate-50 px-4 py-3">
                      <p className="font-semibold text-slate-950">{discipline.name}</p>
                    </div>
                    <table className="min-w-[760px] w-full border-collapse text-sm">
                      <thead>
                        <tr className="bg-white text-slate-700">
                          <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Deliverable</th>
                          <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">{rateLabel}</th>
                          <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">{quantityLabel}</th>
                          <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-[0.14em]">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {discipline.rows.map((row) => (
                          <tr key={row.id} className="border-t border-slate-100">
                            <td className="px-4 py-3 text-slate-900">{row.deliverable}</td>
                            <td className="px-4 py-3 text-slate-600">{formatNumber(row.rate)}</td>
                            <td className="px-4 py-3 text-slate-600">{formatNumber(row.area)}</td>
                            <td className="px-4 py-3 text-right font-semibold text-slate-950">{formatCurrency(row.totalCost)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          </PreviewSectionShell>
        );
      case "workScope":
        return (
          <PreviewSectionShell key={section} label="Work Scope" {...common}>
            <div className="grid gap-4 md:grid-cols-2">
              {workScopeRows.map((row) => (
                <div key={row.id} className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                  <p className="font-semibold text-slate-950">{row.groupName}</p>
                  <p className="mt-2 whitespace-pre-wrap text-sm text-slate-600">{row.leftScope || row.rightScope || "-"}</p>
                </div>
              ))}
            </div>
          </PreviewSectionShell>
        );
      case "negativeList":
        return (
          <PreviewSectionShell key={section} label={version.scopeSection.exclusionsTitle || "Negative List"} {...common}>
            <p className="whitespace-pre-wrap text-sm leading-7 text-slate-600">{version.scopeSection.note}</p>
          </PreviewSectionShell>
        );
      case "optimalList":
        return (
          <PreviewSectionShell key={section} label="Optimal List" {...common}>
            <p className="whitespace-pre-wrap text-sm leading-7 text-slate-600">{version.scopeSection.optimalExclusions}</p>
          </PreviewSectionShell>
        );
      case "bufferedOptimalList":
        return (
          <PreviewSectionShell key={section} label="Buffered Optimal List" {...common}>
            <p className="whitespace-pre-wrap text-sm leading-7 text-slate-600">{version.scopeSection.bufferedExclusions}</p>
          </PreviewSectionShell>
        );
      case "executionEstimate":
        return (
          <PreviewSectionShell key={section} label="Execution Estimate" {...common}>
            <div className="grid gap-4 md:grid-cols-3">
              <PreviewMetric label="Selected Plan" value={selectedPlanLabel} />
              <PreviewMetric label="Execution Cost" value={formatCurrency(getSelectedExecutionCost(version.executionSection))} />
              <PreviewMetric label="Final Estimate" value={formatCurrency(finalEstimate)} />
            </div>
          </PreviewSectionShell>
        );
      case "timeline":
        return (
          <PreviewSectionShell key={section} label={timelineTitle ?? "Timeline"} {...common}>
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <PreviewMetric label="Total Days" value={`${timelineTotals.totalDays} Days`} />
                <PreviewMetric label="Approx. Months" value={`${formatNumber(timelineTotals.totalMonths)} Months`} />
                <PreviewMetric label="Updated" value={formatDateTime(project.lastEditedAt)} />
              </div>
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="min-w-[860px] w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700">
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Activity</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Days</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Start</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">End</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Remarks</th>
                    </tr>
                  </thead>
                  <tbody>
                    {version.executionSection.timelineRows.map((row) => (
                      <tr key={row.id} className="border-t border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-950">{row.activity}</td>
                        <td className="px-4 py-3 text-center text-slate-600">{row.days}</td>
                        <td className="px-4 py-3 text-center text-slate-600">{row.startDate || "-"}</td>
                        <td className="px-4 py-3 text-center text-slate-600">{row.endDate || "-"}</td>
                        <td className="px-4 py-3 text-slate-600">{row.remarks || "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </PreviewSectionShell>
        );
      case "budgetComparison":
        return (
          <PreviewSectionShell key={section} label="Budget Comparison" {...common}>
            {budgetA && budgetB ? (
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="min-w-[1040px] w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700">
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">S.No</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Description</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget A Qty</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget A Rate</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget A Amount</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget B Qty</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget B Rate</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Budget B Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Array.from({ length: Math.max(budgetA.rows.length, budgetB.rows.length) }).map((_, index) => {
                      const rowA = budgetA.rows[index];
                      const rowB = budgetB.rows[index];
                      return (
                        <tr key={`${rowA?.id ?? "a"}-${rowB?.id ?? "b"}-${index}`} className="border-t border-slate-100">
                          <td className="px-4 py-3 text-slate-900">{index + 1}</td>
                          <td className="px-4 py-3 text-slate-900">{rowA?.description || rowB?.description || "-"}</td>
                          <td className="px-4 py-3 text-center text-slate-600">{rowA ? formatNumber(rowA.quantity) : "-"}</td>
                          <td className="px-4 py-3 text-center text-slate-600">{rowA ? formatCurrency(rowA.rate) : "-"}</td>
                          <td className="px-4 py-3 text-center font-medium text-slate-950">{rowA ? formatCurrency(rowA.totalAmount) : "-"}</td>
                          <td className="px-4 py-3 text-center text-slate-600">{rowB ? formatNumber(rowB.quantity) : "-"}</td>
                          <td className="px-4 py-3 text-center text-slate-600">{rowB ? formatCurrency(rowB.rate) : "-"}</td>
                          <td className="px-4 py-3 text-center font-medium text-slate-950">{rowB ? formatCurrency(rowB.totalAmount) : "-"}</td>
                        </tr>
                      );
                    })}
                    <tr className="border-t border-slate-200 bg-slate-50 font-semibold text-slate-950">
                      <td className="px-4 py-3" colSpan={4}>Budget A Total</td>
                      <td className="px-4 py-3 text-center">{formatCurrency(budgetATotal)}</td>
                      <td className="px-4 py-3" colSpan={2}>Budget B Total</td>
                      <td className="px-4 py-3 text-center">{formatCurrency(budgetBTotal)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-slate-500">Budget comparison becomes available once both budget plans exist.</p>
            )}
          </PreviewSectionShell>
        );
      case "paymentSchedule": {
        const paymentSummary = calculatePaymentScheduleSummary(version.paymentSchedule);
        return (
          <PreviewSectionShell key={section} label="Payment Schedule" {...common}>
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-4">
                <PreviewMetric label="Proposal Grand Total" value={formatCurrency(version.paymentSchedule.grandTotal)} />
                <PreviewMetric label="Allocated %" value={`${paymentSummary.allocatedPercentage}%`} />
                <PreviewMetric label="Remaining %" value={`${paymentSummary.remainingPercentage}%`} />
                <PreviewMetric label="Total Amount" value={formatCurrency(paymentSummary.totalAmount)} />
              </div>
              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="min-w-[980px] w-full border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700">
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Installment</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Percentage</th>
                      <th className="px-4 py-3 text-right text-[11px] font-semibold uppercase tracking-[0.14em]">Amount</th>
                      <th className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-[0.14em]">Due Date</th>
                      <th className="px-4 py-3 text-left text-[11px] font-semibold uppercase tracking-[0.14em]">Description / Milestone</th>
                    </tr>
                  </thead>
                  <tbody>
                    {version.paymentSchedule.rows.map((row) => (
                      <tr key={row.id} className="border-t border-slate-100">
                        <td className="px-4 py-3 font-medium text-slate-950">{row.name}</td>
                        <td className="px-4 py-3 text-center text-slate-600">{row.percentage}%</td>
                        <td className="px-4 py-3 text-right font-semibold text-slate-950">{formatCurrency(row.amount)}</td>
                        <td className="px-4 py-3 text-center text-slate-600">{row.dueDate || "-"}</td>
                        <td className="px-4 py-3 text-slate-600">{row.description || "-"}</td>
                      </tr>
                    ))}
                    <tr className="border-t border-slate-200 bg-slate-50 font-semibold text-slate-950">
                      <td className="px-4 py-3">Total</td>
                      <td className="px-4 py-3 text-center">{paymentSummary.allocatedPercentage}%</td>
                      <td className="px-4 py-3 text-right">{formatCurrency(paymentSummary.totalAmount)}</td>
                      <td className="px-4 py-3 text-center">-</td>
                      <td className="px-4 py-3">{version.paymentSchedule.notes || "Payment schedule summary"}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              {version.paymentSchedule.notes ? (
                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                  <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500">Payment Notes</div>
                  <p className="mt-2 whitespace-pre-wrap text-sm leading-7 text-slate-600">{version.paymentSchedule.notes}</p>
                </div>
              ) : null}
            </div>
          </PreviewSectionShell>
        );
      }
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow={isWorkspaceMode ? "Edit Proposal" : "Client Preview"}
        title={isWorkspaceMode ? "Edit Proposal" : "Preview Proposal"}
        description={
          isWorkspaceMode
            ? undefined
            : "View the client-ready proposal exactly as it will export."
        }
      />

      <Card className="overflow-hidden border-slate-200 bg-[#f5f2ea] shadow-sm">
        <div className="border-b border-slate-200 bg-[linear-gradient(135deg,#14213d_0%,#1d3557_60%,#274c77_100%)] px-8 py-10 text-white">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <div className="max-w-3xl">
              <p className="text-sm uppercase tracking-[0.24em] text-amber-300">{project.brandProfile.companyName}</p>
              <h1 className="mt-4 text-4xl font-semibold tracking-tight">{project.projectName || "Untitled proposal"}</h1>
              <p className="mt-2 text-lg text-slate-200">
                Prepared for {project.clientName || "Client"} at {project.location || "Location pending"}
              </p>
            </div>
            <div className="grid gap-3 rounded-3xl border border-white/10 bg-white/10 p-5 backdrop-blur sm:grid-cols-2">
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Version</p>
                <p className="mt-2 text-xl font-semibold">{version.versionLabel}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Updated</p>
                <p className="mt-2 text-sm font-medium text-white">{formatDateTime(project.lastEditedAt)}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Area</p>
                <p className="mt-2 text-lg font-semibold">{formatNumber(project.areaSqFt)} SQ.FT</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-[0.16em] text-slate-300">Selected Plan</p>
                <p className="mt-2 text-lg font-semibold">{selectedPlanLabel}</p>
              </div>
            </div>
          </div>
        </div>

        <CardContent className="mx-auto w-full max-w-6xl space-y-8 px-6 py-8 md:px-8">
          {summaryCards.length > 0 ? (
            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {summaryCards.map((card) => (
                <PreviewMetric key={card.key} label={card.label} value={card.value} />
              ))}
            </section>
          ) : null}

          {summaryCards.length > 0 && visibleSections.length > 0 ? (
            <Separator />
          ) : null}

          {visibleSections.map((section) => renderSection(section))}
        </CardContent>
      </Card>

      <ActionBar>
        {isWorkspaceMode ? null : (
          <>
            <Button variant="outline" onClick={() => downloadPdf(version)}>
              <FileUp className="h-4 w-4" />
              Download PDF
            </Button>
            <Button variant="outline" onClick={() => downloadXlsx(version)}>
              <FileUp className="h-4 w-4" />
              Download XLS
            </Button>
          </>
        )}
      </ActionBar>

      <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <DialogContent className="p-6">
          <DialogHeader className="text-left">
            <DialogTitle>Delete Item</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this item?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setDeleteDialogOpen(false);
                setSectionToDelete(null);
              }}
            >
              Cancel
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                if (sectionToDelete) {
                  deleteProposalSection(sectionToDelete);
                  toast.success("Item deleted successfully");
                  setDeleteDialogOpen(false);
                  setSectionToDelete(null);
                }
              }}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}




