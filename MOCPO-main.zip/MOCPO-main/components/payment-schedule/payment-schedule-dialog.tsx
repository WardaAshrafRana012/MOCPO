"use client";

import { useEffect, useMemo, useState } from "react";
import { CalendarDays, CircleAlert, Plus, Trash2, WalletCards } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Textarea } from "@/components/ui/textarea";
import { calculatePaymentScheduleSummary, calculateProposalGrandTotal } from "@/lib/calculations";
import { createDefaultPaymentInstallments, syncPaymentScheduleAmounts } from "@/lib/payment-schedule";
import type { PaymentSchedule, ProjectRecord, ProposalVersion } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";

function buildEditableSchedule(project: ProjectRecord, version: ProposalVersion): PaymentSchedule {
  const grandTotal = calculateProposalGrandTotal(project, version);
  const base = version.paymentSchedule?.rows?.length
    ? version.paymentSchedule
    : {
        ...version.paymentSchedule,
        enabled: Boolean(version.paymentSchedule?.enabled),
        rows: createDefaultPaymentInstallments(),
        notes: version.paymentSchedule?.notes ?? "",
      };

  return syncPaymentScheduleAmounts(
    {
      enabled: base.enabled ?? false,
      grandTotal,
      rows: base.rows,
      notes: base.notes ?? "",
      updatedAt: base.updatedAt ?? null,
    },
    grandTotal,
  );
}

export function PaymentScheduleDialog({
  open,
  onOpenChange,
  project,
  version,
  onSave,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  project: ProjectRecord;
  version: ProposalVersion;
  onSave: (paymentSchedule: PaymentSchedule) => void;
}) {
  const [schedule, setSchedule] = useState<PaymentSchedule>(() => buildEditableSchedule(project, version));

  useEffect(() => {
    if (!open) return;
    setSchedule(buildEditableSchedule(project, version));
  }, [open, project, version]);

  const summary = useMemo(() => calculatePaymentScheduleSummary(schedule), [schedule]);
  const isUnderAllocated = summary.allocatedPercentage < 100;
  const isOverAllocated = summary.allocatedPercentage > 100;
  const canSave = Math.abs(summary.allocatedPercentage - 100) < 0.01;

  const updateSchedule = (updater: (current: PaymentSchedule) => PaymentSchedule) => {
    setSchedule((current) => {
      const next = updater(current);
      return syncPaymentScheduleAmounts(next, next.grandTotal);
    });
  };

  const addInstallment = () => {
    updateSchedule((current) => ({
      ...current,
      enabled: true,
      rows: [
        ...current.rows,
        {
          id: "payment-installment-" + Math.random().toString(36).slice(2, 10),
          name: "Installment " + (current.rows.length + 1),
          percentage: 0,
          amount: 0,
          dueDate: "",
          description: "",
        },
      ],
    }));
  };

  const statusTone = isOverAllocated
    ? "border-rose-200 bg-rose-50 text-rose-700"
    : isUnderAllocated
      ? "border-amber-200 bg-amber-50 text-amber-700"
      : "border-emerald-200 bg-emerald-50 text-emerald-700";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="h-[92vh] max-w-6xl overflow-hidden rounded-[28px] border border-slate-200 p-0">
        <div className="flex h-full min-h-0 flex-col bg-white">
          <DialogHeader className="border-b border-slate-200 bg-[linear-gradient(135deg,#0f172a_0%,#16324f_55%,#214e7a_100%)] px-8 py-7 text-left">
            <DialogTitle className="flex items-center gap-3 text-2xl font-semibold text-white">
              <WalletCards className="h-6 w-6" />
              Payment Schedule
            </DialogTitle>
            <DialogDescription className="mt-2 max-w-3xl text-slate-200">
              Split the current proposal grand total into installments. This saves only into the active version and will follow it into future versions.
            </DialogDescription>
          </DialogHeader>

          <div className="grid min-h-0 flex-1 lg:grid-cols-[1.4fr_0.6fr]">
            <ScrollArea className="min-h-0">
              <div className="space-y-6 px-8 py-6 pb-10">
                <div className="grid gap-4 lg:grid-cols-4">
                  <div className="rounded-3xl border border-slate-200 bg-slate-50 px-5 py-4">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Client</div>
                    <div className="mt-2 text-sm font-semibold text-slate-950">{project.clientName || "Pending"}</div>
                  </div>
                  <div className="rounded-3xl border border-slate-200 bg-slate-50 px-5 py-4">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Project</div>
                    <div className="mt-2 text-sm font-semibold text-slate-950">{project.projectName || "Untitled"}</div>
                  </div>
                  <div className="rounded-3xl border border-slate-200 bg-slate-50 px-5 py-4">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Active Version</div>
                    <div className="mt-2 text-sm font-semibold text-slate-950">{version.versionLabel}</div>
                  </div>
                  <div className="rounded-3xl border border-slate-200 bg-slate-950 px-5 py-4 text-white">
                    <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-300">Proposal Grand Total</div>
                    <div className="mt-2 text-lg font-semibold">{formatCurrency(schedule.grandTotal)}</div>
                  </div>
                </div>

                <div className={"rounded-3xl border px-5 py-4 " + statusTone}>
                  <div className="flex items-start gap-3">
                    <CircleAlert className="mt-0.5 h-5 w-5" />
                    <div className="space-y-1 text-sm">
                      <div className="font-semibold">
                        {isOverAllocated
                          ? "Allocated percentage is above 100%."
                          : isUnderAllocated
                            ? "Allocated percentage must reach 100% before saving."
                            : "Payment schedule is balanced and ready to save."}
                      </div>
                      <div>
                        Allocated: {summary.allocatedPercentage}% | Remaining: {summary.remainingPercentage}% | Installment Amount Total: {formatCurrency(summary.totalAmount)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-950">Installments</div>
                      <div className="mt-1 text-sm text-slate-500">Create any number of milestones. Amounts update automatically from the percentage and current proposal total.</div>
                    </div>
                    <Button type="button" variant="outline" onClick={addInstallment}>
                      <Plus className="h-4 w-4" />
                      Add Installment
                    </Button>
                  </div>

                  <div className="mt-5 space-y-4">
                    {schedule.rows.map((row, index) => (
                      <div key={row.id} className="rounded-3xl border border-slate-200 bg-slate-50/70 p-4">
                        <div className="grid gap-4 xl:grid-cols-[1.1fr_0.55fr_0.7fr_auto]">
                          <div>
                            <label className="text-sm font-medium text-slate-700">Installment Name</label>
                            <Input value={row.name} onChange={(event) => updateSchedule((current) => ({ ...current, enabled: true, rows: current.rows.map((item) => item.id === row.id ? { ...item, name: event.target.value } : item) }))} placeholder={"Installment " + (index + 1)} className="mt-2" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Percentage (%)</label>
                            <Input type="number" min={0} step="0.01" value={row.percentage} onChange={(event) => updateSchedule((current) => ({ ...current, enabled: true, rows: current.rows.map((item) => item.id === row.id ? { ...item, percentage: Number(event.target.value || 0) } : item) }))} className="mt-2" />
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Due Date</label>
                            <Input type="date" value={row.dueDate} onChange={(event) => updateSchedule((current) => ({ ...current, enabled: true, rows: current.rows.map((item) => item.id === row.id ? { ...item, dueDate: event.target.value } : item) }))} className="mt-2" />
                          </div>
                          <div className="flex items-end justify-end">
                            <Button type="button" variant="outline" size="icon" onClick={() => updateSchedule((current) => ({ ...current, rows: current.rows.filter((item) => item.id !== row.id) }))}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="mt-4 grid gap-4 xl:grid-cols-[0.9fr_1.1fr]">
                          <div className="rounded-2xl border border-slate-200 bg-white px-4 py-4">
                            <div className="text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500">Calculated Amount</div>
                            <div className="mt-2 text-xl font-semibold text-slate-950">{formatCurrency(row.amount)}</div>
                            <div className="mt-2 flex items-center gap-2 text-xs text-slate-500">
                              <CalendarDays className="h-3.5 w-3.5" />
                              {row.dueDate || "No due date selected"}
                            </div>
                          </div>
                          <div>
                            <label className="text-sm font-medium text-slate-700">Description / Milestone</label>
                            <Textarea value={row.description} onChange={(event) => updateSchedule((current) => ({ ...current, enabled: true, rows: current.rows.map((item) => item.id === row.id ? { ...item, description: event.target.value } : item) }))} placeholder="Example: Concept approval, design sign-off, mobilization, final handover" className="mt-2 min-h-[110px]" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                  <label className="text-sm font-medium text-slate-700">Payment Notes</label>
                  <Textarea value={schedule.notes} onChange={(event) => updateSchedule((current) => ({ ...current, enabled: true, notes: event.target.value }))} placeholder="Add optional payment terms, banking notes, or client-specific billing remarks." className="mt-2 min-h-[120px]" />
                </div>
              </div>
            </ScrollArea>

            <aside className="border-t border-slate-200 bg-slate-50/80 lg:border-l lg:border-t-0">
              <div className="space-y-5 px-6 py-6">
                <div className="rounded-3xl border border-slate-200 bg-white p-5">
                  <div className="text-sm font-semibold text-slate-950">Schedule Summary</div>
                  <div className="mt-4 space-y-3 text-sm text-slate-600">
                    <div className="flex items-center justify-between gap-3"><span>Proposal Grand Total</span><span className="font-semibold text-slate-950">{formatCurrency(schedule.grandTotal)}</span></div>
                    <div className="flex items-center justify-between gap-3"><span>Allocated %</span><span className="font-semibold text-slate-950">{summary.allocatedPercentage}%</span></div>
                    <div className="flex items-center justify-between gap-3"><span>Remaining %</span><span className="font-semibold text-slate-950">{summary.remainingPercentage}%</span></div>
                    <div className="flex items-center justify-between gap-3"><span>Total Installment Amount</span><span className="font-semibold text-slate-950">{formatCurrency(summary.totalAmount)}</span></div>
                  </div>
                </div>

                <div className="rounded-3xl border border-slate-200 bg-white p-5">
                  <div className="text-sm font-semibold text-slate-950">What Gets Saved</div>
                  <ul className="mt-3 space-y-2 text-sm text-slate-600">
                    <li>Current active version only</li>
                    <li>Installments, percentages, dates, and notes</li>
                    <li>Copied automatically into future versions</li>
                    <li>Shown as the last section in Preview, PDF, and XLSX</li>
                  </ul>
                </div>
              </div>
            </aside>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 px-8 py-5">
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <div className="flex flex-wrap items-center gap-3">
              <Button type="button" variant="outline" onClick={() => setSchedule(syncPaymentScheduleAmounts({ enabled: true, grandTotal: schedule.grandTotal, rows: createDefaultPaymentInstallments(), notes: "", updatedAt: null }, schedule.grandTotal))}>
                Reset Defaults
              </Button>
              <Button type="button" variant="accent" disabled={!canSave} onClick={() => { onSave({ ...schedule, enabled: true }); onOpenChange(false); }}>
                Save Payment Schedule
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
