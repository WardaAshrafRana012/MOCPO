"use client";

import { useMemo, useState } from "react";
import { ChevronDown, Eye, Lock, PencilLine, Plus, Minus, Ruler, Trash2 } from "lucide-react";

import { ActionBar } from "@/components/shared/action-bar";
import { EmptyState } from "@/components/shared/empty-state";
import { SectionHeader } from "@/components/shared/section-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { calculateScopeTotals } from "@/lib/calculations";
import { standardScopeGroupOptions } from "@/lib/scope-sheet";
import type { ScopeSheetRow } from "@/lib/types";
import { formatCurrency, formatNumber, getEditableNumberInputValue } from "@/lib/utils";
import { useProposalStore } from "@/store/proposal-store";

type ScopeGroup = {
  id: string;
  name: string;
  rows: ScopeSheetRow[];
  isLocked: boolean;
};

type RowSpanMeta = {
  left: {
    sft: Record<string, number>;
    rate: Record<string, number>;
    amount: Record<string, number>;
    hidden: Set<string>;
  };
  right: {
    sft: Record<string, number>;
    rate: Record<string, number>;
    amount: Record<string, number>;
    hidden: Set<string>;
  };
};

function buildScopeGroups(rows: ScopeSheetRow[], lockedGroupIds: string[]) {
  const groups: ScopeGroup[] = [];
  const seen = new Map<string, ScopeGroup>();

  for (const row of rows) {
    if (!row.groupId || !row.groupName) continue;

    if (!seen.has(row.groupId)) {
      const group: ScopeGroup = {
        id: row.groupId,
        name: row.groupName,
        rows: [],
        isLocked: lockedGroupIds.includes(row.groupId),
      };
      seen.set(row.groupId, group);
      groups.push(group);
    }

    seen.get(row.groupId)?.rows.push(row);
  }

  return groups;
}

function buildValueSpanMap(
  rows: ScopeSheetRow[],
  side: "left" | "right",
): {
  sft: Record<string, number>;
  rate: Record<string, number>;
  amount: Record<string, number>;
  hidden: Set<string>;
} {
  const sft: Record<string, number> = {};
  const rate: Record<string, number> = {};
  const amount: Record<string, number> = {};
  const hidden = new Set<string>();
  const valueSpanKey = side === "left" ? "leftValueRowSpan" : "rightValueRowSpan";

  let index = 0;
  while (index < rows.length) {
    const row = rows[index];
    if (row.kind !== "line") {
      index += 1;
      continue;
    }

    const currentSft = side === "left" ? row.leftSft : row.rightSft;
    const currentRate = side === "left" ? row.leftRate : row.rightRate;
    const currentAmount = side === "left" ? row.leftAmount : row.rightAmount;
    const explicitSpan = row[valueSpanKey];

    if (explicitSpan && explicitSpan > 1) {
      const span = rows.length - index;
      for (let offset = 1; offset < span; offset += 1) {
        hidden.add(rows[index + offset].id);
      }

      sft[row.id] = span;
      rate[row.id] = span;
      amount[row.id] = span;
      index += span;
      continue;
    }

    if (currentSft === null && currentRate === null && currentAmount === null) {
      index += 1;
      continue;
    }

    let span = 1;
    while (index + span < rows.length) {
      const nextRow = rows[index + span];
      if (nextRow.kind !== "line") {
        break;
      }

      const nextSft = side === "left" ? nextRow.leftSft : nextRow.rightSft;
      const nextRate = side === "left" ? nextRow.leftRate : nextRow.rightRate;
      const nextAmount = side === "left" ? nextRow.leftAmount : nextRow.rightAmount;
      const nextIsBlankValue = nextSft === null && nextRate === null && nextAmount === null;

      if (!nextIsBlankValue && (nextSft !== currentSft || nextRate !== currentRate || nextAmount !== currentAmount)) {
        break;
      }

      hidden.add(nextRow.id);
      span += 1;
    }

    sft[row.id] = span;
    rate[row.id] = span;
    amount[row.id] = span;
    index += span;
  }

  return { sft, rate, amount, hidden };
}

function buildRowSpanMeta(rows: ScopeSheetRow[]): RowSpanMeta {
  return {
    left: buildValueSpanMap(rows, "left"),
    right: buildValueSpanMap(rows, "right"),
  };
}

function parseListItems(source: string) {
  if (source.length === 0) {
    return [];
  }

  return source
    .split(/\r?\n/)
    .map((entry) => entry.trim());
}

function formatListItems(items: string[]) {
  return items.map((item) => item.trim()).join("\n");
}

const negativeListSuggestions = [
  "Branding Work",
  "Design Elements",
  "WCP",
  "Network Switches",
  "Routers",
  "UPS",
  "Server Racks",
  "UPS Batteries",
  "PABX",
  "PDU",
  "Electrical Locks",
  "Internet Service Provide",
  "LED TV",
  "Coffee Machine",
  "Dustbins",
  "Wastebins",
  "Air Purifiers",
  "Fridge",
  "Electric Kettle",
  "PTCL Line",
  "Network Boosters",
  "Repairing of Facade Glass",
  "Video Conferencing System",
  "Lighting Control System",
  "Fire Suppression",
  "WCP Unit",
];

function ScopeComparisonTable({
  group,
  sectionLocked,
  onEditToggle,
  onUpdateRow,
  onAddRow,
  onRemoveRow,
}: {
  group: ScopeGroup;
  sectionLocked: boolean;
  onEditToggle: (groupId: string, isLocked: boolean) => void;
  onUpdateRow: (
    rowId: string,
    field: "leftSerial" | "leftScope" | "leftSft" | "leftRate" | "rightSerial" | "rightScope" | "rightSft" | "rightRate",
    value: number | string,
  ) => void;
  onAddRow: (groupId: string) => void;
  onRemoveRow: (groupId: string) => void;
}) {
  const rowSpanMeta = useMemo(() => buildRowSpanMeta(group.rows), [group.rows]);
  const isReadOnly = sectionLocked || group.isLocked;

  return (
    <Card className="border-slate-200 bg-white shadow-sm">
      <CardHeader className="gap-3 border-b border-slate-200 pb-4 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <CardTitle>{group.name}</CardTitle>
          <CardDescription>
            {group.rows.length} rows mirrored into the Excel scope sheet - {isReadOnly ? "locked for review" : "editing unlocked"}
          </CardDescription>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {!isReadOnly ? (
            <>
              <Button variant="outline" onClick={() => onAddRow(group.id)}>
                <Plus className="h-4 w-4" />
                Add Field
              </Button>
              <Button variant="outline" onClick={() => onRemoveRow(group.id)}>
                <Minus className="h-4 w-4" />
                Remove Row
              </Button>
            </>
          ) : null}
          <Button
            variant={isReadOnly ? "secondary" : "accent"}
            onClick={() => onEditToggle(group.id, !group.isLocked)}
          >
            {isReadOnly ? <PencilLine className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
            {isReadOnly ? "Edit Fields" : "Lock Values"}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 pt-4">
        <div className="overflow-x-auto rounded-xl border border-slate-300 bg-white shadow-[inset_0_1px_0_rgba(255,255,255,0.7),0_18px_50px_rgba(15,23,42,0.08)]">
          <table className="min-w-[980px] border-collapse text-xs text-slate-950">
            <thead>
              <tr>
                <th colSpan={5} className="border border-slate-300 bg-gradient-to-r from-[#fff7df] via-[#f8e7b4] to-[#fff7df] px-3 py-2 text-center text-base font-bold uppercase tracking-[0.08em] text-slate-950">
                  Plan A (Optimal Scope)
                </th>
                <th colSpan={5} className="border border-slate-300 border-l-8 border-l-slate-500 bg-gradient-to-r from-[#dbeafe] via-[#eef6ff] to-[#dbeafe] px-3 py-2 text-center text-base font-bold uppercase tracking-[0.08em] text-slate-950">
                  Plan B (Buffered Scope)
                </th>
              </tr>
              <tr className="bg-slate-50">
                <th className="w-10 border border-slate-300 px-1 py-2 text-center font-bold text-blue-700 underline">S.No</th>
                <th className="w-[230px] border border-slate-300 px-2 py-2 text-center font-bold">Scope</th>
                <th className="w-16 border border-slate-300 px-1 py-2 text-center font-bold">Sft</th>
                <th className="w-16 border border-slate-300 px-1 py-2 text-center font-bold">Rate</th>
                <th className="w-24 border border-slate-300 px-1 py-2 text-center font-bold">Amount</th>
                <th className="w-10 border border-slate-300 border-l-8 border-l-slate-500 px-1 py-2 text-center font-bold text-blue-700 underline">S.No</th>
                <th className="w-[230px] border border-slate-300 px-2 py-2 text-center font-bold">Scope</th>
                <th className="w-16 border border-slate-300 px-1 py-2 text-center font-bold">Sft</th>
                <th className="w-16 border border-slate-300 px-1 py-2 text-center font-bold">Rate</th>
                <th className="w-24 border border-slate-300 px-1 py-2 text-center font-bold">Amount</th>
              </tr>
            </thead>
            <tbody>
              {group.rows.map((row) => (
                <tr key={row.id} className={row.kind === "groupHeader" ? "bg-[#fff4cf] font-bold" : "bg-white hover:bg-slate-50/70"}>
                  <td className="border border-slate-300 px-2 py-1.5 align-top">
                    {isReadOnly ? (
                      <span className="block text-center text-slate-950">{row.leftSerial || "-"}</span>
                    ) : (
                      <Input
                        value={row.leftSerial}
                        onChange={(event) => onUpdateRow(row.id, "leftSerial", event.target.value)}
                        className="border-0 bg-transparent px-1 text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-2 py-1.5 align-top">
                    {isReadOnly ? (
                      <div className="whitespace-pre-line leading-5 text-slate-950">{row.leftScope || "-"}</div>
                    ) : (
                      <Textarea
                        value={row.leftScope}
                        onChange={(event) => onUpdateRow(row.id, "leftScope", event.target.value)}
                        rows={Math.min(7, Math.max(1, row.leftScope.split("\n").length))}
                        className="min-h-[44px] resize-y border-0 bg-transparent px-1 py-2 shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  {!rowSpanMeta.left.hidden.has(row.id) ? (
                    <>
                      <td
                        rowSpan={rowSpanMeta.left.sft[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {isReadOnly ? (
                          row.leftSft === null ? "-" : formatNumber(row.leftSft)
                        ) : (
                          <Input
                            type="number"
                            value={getEditableNumberInputValue(row.leftSft)}
                            onChange={(event) => onUpdateRow(row.id, "leftSft", event.target.value)}
                            className="border-0 bg-amber-50 px-1 text-center shadow-none focus-visible:ring-1"
                          />
                        )}
                      </td>
                      <td
                        rowSpan={rowSpanMeta.left.rate[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {isReadOnly ? (
                          row.leftRate === null ? "-" : formatNumber(row.leftRate)
                        ) : (
                          <Input
                            type="number"
                            value={getEditableNumberInputValue(row.leftRate)}
                            onChange={(event) => onUpdateRow(row.id, "leftRate", event.target.value)}
                            className="border-0 bg-amber-50 px-1 text-center shadow-none focus-visible:ring-1"
                          />
                        )}
                      </td>
                      <td
                        rowSpan={rowSpanMeta.left.amount[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {row.leftAmount === null ? "-" : formatNumber(row.leftAmount)}
                      </td>
                    </>
                  ) : null}
                  <td className="border border-slate-300 border-l-8 border-l-slate-500 px-2 py-1.5 align-top">
                    {isReadOnly ? (
                      <span className="block text-center text-slate-950">{row.rightSerial || "-"}</span>
                    ) : (
                      <Input
                        value={row.rightSerial}
                        onChange={(event) => onUpdateRow(row.id, "rightSerial", event.target.value)}
                        className="border-0 bg-transparent px-1 text-center shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  <td className="border border-slate-300 px-2 py-1.5 align-top">
                    {isReadOnly ? (
                      <div className="whitespace-pre-line leading-5 text-slate-950">{row.rightScope || "-"}</div>
                    ) : (
                      <Textarea
                        value={row.rightScope}
                        onChange={(event) => onUpdateRow(row.id, "rightScope", event.target.value)}
                        rows={Math.min(7, Math.max(1, row.rightScope.split("\n").length))}
                        className="min-h-[44px] resize-y border-0 bg-transparent px-1 py-2 shadow-none focus-visible:ring-1"
                      />
                    )}
                  </td>
                  {!rowSpanMeta.right.hidden.has(row.id) ? (
                    <>
                      <td
                        rowSpan={rowSpanMeta.right.sft[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {isReadOnly ? (
                          row.rightSft === null ? "-" : formatNumber(row.rightSft)
                        ) : (
                          <Input
                            type="number"
                            value={getEditableNumberInputValue(row.rightSft)}
                            onChange={(event) => onUpdateRow(row.id, "rightSft", event.target.value)}
                            className="border-0 bg-amber-50 px-1 text-center shadow-none focus-visible:ring-1"
                          />
                        )}
                      </td>
                      <td
                        rowSpan={rowSpanMeta.right.rate[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {isReadOnly ? (
                          row.rightRate === null ? "-" : formatNumber(row.rightRate)
                        ) : (
                          <Input
                            type="number"
                            value={getEditableNumberInputValue(row.rightRate)}
                            onChange={(event) => onUpdateRow(row.id, "rightRate", event.target.value)}
                            className="border-0 bg-amber-50 px-1 text-center shadow-none focus-visible:ring-1"
                          />
                        )}
                      </td>
                      <td
                        rowSpan={rowSpanMeta.right.amount[row.id] ?? 1}
                        className="border border-slate-300 bg-gradient-to-b from-white to-slate-50 px-3 py-2 align-middle text-center font-bold text-slate-950"
                      >
                        {row.rightAmount === null ? "-" : formatNumber(row.rightAmount)}
                      </td>
                    </>
                  ) : null}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

export function ScopePage({
  mode = "page",
  sectionLocked = false,
  lockScopeSelection = false,
}: {
  mode?: "page" | "wizard" | "ai-workspace";
  sectionLocked?: boolean;
  lockScopeSelection?: boolean;
}) {
  const project = useProposalStore((state) => state.project);
  const updateScopeSectionField = useProposalStore((state) => state.updateScopeSectionField);
  const updateScopeRow = useProposalStore((state) => state.updateScopeRow);
  const loadStandardScopeGroup = useProposalStore((state) => state.loadStandardScopeGroup);
  const unloadScopeGroup = useProposalStore((state) => state.unloadScopeGroup);
  const setScopeGroupLocked = useProposalStore((state) => state.setScopeGroupLocked);
  const addScopeRow = useProposalStore((state) => state.addScopeRow);
  const removeScopeRowFromGroup = useProposalStore((state) => state.removeScopeRowFromGroup);
  const applyProjectAreaToScope = useProposalStore((state) => state.applyProjectAreaToScope);
  const setScopePlanMode = useProposalStore((state) => state.setScopePlanMode);
  const addScopeGroup = useProposalStore((state) => state.addScopeGroup);
  const showOnlyPreviewSection = useProposalStore((state) => state.showOnlyPreviewSection);
  const version = project.draftVersion;
  const groups = useMemo(
    () => buildScopeGroups(version.scopeSection.rows, version.scopeSection.lockedGroupIds),
    [version.scopeSection.lockedGroupIds, version.scopeSection.rows],
  );
  const [newGroupName, setNewGroupName] = useState("");
  const totals = calculateScopeTotals(version.scopeSection);
  const optimalItems = parseListItems(version.scopeSection.optimalExclusions);
  const bufferedItems = parseListItems(version.scopeSection.bufferedExclusions);
  const [showDeliverables, setShowDeliverables] = useState(true);
  const [showItemsNotIncluded, setShowItemsNotIncluded] = useState(false);
  const isWizard = mode === "wizard" || mode === "ai-workspace";
  return (
    <div className="space-y-6">
      <SectionHeader
        eyebrow={isWizard ? "Step 3" : "Tab 2"}
        title="Work Scope Break-up"
        actions={
          !isWizard ? (
            <div className="hidden flex-wrap gap-3 sm:flex">
              <Button variant="outline" onClick={() => {
                showOnlyPreviewSection("scope");
                window.open("/preview-proposal", "_blank", "noopener,noreferrer");
              }}>
                <Eye className="h-4 w-4" />
                Open Preview
              </Button>
              <Button variant="outline" onClick={applyProjectAreaToScope}>
                <Ruler className="h-4 w-4" />
                Apply Area to Scope
              </Button>
            </div>
          ) : null
        }
      />

      <div className="grid gap-6">
        <div className="grid gap-6">
          <Card className="border-white/80">
            <CardHeader className="pb-3">
              <button
                type="button"
                onClick={() => setShowDeliverables((value) => !value)}
                className="flex w-full items-start justify-between gap-4 text-left"
              >
                <span>
                  <CardTitle className="text-base">Deliverable categories</CardTitle>
                </span>
                <ChevronDown
                  className={`mt-1 h-5 w-5 shrink-0 text-slate-500 transition-transform ${showDeliverables ? "rotate-180" : ""}`}
                />
              </button>
            </CardHeader>
            {showDeliverables ? (
              <CardContent className="space-y-4">
                <div className="grid gap-3 xl:grid-cols-4">
                  {standardScopeGroupOptions.map((option) => {
                    const loadedGroup = groups.find((group) => group.id === option.id);
                    if (lockScopeSelection && !loadedGroup) {
                      return null;
                    }

                    return (
                      <div
                        key={option.id}
                        className={`flex items-center justify-between gap-3 rounded-xl border p-3 ${
                          loadedGroup ? "border-blue-300 bg-blue-50" : "border-slate-200 bg-slate-50"
                        }`}
                      >
                        <div>
                          <p className="text-sm font-medium">{option.name}</p>
                          <p className="text-xs text-slate-500">
                            {loadedGroup ? `${loadedGroup.rows.length} rows loaded` : "Workbook standard template"}
                          </p>
                        </div>
                        {!lockScopeSelection ? (
                          <div className="flex items-center gap-2">
                            {loadedGroup ? (
                              <>
                                <span className="rounded-md bg-blue-100 px-2.5 py-1 text-xs font-semibold text-blue-700">Loaded</span>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => {
                                    if (!sectionLocked) {
                                      unloadScopeGroup(option.id);
                                    }
                                  }}
                                  disabled={sectionLocked}
                                  className="h-7 w-7 p-0 text-slate-400 hover:text-red-500"
                                >
                                  <Minus className="h-3.5 w-3.5" />
                                </Button>
                              </>
                            ) : (
                              <Button
                                size="sm"
                                variant="accent"
                                onClick={() => {
                                  if (!sectionLocked) {
                                    loadStandardScopeGroup(option.id);
                                  }
                                }}
                                disabled={sectionLocked}
                              >
                                Add
                              </Button>
                            )}
                          </div>
                        ) : null}
                      </div>
                    );
                  })}
                </div>

                {!lockScopeSelection ? (
                  <div className="flex max-w-xl items-center gap-2">
                    <Input placeholder="New category name" value={newGroupName} onChange={(e) => setNewGroupName(e.target.value)} disabled={sectionLocked} />
                    <Button
                      disabled={sectionLocked}
                      onClick={() => {
                        if (newGroupName.trim()) {
                          addScopeGroup(newGroupName.trim());
                          setNewGroupName("");
                          setShowDeliverables(false);
                        }
                      }}
                    >
                      Add Category
                    </Button>
                  </div>
                ) : null}

                <Button
                  variant="outline"
                  className="w-full justify-between"
                  onClick={() => setShowItemsNotIncluded((value) => !value)}
                >
                  <span>Negative List</span>
                  <ChevronDown className={`h-4 w-4 transition-transform ${showItemsNotIncluded ? "rotate-180" : ""}`} />
                </Button>

                {showItemsNotIncluded ? (
                  <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <p className="text-sm font-semibold text-slate-950">Negative List</p>
                    <div className="mt-4 grid gap-4 xl:grid-cols-2">
                      <div className="space-y-2 xl:col-span-2">
                        <Label htmlFor="scope-exclusions-title">Section Title</Label>
                        <Input
                          id="scope-exclusions-title"
                          value={version.scopeSection.exclusionsTitle}
                          disabled={sectionLocked}
                          onChange={(event) => updateScopeSectionField("exclusionsTitle", event.target.value)}
                        />
                      </div>
                      <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-950">Optimal List</p>
                            <p className="text-xs text-slate-500">Create, reorder, and manage negative list entries.</p>
                          </div>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => updateScopeSectionField("optimalExclusions", formatListItems([...optimalItems, ""]))}
                            disabled={sectionLocked}
                          >
                            <Plus className="h-4 w-4" />
                            Add Item
                          </Button>
                        </div>
                        <div className="space-y-3">
                          {optimalItems.length === 0 ? (
                            <p className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">No optimal list entries added yet.</p>
                          ) : (
                            optimalItems.map((item, index) => (
                              <div key={`optimal-${index}`} className="grid gap-2 sm:grid-cols-[1fr_auto] items-center rounded-2xl border border-slate-200 bg-slate-50 p-3">
                                <Input
                                  value={item}
                                  placeholder="Add item"
                                  list="negative-list-suggestions"
                                  onChange={(event) => {
                                    const nextItems = [...optimalItems];
                                    nextItems[index] = event.target.value;
                                    updateScopeSectionField("optimalExclusions", formatListItems(nextItems));
                                  }}
                                  className="min-w-0 border-slate-200 bg-white"
                                  disabled={sectionLocked}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    const nextItems = optimalItems.filter((_, itemIndex) => itemIndex !== index);
                                    updateScopeSectionField("optimalExclusions", formatListItems(nextItems));
                                  }}
                                  disabled={sectionLocked}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                      <div className="space-y-4 rounded-2xl border border-slate-200 bg-white p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <p className="text-sm font-semibold text-slate-950">Buffered Optimal List</p>
                            <p className="text-xs text-slate-500">Manage the broader buffered negative list for client comparison.</p>
                          </div>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => updateScopeSectionField("bufferedExclusions", formatListItems([...bufferedItems, ""]))}
                            disabled={sectionLocked}
                          >
                            <Plus className="h-4 w-4" />
                            Add Item
                          </Button>
                        </div>
                        <div className="space-y-3">
                          {bufferedItems.length === 0 ? (
                            <p className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-500">No buffered list entries added yet.</p>
                          ) : (
                            bufferedItems.map((item, index) => (
                              <div key={`buffered-${index}`} className="grid gap-2 sm:grid-cols-[1fr_auto] items-center rounded-2xl border border-slate-200 bg-slate-50 p-3">
                                <Input
                                  value={item}
                                  placeholder="Add item"
                                  list="negative-list-suggestions"
                                  onChange={(event) => {
                                    const nextItems = [...bufferedItems];
                                    nextItems[index] = event.target.value;
                                    updateScopeSectionField("bufferedExclusions", formatListItems(nextItems));
                                  }}
                                  className="min-w-0 border-slate-200 bg-white"
                                  disabled={sectionLocked}
                                />
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => {
                                    const nextItems = bufferedItems.filter((_, itemIndex) => itemIndex !== index);
                                    updateScopeSectionField("bufferedExclusions", formatListItems(nextItems));
                                  }}
                                  disabled={sectionLocked}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
                <datalist id="negative-list-suggestions">
                  {negativeListSuggestions.map((item) => (
                    <option key={item} value={item} />
                  ))}
                </datalist>
              </CardContent>
            ) : null}
          </Card>
        </div>

        <div className="space-y-6">
          {groups.length > 0 ? (
            groups.map((group) => (
                <ScopeComparisonTable
                  key={group.id}
                  group={group}
                  sectionLocked={sectionLocked}
                  onEditToggle={setScopeGroupLocked}
                onUpdateRow={updateScopeRow}
                onAddRow={addScopeRow}
                onRemoveRow={removeScopeRowFromGroup}
              />
            ))
          ) : (
            <EmptyState
              title="No standard scope loaded yet"
              description="Click `ID Scope`, `Design Scope`, `HVAC /Air Conditioning`, `MEP Scope`, or `Furniture Scope` to load the standard rows."
            />
          )}

          {mode !== "wizard" ? (
            <>
              <Card className="border-white/80">
                <CardHeader>
                  <CardTitle>Workscope Break-up Tax</CardTitle>
                  <CardDescription>Saved into the current active version.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <div className="grid gap-4 md:grid-cols-[1fr_220px] md:items-end">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">GST Tax Rate %</p>
                        <p className="mt-1 text-sm text-slate-600">Changing this updates Plan A and Plan B tax values together.</p>
                      </div>
                      {sectionLocked ? (
                        <div className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-right text-lg font-semibold text-slate-950">{formatNumber(totals.gstRate)}</div>
                      ) : (
                        <Input
                          type="number"
                          value={getEditableNumberInputValue(totals.gstRate)}
                          onChange={(event) => updateScopeSectionField("gstTaxRate", Number(event.target.value || 0))}
                        />
                      )}
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Plan A Tax Card</p>
                      <p className="mt-1 text-sm font-medium text-slate-900">{version.scopeSection.optimalLabel}</p>
                      <div className="mt-4 space-y-2 text-sm text-slate-700">
                        <div className="flex justify-between gap-3"><span>Plan A Net Total</span><span>{formatCurrency(totals.planANetTotal)}</span></div>
                        <div className="flex justify-between gap-3"><span>GST Tax Rate %</span><span>{formatNumber(totals.gstRate)}</span></div>
                        <div className="flex justify-between gap-3"><span>Plan A Tax @ GST Rate</span><span>{formatCurrency(totals.planATaxAmount)}</span></div>
                        <div className="flex justify-between gap-3 font-semibold text-slate-950"><span>Plan A Total Amount With Tax</span><span>{formatCurrency(totals.planATotalWithTax)}</span></div>
                      </div>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <p className="text-xs font-semibold uppercase tracking-[0.14em] text-slate-500">Plan B Tax Card</p>
                      <p className="mt-1 text-sm font-medium text-slate-900">{version.scopeSection.bufferedLabel}</p>
                      <div className="mt-4 space-y-2 text-sm text-slate-700">
                        <div className="flex justify-between gap-3"><span>Plan B Net Total</span><span>{formatCurrency(totals.planBNetTotal)}</span></div>
                        <div className="flex justify-between gap-3"><span>GST Tax Rate %</span><span>{formatNumber(totals.gstRate)}</span></div>
                        <div className="flex justify-between gap-3"><span>Plan B Tax @ GST Rate</span><span>{formatCurrency(totals.planBTaxAmount)}</span></div>
                        <div className="flex justify-between gap-3 font-semibold text-slate-950"><span>Plan B Total Amount With Tax</span><span>{formatCurrency(totals.planBTotalWithTax)}</span></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-white/80">
                <CardHeader>
                  <CardTitle>Scope Note</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea rows={10} value={version.scopeSection.note} onChange={(event) => updateScopeSectionField("note", event.target.value)} />
                </CardContent>
              </Card>
            </>
          ) : null}
        </div>

      </div>
      {!isWizard ? (
        <ActionBar>
          <Button variant="outline" onClick={() => setScopePlanMode("compare")}>
            Compare Plans
          </Button>
          <Button variant="outline" onClick={applyProjectAreaToScope}>
            <Ruler className="h-4 w-4" />
            Apply Area to Scope
          </Button>
        </ActionBar>
      ) : null}
    </div>
  );
}
