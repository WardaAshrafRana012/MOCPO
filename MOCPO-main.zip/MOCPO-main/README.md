## MOCPO AI Chat

The AI builder now supports a real OpenAI-compatible provider flow and falls back to the local proposal assistant when no API key is configured.

### Free API setup

1. Copy `.env.example` to `.env.local`
2. Add an OpenRouter API key
3. Keep the default free router model or replace it with another compatible model

```bash
MOCPO_AI_API_KEY=your_openrouter_api_key
MOCPO_AI_BASE_URL=https://openrouter.ai/api/v1
MOCPO_AI_MODEL=openrouter/free
MOCPO_AI_SITE_URL=http://localhost:3003
MOCPO_AI_SITE_NAME=MOCPO Proposal AI
```

### Run locally

```bash
npm run dev
```

Or for a production preview:

```bash
npm run build
npm run start
```

## Google Drive Integration (Optional)

MOCPO can sync proposals to Google Drive for cloud backup and access from multiple devices. This feature is **optional** - the app works perfectly with localStorage alone.

### Setup Steps

#### 1. Create Drive Folder

1. Go to [Google Drive](https://drive.google.com)
2. Create a folder named `MOCPO Proposals`
3. Note the folder ID from the URL: `https://drive.google.com/drive/folders/YOUR_FOLDER_ID`

#### 2. Deploy Google Apps Script

1. Go to [Google Apps Script](https://script.google.com)
2. Create a new project
3. Copy the content from `apps-script/Code.gs` into the script editor
4. Replace `PASTE_MAIN_MOCPO_FOLDER_ID_HERE` with your folder ID
5. Deploy as Web App:
   - Click **Deploy** → **New Deployment**
   - Select type: **Web app**
   - Execute as: **Me**
   - Access as: **Anyone**
6. Copy the deployment URL

#### 3. Add Environment Variable

1. Open `.env.local`
2. Add the Apps Script URL:

```bash
NEXT_PUBLIC_APPS_SCRIPT_URL=https://script.google.com/macros/d/YOUR_DEPLOYMENT_ID/usercontent
```

#### 4. Run the App

```bash
npm run dev
```

### How It Works

**When you click "Save Version":**
- Version saved to localStorage (always works)
- Version synced to Drive (if configured)
- Shows success message: `Version X saved to Drive.`
- Shows error if sync fails: `Saved locally. Drive sync failed.`

**Drive Folder Structure:**
```
MOCPO Proposals/
├── Client Name/
│   ├── Project Name/
│   │   ├── Version 1/
│   │   │   └── proposal-data.json
│   │   ├── Version 2/
│   │   │   └── proposal-data.json
│   │   └── Version 3/
│   │       └── proposal-data.json
```

**View Cloud History:**
- Go to **Proposal History**
- Scroll down to **Google Drive sync** section
- Browse your Drive proposals by client → project → version
- Click a version to load it into the editor
