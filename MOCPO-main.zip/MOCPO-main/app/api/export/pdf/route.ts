import { NextResponse } from "next/server";

import { createDraftPdfBlob } from "@/lib/report";
import type { ProposalSummaryPayload } from "@/lib/types";

export async function POST(request: Request) {
  const payload = (await request.json()) as ProposalSummaryPayload;
  const fallbackBlob = createDraftPdfBlob(payload);
  const buffer = (await fallbackBlob.arrayBuffer()) as ArrayBuffer;

  return new NextResponse(new Blob([buffer], { type: "application/pdf" }), {
    status: 200,
    headers: {
      "Content-Type": "application/pdf",
    },
  });
}
