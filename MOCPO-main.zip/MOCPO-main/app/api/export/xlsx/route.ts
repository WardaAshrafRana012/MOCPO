import { NextResponse } from "next/server";

import { buildProposalWorkbookBuffer } from "@/lib/server/workbook";
import type { ProposalSummaryPayload } from "@/lib/types";

export async function POST(request: Request) {
  const payload = (await request.json()) as ProposalSummaryPayload;
  const workbookBuffer = await buildProposalWorkbookBuffer(payload.project, payload.version);

  return new NextResponse(
    new Blob([workbookBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }),
    {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${payload.project.projectName || "proposal"}.xlsx"`,
      },
    },
  );
}
