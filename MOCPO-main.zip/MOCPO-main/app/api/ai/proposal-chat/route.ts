import { NextResponse } from "next/server";

import { runProposalConversation, type ProposalChatRequest } from "@/lib/ai-proposal-chat";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as ProposalChatRequest;
    const response = await runProposalConversation(body);
    return NextResponse.json(response);
  } catch (error) {
    return NextResponse.json(
      {
        error: "Unable to process proposal chat request.",
        detail: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 400 },
    );
  }
}
