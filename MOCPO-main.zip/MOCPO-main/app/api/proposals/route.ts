import { NextResponse } from "next/server";

import { listLatestProjectsFromMongo } from "@/lib/server/mongodb";

export async function GET() {
  try {
    const projects = await listLatestProjectsFromMongo();

    return NextResponse.json({
      ok: true,
      projects,
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        message: error instanceof Error ? error.message : "Failed to load proposals from MongoDB.",
        projects: [],
      },
      { status: 500 },
    );
  }
}
