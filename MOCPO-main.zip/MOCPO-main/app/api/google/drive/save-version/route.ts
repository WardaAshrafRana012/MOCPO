import { NextResponse } from "next/server";

import { createFileName, getVersionNumber } from "@/lib/calculations";
import { createDraftPdfBlob } from "@/lib/report";
import { buildProposalWorkbookBuffer } from "@/lib/server/workbook";
import { saveProposalPayloadToMongo } from "@/lib/server/mongodb";
import type { ProposalSummaryPayload } from "@/lib/types";

interface AppsScriptSaveProposalFilesResponse {
  success?: boolean;
  message?: string;
  error?: string;
  projectFolderUrl?: string;
  versionFolderUrl?: string;
  files?: Array<{ type?: string; fileName?: string; fileUrl?: string }>;
}

async function parseAppsScriptResponse(response: Response): Promise<AppsScriptSaveProposalFilesResponse> {
  const contentType = response.headers.get("content-type") || "";
  const responseText = await response.text();

  if (!responseText.trim()) {
    throw new Error(`Apps Script returned an empty response (HTTP ${response.status}) from ${response.url || "unknown URL"}.`);
  }

  if (!contentType.toLowerCase().includes("application/json")) {
    const preview = responseText.replace(/\s+/g, " ").trim().slice(0, 300);
    throw new Error(
      `Apps Script returned ${contentType || "non-JSON content"} (HTTP ${response.status}) from ${response.url || "unknown URL"}. Response preview: ${preview}`,
    );
  }

  try {
    return JSON.parse(responseText) as AppsScriptSaveProposalFilesResponse;
  } catch {
    const preview = responseText.replace(/\s+/g, " ").trim().slice(0, 300);
    throw new Error(`Apps Script returned invalid JSON (HTTP ${response.status}) from ${response.url || "unknown URL"}. Response preview: ${preview}`);
  }
}

async function generatePdfBase64(payload: ProposalSummaryPayload) {
  const fallbackBlob = createDraftPdfBlob(payload);
  const buffer = Buffer.from(await fallbackBlob.arrayBuffer());
  return buffer.toString("base64");
}

export async function POST(request: Request) {
  try {
    const payload = (await request.json()) as ProposalSummaryPayload;
    const appsScriptUrl = process.env.NEXT_PUBLIC_APPS_SCRIPT_URL;

    const mongoSave = await saveProposalPayloadToMongo(payload, {
      driveSyncStatus: appsScriptUrl ? "pending" : "skipped",
      driveMessage: appsScriptUrl
        ? "Proposal saved to MongoDB. Drive sync in progress."
        : "Proposal saved to MongoDB. Drive sync not configured.",
    });

    if (!appsScriptUrl) {
      return NextResponse.json({
        ok: mongoSave.saved,
        mongoSaved: mongoSave.saved,
        driveSaved: false,
        message: mongoSave.saved
          ? "Proposal saved to MongoDB. Drive sync not configured because NEXT_PUBLIC_APPS_SCRIPT_URL is missing."
          : "Drive sync not configured. NEXT_PUBLIC_APPS_SCRIPT_URL is missing.",
      });
    }

    const versionNumber = getVersionNumber(payload.version.versionLabel);
    const pdfFileName = createFileName(payload.project.projectName, payload.version.versionLabel, "pdf");
    const xlsxFileName = createFileName(payload.project.projectName, payload.version.versionLabel, "xlsx");

    const [pdfBase64, workbookBuffer] = await Promise.all([
      generatePdfBase64(payload),
      buildProposalWorkbookBuffer(payload.project, payload.version),
    ]);

    console.info(`[drive-sync-api] saveProposalFiles -> ${appsScriptUrl}`);

    const response = await fetch(appsScriptUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "saveProposalFiles",
        clientName: payload.project.clientName || "No client name",
        projectName: payload.project.projectName || "Untitled Project",
        versionNumber,
        pdfBase64,
        xlsxBase64: Buffer.from(workbookBuffer).toString("base64"),
        pdfFileName,
        xlsxFileName,
      }),
      cache: "no-store",
    });

    const result = await parseAppsScriptResponse(response);

    if (!response.ok || !result.success) {
      const failureMessage = result.message || result.error || `Apps Script upload failed with HTTP ${response.status}.`;

      await saveProposalPayloadToMongo(payload, {
        driveSyncStatus: "failed",
        driveMessage: failureMessage,
      });

      return NextResponse.json(
        {
          ok: false,
          mongoSaved: mongoSave.saved,
          driveSaved: false,
          message: mongoSave.saved
            ? `Proposal saved to MongoDB. Drive sync failed: ${failureMessage}`
            : failureMessage,
        },
        { status: 500 },
      );
    }

    const successMessage = result.message || "Proposal files saved to Drive.";

    await saveProposalPayloadToMongo(payload, {
      driveSyncStatus: "success",
      driveMessage: successMessage,
      projectFolderUrl: result.projectFolderUrl || result.versionFolderUrl || "",
      files: result.files || [],
    });

    return NextResponse.json({
      ok: true,
      mongoSaved: mongoSave.saved,
      driveSaved: true,
      message: mongoSave.saved
        ? `Proposal saved to MongoDB and Google Drive. ${successMessage}`
        : successMessage,
      projectFolderUrl: result.projectFolderUrl || result.versionFolderUrl || "",
      files: result.files || [],
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        mongoSaved: false,
        driveSaved: false,
        message: error instanceof Error ? error.message : "Drive sync failed.",
      },
      { status: 500 },
    );
  }
}
