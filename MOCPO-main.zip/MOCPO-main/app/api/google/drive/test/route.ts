import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const hasCredentials = Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_PRIVATE_KEY);

  if (!hasCredentials) {
    return NextResponse.json({
      ok: false,
      message: "Upload not completed: Google Drive credentials are missing.",
    });
  }

  if (!body.folderId) {
    return NextResponse.json({ ok: false, message: "Folder ID is required for Drive upload verification." }, { status: 400 });
  }

  return NextResponse.json({ ok: true, message: "Drive upload test succeeded." });
}
