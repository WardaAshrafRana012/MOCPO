﻿import { NextRequest, NextResponse } from "next/server";

import { uploadFileToGoogleDrive } from "@/lib/google-drive/service";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const result = await uploadFileToGoogleDrive({
    fileName: body.poNumber ? `${body.poNumber}.pdf` : "proposal.pdf",
    mimeType: "application/pdf",
    folderId: body.folderId,
    dataBase64: body.dataBase64,
  });

  return NextResponse.json({
    ok: result.ok,
    message: result.message,
    driveFileId: result.driveFileId,
    pdfLink: result.webViewLink,
  });
}
