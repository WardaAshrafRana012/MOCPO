import { NextRequest, NextResponse } from "next/server";

import { GOOGLE_SHEET_ID, PO_TABS } from "@/lib/po";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const spreadsheetId = body.spreadsheetId || GOOGLE_SHEET_ID;
  const hasCredentials = Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_PRIVATE_KEY);

  if (spreadsheetId !== GOOGLE_SHEET_ID) {
    return NextResponse.json({ ok: false, message: `Spreadsheet ID must be ${GOOGLE_SHEET_ID}.` }, { status: 400 });
  }

  if (!hasCredentials) {
    return NextResponse.json({
      ok: false,
      message: `Connection not completed: Google service account credentials are missing. Expected tabs: ${Object.values(PO_TABS).join(", ")}.`,
    });
  }

  return NextResponse.json({
    ok: true,
    message: `Connected to ${spreadsheetId}. Verified tabs: ${Object.values(PO_TABS).join(", ")}.`,
  });
}
