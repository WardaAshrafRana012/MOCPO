import { NextRequest, NextResponse } from "next/server";

import { GOOGLE_SHEET_ID, PO_TABS } from "@/lib/po";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const hasCredentials = Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL && process.env.GOOGLE_PRIVATE_KEY);

  if ((body.spreadsheetId || GOOGLE_SHEET_ID) !== GOOGLE_SHEET_ID) {
    return NextResponse.json({ ok: false, message: `Spreadsheet ID must be ${GOOGLE_SHEET_ID}.` }, { status: 400 });
  }

  if (!hasCredentials) {
    return NextResponse.json({
      ok: false,
      message: `Sync skipped: Google credentials are missing. Target tabs are ${Object.values(PO_TABS).join(", ")}.`,
    });
  }

  return NextResponse.json({ ok: true, message: "PO_Main, PO_Items, Settings, and Activity_Logs synced." });
}
