import { DownloadsPage } from "@/components/downloads/downloads-page";

export default function Page() {
  return <DownloadsPage />;
}
