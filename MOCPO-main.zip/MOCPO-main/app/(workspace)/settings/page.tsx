import { DownloadsPage } from "@/components/downloads/downloads-page";

export default function SettingsPage() {
  return <DownloadsPage />;
}
