import { AIBuilderPage } from "@/components/ai/ai-builder-page";

export default function Page() {
  return <AIBuilderPage />;
}
