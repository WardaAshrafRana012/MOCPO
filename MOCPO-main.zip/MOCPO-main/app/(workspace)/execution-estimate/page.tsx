import { ExecutionPage } from "@/components/execution/execution-page";

export default function Page() {
  return <ExecutionPage />;
}
