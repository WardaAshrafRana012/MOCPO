﻿import { Suspense } from "react";

import { ProposalPreviewPage } from "@/components/preview/proposal-preview-page";

export default function Page() {
  return (
    <Suspense fallback={null}>
      <ProposalPreviewPage mode="page" />
    </Suspense>
  );
}
