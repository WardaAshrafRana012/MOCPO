import { VersionHistoryPage } from "@/components/version-history/version-history-page";

export default function Page() {
  return <VersionHistoryPage />;
}
