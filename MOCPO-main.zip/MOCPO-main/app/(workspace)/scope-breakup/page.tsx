import { ScopePage } from "@/components/scope/scope-page";

export default function Page() {
  return <ScopePage />;
}
