import { ProposalWorkspace } from "@/components/ai/ai-builder-page";

export default function Page() {
  return <ProposalWorkspace />;
}
