import { ConsultancyPage } from "@/components/consultancy/consultancy-page";

export default function Page() {
  return <ConsultancyPage />;
}
