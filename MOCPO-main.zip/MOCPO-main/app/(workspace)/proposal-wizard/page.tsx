import { Suspense } from "react";
import { AIBuilderPage } from "@/components/ai/ai-builder-page";

export default function Page() {
  return (
    <Suspense fallback={null}>
      <AIBuilderPage />
    </Suspense>
  );
}
