"use client";

import { useMemo } from "react";
import { useParams } from "next/navigation";

import { ProposalPreviewPage } from "@/components/preview/proposal-preview-page";
import { useProposalStore } from "@/store/proposal-store";

export default function PrintProposalPage() {
  const params = useParams<{ versionId: string }>();
  const versionId = params?.versionId ?? "";
  const project = useProposalStore((state) => state.project);
  const version = useMemo(
    () =>
      project.savedVersions.find((entry) => entry.id === versionId) ??
      (project.draftVersion.id === versionId ? project.draftVersion : project.savedVersions[0] ?? project.draftVersion),
    [project.draftVersion, project.savedVersions, versionId],
  );

  return <ProposalPreviewPage mode="page" versionOverride={version} />;
}
