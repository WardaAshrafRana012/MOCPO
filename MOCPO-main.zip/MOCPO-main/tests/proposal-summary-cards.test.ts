import { beforeEach, describe, expect, it } from "vitest";

import { PLAN_A_SCOPE_LABEL, PLAN_B_SCOPE_LABEL, getProposalSummaryCards } from "@/lib/proposal-summary-cards";
import type { ExecutionPlan } from "@/lib/types";
import { useProposalStore } from "@/store/proposal-store";

function resetProject() {
  const initialState = useProposalStore.getInitialState();
  useProposalStore.setState({
    activeProjectId: initialState.activeProjectId,
    project: initialState.project,
    proposals: initialState.proposals,
  });
}

function getSummaryLabels({
  consultancy,
  scope,
  plan,
}: {
  consultancy: boolean;
  scope: boolean;
  plan: ExecutionPlan;
}) {
  const store = useProposalStore.getState();

  store.updateProjectFields({ areaSqFt: 1000 });
  store.selectConsultancyDiscipline("Architecture");
  store.loadStandardScopeGroup("id-scope");
  store.setExecutionPlan(plan);
  store.setProposalSectionVisibility("consultancyFee", consultancy);
  store.setProposalSectionVisibility("workScope", scope);

  const { project } = useProposalStore.getState();
  return getProposalSummaryCards(project, project.draftVersion).map((card) => card.label);
}

describe("proposal summary cards", () => {
  beforeEach(() => {
    resetProject();
  });

  it.each([
    [{ consultancy: true, scope: false, plan: "both" as const }, ["Consultancy Fee"]],
    [{ consultancy: false, scope: true, plan: "optimal" as const }, [PLAN_A_SCOPE_LABEL]],
    [{ consultancy: false, scope: true, plan: "buffered" as const }, [PLAN_B_SCOPE_LABEL]],
    [{ consultancy: false, scope: true, plan: "both" as const }, [PLAN_A_SCOPE_LABEL, PLAN_B_SCOPE_LABEL]],
    [{ consultancy: true, scope: true, plan: "optimal" as const }, ["Consultancy Fee", PLAN_A_SCOPE_LABEL, "Final Estimate"]],
    [{ consultancy: true, scope: true, plan: "buffered" as const }, ["Consultancy Fee", PLAN_B_SCOPE_LABEL, "Final Estimate"]],
    [
      { consultancy: true, scope: true, plan: "both" as const },
      ["Consultancy Fee", PLAN_A_SCOPE_LABEL, PLAN_B_SCOPE_LABEL, "Final Estimate"],
    ],
  ])("returns matching card labels for %o", (selection, expectedLabels) => {
    expect(getSummaryLabels(selection)).toEqual(expectedLabels);
  });
});
