import { describe, expect, it } from "vitest";

import { buildInitialConversation, runLocalProposalConversation } from "@/lib/ai-proposal-chat";
import type { AIChatMessage } from "@/lib/types";

function createUserMessage(content: string): AIChatMessage {
  return {
    id: "user-message",
    role: "user",
    content,
    createdAt: new Date().toISOString(),
  };
}

describe("ai proposal chat", () => {
  it("asks a follow-up question when critical details are missing", () => {
    const response = runLocalProposalConversation({
      messages: [createUserMessage("Create a proposal for a villa in Karachi with architecture and interiors.")],
      combinedPrompt: "",
    });

    expect(response.conversation.readyToGenerate).toBe(false);
    expect(response.conversation.missingFields.length).toBeGreaterThan(0);
    expect(response.assistantMessage.content).toContain("client name");
  });

  it("marks the proposal ready when a complete prompt is provided", () => {
    const response = runLocalProposalConversation({
      messages: [
        createUserMessage(
          "Create a proposal for ABC Developers. Project Name: Luxury Villa. Area: 5000 sqft. Location: DHA Karachi. Include Architectural Design, Interior Design, MEP Design, and Site Supervision. Add ID scope, Design scope, HVAC scope and Electrical scope. Execution Plan: Premium. Select Plan A and Plan B. Timeline: 150 days.",
        ),
      ],
      combinedPrompt: "",
    });

    expect(response.conversation.readyToGenerate).toBe(true);
    expect(response.draft.clientName).toBe("ABC Developers");
    expect(response.draft.projectName).toBe("Luxury Villa");
    expect(response.draft.timelineDays).toBe(150);
    expect(response.draft.deliverables).toContain("Architecture");
    expect(response.draft.scopeGroupIds).toContain("id-scope");
    expect(response.draft.selectedPlan).toBe("both");
  });

  it("starts with a guided assistant welcome message", () => {
    const conversation = buildInitialConversation();

    expect(conversation.messages[0]?.role).toBe("assistant");
    expect(conversation.readyToGenerate).toBe(false);
  });

  it("parses natural proposal instructions and becomes ready to generate", () => {
    const response = runLocalProposalConversation({
      messages: [
        createUserMessage(
          "walmart client and project dollmen area 746900 and location karachi include architecture and structure scope add ID scope and HVAC scope and plan B and timeline of 187 days",
        ),
      ],
      combinedPrompt: "",
    });

    expect(response.conversation.readyToGenerate).toBe(true);
    expect(response.draft.clientName).toBe("Walmart");
    expect(response.draft.projectName).toBe("dollmen");
    expect(response.draft.areaSqFt).toBe(746900);
    expect(response.draft.location).toBe("Karachi");
    expect(response.draft.timelineDays).toBe(187);
    expect(response.draft.deliverables).toContain("Architecture");
    expect(response.draft.deliverables).toContain("Structure");
    expect(response.draft.selectedPlan).toBe("buffered");
  });

  it("supports the guided step-by-step chatbot flow", () => {
    const response = runLocalProposalConversation({
      messages: [
        { id: "a1", role: "assistant", content: "Enter the client name.", createdAt: new Date().toISOString() },
        createUserMessage("ABC Developers"),
        { id: "a2", role: "assistant", content: "Enter the project name.", createdAt: new Date().toISOString() },
        { id: "u2", role: "user", content: "Luxury Villa", createdAt: new Date().toISOString() },
        { id: "a3", role: "assistant", content: "Enter the project area in square feet.", createdAt: new Date().toISOString() },
        { id: "u3", role: "user", content: "5000", createdAt: new Date().toISOString() },
        { id: "a4", role: "assistant", content: "Enter the project location.", createdAt: new Date().toISOString() },
        { id: "u4", role: "user", content: "DHA Karachi", createdAt: new Date().toISOString() },
        { id: "a5", role: "assistant", content: "Consultancy Fee - Standard Deliverables", createdAt: new Date().toISOString() },
        { id: "u5", role: "user", content: "1,2,3", createdAt: new Date().toISOString() },
        { id: "a6", role: "assistant", content: "Work Scope Breakup", createdAt: new Date().toISOString() },
        { id: "u6", role: "user", content: "1,2,3", createdAt: new Date().toISOString() },
        { id: "a7", role: "assistant", content: "Execution Estimate Package", createdAt: new Date().toISOString() },
        { id: "u7", role: "user", content: "3", createdAt: new Date().toISOString() },
        { id: "a8", role: "assistant", content: "Selected Budget Plan For Final Estimate", createdAt: new Date().toISOString() },
        { id: "u8", role: "user", content: "1", createdAt: new Date().toISOString() },
        { id: "a9", role: "assistant", content: "Choose the project timeline days.", createdAt: new Date().toISOString() },
        { id: "u9", role: "user", content: "150 days", createdAt: new Date().toISOString() },
      ],
      combinedPrompt: "",
    });

    expect(response.conversation.readyToGenerate).toBe(true);
    expect(response.draft.clientName).toBe("ABC Developers");
    expect(response.draft.projectName).toBe("Luxury Villa");
    expect(response.draft.deliverables).toEqual(["Architecture", "Interior", "MEP Design"]);
    expect(response.draft.scopeGroupIds).toEqual(["id-scope", "design-scope", "hvac"]);
    expect(response.draft.executionPlan).toBe("Premium");
    expect(response.draft.selectedPlan).toBe("both");
  });
});
