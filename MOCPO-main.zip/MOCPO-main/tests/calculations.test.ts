import { describe, expect, it } from "vitest";

import {
  calculateConsultancyTotals,
  calculateFinalEstimate,
  calculateScopeTotals,
  calculateTimelineTotals,
  createFileName,
  getProposalWarnings,
} from "@/lib/calculations";
import { buildInitialConversation } from "@/lib/ai-proposal-chat";
import { createDefaultProposalSectionVisibility, createDefaultWorkspaceSections } from "@/lib/proposal-sections";
import { createConsultancyDiscipline, createExecutionSection } from "@/lib/seeds";
import { createScopeSection } from "@/lib/scope-sheet";
import type { ProjectRecord, ProposalVersion } from "@/lib/types";

function createFixture(): { project: ProjectRecord; version: ProposalVersion } {
  const version: ProposalVersion = {
    id: "version-1",
    versionLabel: "V1",
    createdAt: "2026-05-23T00:00:00.000Z",
    savedAt: null,
    basedOnVersionId: null,
    isDraft: true,
    previewSections: createDefaultProposalSectionVisibility(),
    workspaceSections: createDefaultWorkspaceSections(),
    consultancySection: {
      disciplines: [createConsultancyDiscipline("Architecture", 1000)],
    },
    scopeSection: createScopeSection(1000, ["id-scope"]),
    executionSection: createExecutionSection(),
  };

  const project: ProjectRecord = {
    projectId: "project-1",
    projectName: "North Bay",
    clientName: "Acme",
    clientFolderName: "Acme",
    areaSqFt: 1000,
    location: "Karachi",
    projectDurationMonths: 24,
    proposalDate: "2026-05-23",
    proposalStatus: "draft",
    currentDraftVersionId: version.id,
    activeVersionId: version.id,
    draftVersion: version,
    savedVersions: [],
    versions: [],
    downloads: [],
    taxRate: 15,
    discountRate: 0,
    notes: "",
    lastEditedAt: "2026-05-23T00:00:00.000Z",
    brandProfile: {
      companyName: "Apex",
      logoUrl: "",
      preparedBy: "Desk",
      signatureName: "Ammar",
      signatureTitle: "Director",
      footerText: "Footer",
    },
    aiConversation: buildInitialConversation(),
  };

  return { project, version };
}

describe("proposal calculations", () => {
  it("computes consultancy totals with SST", () => {
    const { project, version } = createFixture();
    const totals = calculateConsultancyTotals(
      version.consultancySection,
      project.taxRate,
      project.discountRate,
      project.projectDurationMonths,
    );

    expect(totals.subtotal).toBeGreaterThan(0);
    expect(totals.taxAmount).toBeCloseTo(totals.subtotal * 0.15);
    expect(totals.discountAmount).toBe(0);
    expect(totals.grandTotal).toBeCloseTo(totals.subtotal + totals.taxAmount);
  });

  it("computes scope totals and final estimate", () => {
    const { version } = createFixture();
    const scopeTotals = calculateScopeTotals(version.scopeSection);
    version.executionSection.importedConsultancyFee = 10000;
    version.executionSection.importedOptimalCost = scopeTotals.optimalTotal;

    expect(scopeTotals.optimalTotal).toBeGreaterThan(0);
    expect(calculateFinalEstimate(version.executionSection)).toBe(scopeTotals.optimalTotal + 10000);
  });

  it("builds timeline totals", () => {
    const { version } = createFixture();
    const totals = calculateTimelineTotals(version.executionSection.timelineRows);

    expect(totals.totalDays).toBeGreaterThan(0);
    expect(totals.totalMonths).toBeGreaterThan(0);
  });

  it("generates file names and warnings", () => {
    const { project, version } = createFixture();

    expect(createFileName(project.projectName, "V2", "pdf")).toBe("North_Bay_Proposal_V2.pdf");
    expect(getProposalWarnings(project, version)).toEqual([]);
  });
});
