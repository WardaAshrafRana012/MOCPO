import { beforeEach, describe, expect, it } from "vitest";

import { useProposalStore } from "@/store/proposal-store";

describe("proposal store versioning", () => {
  beforeEach(() => {
    const initialState = useProposalStore.getInitialState();
    useProposalStore.setState({
      activeProjectId: initialState.activeProjectId,
      project: initialState.project,
      proposals: initialState.proposals,
    });
  });

  it("keeps the same version number when editing after a save", () => {
    const { saveDraft, updateProjectFields } = useProposalStore.getState();

    const savedAtBefore = useProposalStore.getState().project.lastEditedAt;
    saveDraft();
    expect(useProposalStore.getState().project.savedVersions).toHaveLength(1);
    expect(useProposalStore.getState().project.draftVersion.isDraft).toBe(false);
    expect(useProposalStore.getState().project.savedVersions[0].savedAt).not.toBeNull();
    expect(useProposalStore.getState().project.lastEditedAt).not.toBe(savedAtBefore);

    updateProjectFields({ projectName: "Revised Project" });

    const state = useProposalStore.getState();
    expect(state.project.draftVersion.isDraft).toBe(true);
    expect(state.project.draftVersion.versionLabel).toBe("V1");
    expect(state.project.savedVersions).toHaveLength(1);

    const savedLabel = useProposalStore.getState().saveDraft();
    const savedState = useProposalStore.getState();
    expect(savedLabel).toBe("V1");
    expect(savedState.project.draftVersion.isDraft).toBe(false);
    expect(savedState.project.draftVersion.versionLabel).toBe("V1");
    expect(savedState.project.savedVersions).toHaveLength(1);
  });

  it("restores a saved version into a new draft", () => {
    const { saveDraft, restoreSavedVersion } = useProposalStore.getState();
    saveDraft();
    const saved = useProposalStore.getState().project.savedVersions[0];

    restoreSavedVersion(saved.id);

    const state = useProposalStore.getState();
    expect(state.project.draftVersion.isDraft).toBe(true);
    expect(state.project.draftVersion.versionLabel).toBe("V2");
    expect(state.project.draftVersion.basedOnVersionId).toBe(saved.id);
    expect(state.project.savedVersions).toHaveLength(1);
  });

  it("creates the next active version by deep-cloning the current active version and leaving old versions unchanged", () => {
    const {
      createNextVersion,
      loadStandardScopeGroup,
      saveDraft,
      selectConsultancyDiscipline,
      setProposalSectionVisibility,
      updateProjectFields,
    } = useProposalStore.getState();

    updateProjectFields({ areaSqFt: 1000 });
    selectConsultancyDiscipline("Architecture");
    loadStandardScopeGroup("id-scope");
    setProposalSectionVisibility("consultancyFee", true);
    setProposalSectionVisibility("workScope", true);
    saveDraft();
    const savedV1 = structuredClone(useProposalStore.getState().project.savedVersions[0]);
    useProposalStore.getState().updateProjectFields({ projectName: "Version 2 working copy" });

    createNextVersion();

    let state = useProposalStore.getState();
    const savedPreviousVersion = state.project.savedVersions.find((version) => version.versionLabel === "V1");
    expect(savedPreviousVersion?.previewSections.consultancyFee).toBe(true);
    expect(savedPreviousVersion?.previewSections.workScope).toBe(true);
    expect(savedPreviousVersion?.id).toBe(savedV1.id);
    expect(savedPreviousVersion?.savedAt).toBe(savedV1.savedAt);
    expect(state.project.draftVersion.versionLabel).toBe("V2");
    expect(state.project.savedVersions.find((version) => version.versionLabel === "V2")).toBeUndefined();
    expect(state.project.projectName).toBe("Version 2 working copy");
    expect(state.project.draftVersion.previewSections.consultancyFee).toBe(true);
    expect(state.project.draftVersion.previewSections.workScope).toBe(true);
    expect(state.project.draftVersion.workspaceSections.consultancyFee.hidden).toBe(false);
    expect(state.project.draftVersion.workspaceSections.workScope.hidden).toBe(false);
    expect(state.project.draftVersion.consultancySection.disciplines).toHaveLength(1);
    expect(state.project.draftVersion.scopeSection.rows.some((row) => row.groupId === "id-scope")).toBe(true);

    useProposalStore.getState().unloadScopeGroup("id-scope");
    state = useProposalStore.getState();

    expect(state.project.draftVersion.scopeSection.rows.some((row) => row.groupId === "id-scope")).toBe(false);
    expect(savedPreviousVersion?.scopeSection.rows.some((row) => row.groupId === "id-scope")).toBe(true);
  });

  it("hydrates partial ai conversation data without crashing", () => {
    const baseProject = useProposalStore.getState().project;

    useProposalStore.getState().importProjectData({
      ...baseProject,
      aiConversation: {
        messages: [
          {
            id: "legacy-message",
            role: "assistant",
            content: "Legacy prompt",
            createdAt: new Date().toISOString(),
          },
        ],
      },
    } as typeof baseProject);

    const state = useProposalStore.getState();
    expect(state.project.aiConversation.messages).toHaveLength(1);
    expect(Array.isArray(state.project.aiConversation.missingFields)).toBe(true);
    expect(Array.isArray(state.project.aiConversation.draft.deliverables)).toBe(true);
    expect(typeof state.project.aiConversation.draft.summary).toBe("string");
  });

  it("creates the next label from the true latest version including the active draft", () => {
    const { saveDraft, createNextVersion, restoreSavedVersion } = useProposalStore.getState();

    saveDraft();
    createNextVersion();
    const saved = useProposalStore.getState().project.savedVersions[0];

    restoreSavedVersion(saved.id);

    expect(useProposalStore.getState().project.draftVersion.versionLabel).toBe("V3");
  });

  it("saves the current active version after each new version is created", () => {
    const { createNextVersion, saveDraft, updateProjectFields } = useProposalStore.getState();

    expect(saveDraft()).toBe("V1");
    expect(useProposalStore.getState().project.draftVersion.versionLabel).toBe("V1");

    createNextVersion();
    expect(useProposalStore.getState().project.draftVersion.versionLabel).toBe("V2");
    updateProjectFields({ projectDurationMonths: 14 });
    expect(useProposalStore.getState().saveDraft()).toBe("V2");
    expect(useProposalStore.getState().project.draftVersion.versionLabel).toBe("V2");

    createNextVersion();
    expect(useProposalStore.getState().project.draftVersion.versionLabel).toBe("V3");
    updateProjectFields({ projectDurationMonths: 16 });
    expect(useProposalStore.getState().saveDraft()).toBe("V3");

    const state = useProposalStore.getState();
    expect(state.project.draftVersion.versionLabel).toBe("V3");
    expect(state.project.savedVersions.map((version) => version.versionLabel)).toEqual(["V3", "V2", "V1"]);
    expect(state.project.savedVersions.every((version) => version.savedAt)).toBe(true);
  });

  it("keeps the active new version when proposal builder regenerates the draft", () => {
    const { createNextVersion, generateProposalFromDraft, saveDraft } = useProposalStore.getState();

    saveDraft();
    createNextVersion();

    generateProposalFromDraft({
      clientName: "Client A",
      projectName: "Project A",
      areaSqFt: 5000,
      location: "Karachi",
      deliverables: ["Architecture"],
      scopeGroupIds: ["id-scope"],
      executionPlan: "Premium Turnkey Package",
      selectedPlan: "optimal",
      timelineDays: 120,
      notes: "",
      includeLandscape: null,
      summary: "",
    });

    const stateAfterGenerate = useProposalStore.getState();
    expect(stateAfterGenerate.project.draftVersion.versionLabel).toBe("V2");
    expect(stateAfterGenerate.project.savedVersions.map((version) => version.versionLabel)).toEqual(["V1"]);

    expect(useProposalStore.getState().saveDraft()).toBe("V2");
    expect(useProposalStore.getState().project.savedVersions.map((version) => version.versionLabel)).toEqual(["V2", "V1"]);
  });

  it("deletes a saved version without touching other snapshots", () => {
    const { saveDraft, createNextVersion, deleteSavedVersion } = useProposalStore.getState();

    saveDraft();
    createNextVersion();
    saveDraft();
    const stateBeforeDelete = useProposalStore.getState();
    const versionToDelete = stateBeforeDelete.project.savedVersions.find((version) => version.versionLabel === "V1");

    deleteSavedVersion(stateBeforeDelete.project.projectId, versionToDelete!.id);

    const stateAfterDelete = useProposalStore.getState();
    expect(stateAfterDelete.project.savedVersions.some((version) => version.versionLabel === "V1")).toBe(false);
    expect(stateAfterDelete.project.savedVersions.some((version) => version.versionLabel === "V2")).toBe(true);
  });
  it("keeps one download entry per file kind and version", () => {
    const { registerDownload } = useProposalStore.getState();

    registerDownload("pdf", "V1", "proposal-v1.pdf");
    registerDownload("pdf", "V1", "proposal-v1.pdf");
    registerDownload("xlsx", "V1", "proposal-v1.xlsx");
    registerDownload("xlsx", "V1", "proposal-v1.xlsx");

    const downloads = useProposalStore.getState().project.downloads;

    expect(downloads.filter((download) => download.kind === "pdf" && download.versionLabel === "V1")).toHaveLength(1);
    expect(downloads.filter((download) => download.kind === "xlsx" && download.versionLabel === "V1")).toHaveLength(1);
  });
});


