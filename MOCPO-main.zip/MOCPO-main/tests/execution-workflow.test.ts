import { describe, expect, it } from "vitest";

import { buildGeneratedDraftVersionFromDraft, withDraftSummary } from "@/lib/ai-proposal-builder";
import { buildInitialConversation } from "@/lib/ai-proposal-chat";
import { getProposalWarnings } from "@/lib/calculations";
import { createDefaultProposalSectionVisibility, createDefaultWorkspaceSections } from "@/lib/proposal-sections";
import { createBlankExecutionSection } from "@/lib/seeds";
import { createScopeSection } from "@/lib/scope-sheet";
import type { AIProposalDraft, ProjectRecord, ProposalVersion } from "@/lib/types";

function createProjectFixture(): ProjectRecord {
  const version: ProposalVersion = {
    id: "version-execution",
    versionLabel: "V1",
    createdAt: "2026-06-19T00:00:00.000Z",
    savedAt: null,
    savedBy: null,
    basedOnVersionId: null,
    isDraft: true,
    previewSections: createDefaultProposalSectionVisibility(),
    workspaceSections: createDefaultWorkspaceSections(),
    consultancySection: { disciplines: [] },
    scopeSection: createScopeSection(0),
    executionSection: createBlankExecutionSection(),
  };

  return {
    projectId: "project-execution",
    projectName: "Execution Project",
    clientName: "Client",
    clientFolderName: "Client",
    areaSqFt: 1000,
    location: "Karachi",
    projectDurationMonths: 3,
    proposalDate: "2026-06-19",
    proposalStatus: "draft",
    currentDraftVersionId: version.id,
    activeVersionId: version.id,
    draftVersion: version,
    savedVersions: [],
    versions: [],
    downloads: [],
    taxRate: 0,
    discountRate: 0,
    notes: "",
    lastEditedAt: "2026-06-19T00:00:00.000Z",
    brandProfile: {
      companyName: "MOCPO",
      logoUrl: "",
      preparedBy: "MOCPO Operator",
      signatureName: "",
      signatureTitle: "",
      footerText: "",
    },
    aiConversation: buildInitialConversation(),
  };
}

describe("execution estimate workflow", () => {
  it("creates timeline-only execution data when workscope is not selected", () => {
    const project = createProjectFixture();
    const draft: AIProposalDraft = withDraftSummary({
      clientName: "Client",
      projectName: "Execution Project",
      areaSqFt: 1000,
      location: "Karachi",
      deliverables: [],
      scopeGroupIds: [],
      executionPlan: "Premium Turnkey Package",
      selectedPlan: null,
      timelineDays: 120,
      notes: "",
      includeLandscape: null,
      summary: "",
    });

    const version = buildGeneratedDraftVersionFromDraft(project, draft);

    expect(version.executionSection.totalProjectDurationDays).toBe(120);
    expect(version.executionSection.timelineRows).toHaveLength(6);
    expect(version.executionSection.budgetPlans).toHaveLength(0);
    expect(version.executionSection.selectedPlan).toBeNull();
  });

  it("does not warn about missing scope or plan when only execution timeline is selected", () => {
    const project = createProjectFixture();
    const version: ProposalVersion = {
      ...project.draftVersion,
      previewSections: {
        ...project.draftVersion.previewSections,
        executionEstimate: true,
        timeline: true,
      },
      executionSection: {
        ...project.draftVersion.executionSection,
        totalProjectDurationDays: 30,
        timelineRows: [
          {
            id: "timeline-1",
            activity: "Design Process",
            days: 30,
            startDate: "2026-06-19",
            endDate: "2026-07-19",
            remarks: "",
          },
        ],
        isLocked: true,
      },
    };

    const warnings = getProposalWarnings(project, version);

    expect(warnings).not.toContain("Scope breakup incomplete.");
    expect(warnings).not.toContain("No plan selected.");
  });
});
