import { describe, expect, it } from "vitest";

import { buildGeneratedDraftVersionFromDraft, withDraftSummary } from "@/lib/ai-proposal-builder";
import { buildInitialConversation } from "@/lib/ai-proposal-chat";
import { createDefaultProposalSectionVisibility, createDefaultWorkspaceSections } from "@/lib/proposal-sections";
import { createBlankExecutionSection } from "@/lib/seeds";
import { createScopeSection } from "@/lib/scope-sheet";
import type { AIProposalDraft, ProjectRecord, ProposalVersion } from "@/lib/types";

function createBlankProjectFixture(): ProjectRecord {
  const version: ProposalVersion = {
    id: "version-blank",
    versionLabel: "V1",
    createdAt: "2026-06-13T00:00:00.000Z",
    savedAt: null,
    savedBy: null,
    basedOnVersionId: null,
    isDraft: true,
    previewSections: createDefaultProposalSectionVisibility(),
    workspaceSections: createDefaultWorkspaceSections(),
    consultancySection: { disciplines: [] },
    scopeSection: createScopeSection(0),
    executionSection: createBlankExecutionSection(),
  };

  return {
    projectId: "project-blank",
    projectName: "",
    clientName: "",
    clientFolderName: "",
    areaSqFt: 0,
    location: "",
    projectDurationMonths: 0,
    proposalDate: "2026-06-13",
    proposalStatus: "draft",
    currentDraftVersionId: version.id,
    activeVersionId: version.id,
    draftVersion: version,
    savedVersions: [],
    versions: [],
    downloads: [],
    taxRate: 0,
    discountRate: 0,
    notes: "",
    lastEditedAt: "2026-06-13T00:00:00.000Z",
    brandProfile: {
      companyName: "MOCPO",
      logoUrl: "",
      preparedBy: "MOCPO Operator",
      signatureName: "",
      signatureTitle: "",
      footerText: "",
    },
    aiConversation: buildInitialConversation(),
  };
}

describe("first-time section initialization", () => {
  it("creates blank section defaults with zero selected items", () => {
    const project = createBlankProjectFixture();

    expect(project.draftVersion.consultancySection.disciplines).toHaveLength(0);
    expect(project.draftVersion.scopeSection.rows).toHaveLength(0);
    expect(project.draftVersion.executionSection.selectedPlan).toBeNull();
    expect(project.draftVersion.executionSection.budgetPlans).toHaveLength(0);
    expect(project.draftVersion.executionSection.timelineRows).toHaveLength(0);
  });

  it("does not auto-select categories when generated draft selections are empty", () => {
    const project = createBlankProjectFixture();
    const draft: AIProposalDraft = withDraftSummary({
      clientName: "Client",
      projectName: "Project",
      areaSqFt: 1000,
      location: "Karachi",
      deliverables: [],
      scopeGroupIds: [],
      executionPlan: "Premium Turnkey Package",
      selectedPlan: null,
      timelineDays: 0,
      notes: "",
      includeLandscape: null,
      summary: "",
    });

    const version = buildGeneratedDraftVersionFromDraft(project, draft);

    expect(version.consultancySection.disciplines).toHaveLength(0);
    expect(version.scopeSection.rows).toHaveLength(0);
    expect(version.executionSection.selectedPlan).toBeNull();
    expect(version.executionSection.budgetPlans).toHaveLength(0);
    expect(version.executionSection.timelineRows).toHaveLength(0);
  });
});
