﻿import ExcelJS from "exceljs";
import { beforeEach, describe, expect, it } from "vitest";

import { buildProposalWorkbookBuffer } from "@/lib/server/workbook";
import { useProposalStore } from "@/store/proposal-store";

describe("proposal workbook export", () => {
  beforeEach(() => {
    const initialState = useProposalStore.getInitialState();
    useProposalStore.setState({
      activeProjectId: initialState.activeProjectId,
      project: initialState.project,
      proposals: initialState.proposals,
    });
  });

  it("exports only the consultancy sheet when only consultancy is visible", async () => {
    const store = useProposalStore.getState();
    store.selectConsultancyDiscipline("Architecture");
    store.setProposalSectionVisibility("consultancyFee", true);
    store.setProposalSectionVisibility("workScope", false);
    store.setProposalSectionVisibility("negativeList", false);
    store.setProposalSectionVisibility("optimalList", false);
    store.setProposalSectionVisibility("bufferedOptimalList", false);
    store.setProposalSectionVisibility("executionEstimate", false);
    store.setProposalSectionVisibility("timeline", false);
    store.setProposalSectionVisibility("budgetComparison", false);

    const state = useProposalStore.getState();
    const buffer = await buildProposalWorkbookBuffer(state.project, state.project.draftVersion);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    expect(workbook.worksheets.map((sheet) => sheet.name)).toEqual(["Consultancy Fee"]);
  });

  it("exports only the workscope sheet when only workscope is visible", async () => {
    const store = useProposalStore.getState();
    store.updateProjectFields({ areaSqFt: 5000 });
    store.loadStandardScopeGroup("id-scope");
    store.setProposalSectionVisibility("consultancyFee", false);
    store.setProposalSectionVisibility("workScope", true);
    store.setProposalSectionVisibility("negativeList", false);
    store.setProposalSectionVisibility("optimalList", false);
    store.setProposalSectionVisibility("bufferedOptimalList", false);
    store.setProposalSectionVisibility("executionEstimate", false);
    store.setProposalSectionVisibility("timeline", false);
    store.setProposalSectionVisibility("budgetComparison", false);

    const state = useProposalStore.getState();
    const buffer = await buildProposalWorkbookBuffer(state.project, state.project.draftVersion);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    expect(workbook.worksheets.map((sheet) => sheet.name)).toEqual(["Workscope Break-up"]);
  });

  it("exports only the execution sheet when only execution is visible", async () => {
    const store = useProposalStore.getState();
    store.setExecutionPlan("both");
    store.setProposalSectionVisibility("consultancyFee", false);
    store.setProposalSectionVisibility("workScope", false);
    store.setProposalSectionVisibility("negativeList", false);
    store.setProposalSectionVisibility("optimalList", false);
    store.setProposalSectionVisibility("bufferedOptimalList", false);
    store.setProposalSectionVisibility("executionEstimate", true);
    store.setProposalSectionVisibility("timeline", false);
    store.setProposalSectionVisibility("budgetComparison", false);

    const state = useProposalStore.getState();
    const buffer = await buildProposalWorkbookBuffer(state.project, state.project.draftVersion);
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(buffer);

    expect(workbook.worksheets.map((sheet) => sheet.name)).toEqual(["Execution Estimate"]);
  });
});
