"use client";

import { create } from "zustand";
import {
  calculateConsultancyDisciplineTotal,
  calculateConsultancyRowTotal,
  calculateConsultancyTotals,
  calculateFinalEstimate,
  calculateProposalGrandTotal,
  calculateScopeTotals,
  calculateTimelineEndDate,
  createFileName,
  getNextVersionLabel,
} from "@/lib/calculations";
import {
  createConsultancyDiscipline,
  createExecutionBudgetPlan,
  createBlankExecutionSection,
  createDistributedTimelineRows,
  createTimelineRows,
  standardTimelineActivities,
  standardDisciplineOrder,
} from "@/lib/seeds";
import {
  createScopeSection,
  createStandardScopeGroupRows,
  getScopeRowsForTotals,
  syncScopeSheetRows,
} from "@/lib/scope-sheet";
import {
  buildGeneratedDraftVersion,
  buildGeneratedDraftVersionFromDraft,
  parseProposalPrompt,
  withDraftSummary,
} from "@/lib/ai-proposal-builder";
import { buildInitialConversation } from "@/lib/ai-proposal-chat";
import {
  createDefaultProposalSectionVisibility,
  createDefaultWorkspaceSections,
  getAvailableProposalSections,
  getModuleProposalSections,
  migrateProposalSectionVisibility,
  migrateWorkspaceSections,
  proposalSectionOrder,
  syncPreviewSectionsFromWorkspaceSections,
} from "@/lib/proposal-sections";
import type {
  AIConversationState,
  AIProposalDraft,
  BrandProfile,
  DownloadArtifact,
  DownloadKind,
  DisciplineName,
  ExecutionBudgetPlan,
  ExecutionPlan,
  ProposalSectionKey,
  ProjectRecord,
  ProposalVersion,
  ScopePlanMode,
  PaymentSchedule,
} from "@/lib/types";
import { createId } from "@/lib/utils";
import { saveVersionToDrive } from "@/lib/drive-sync";
import { createEmptyPaymentSchedule, syncPaymentScheduleAmounts } from "@/lib/payment-schedule";

export interface DriveSyncStatus {
  isSyncing: boolean;
  lastMessage: string;
  lastMessageAt: number;
}

interface ProposalStore {
  project: ProjectRecord;
  proposals: ProjectRecord[];
  activeProjectId: string;
  driveSyncStatus: DriveSyncStatus;
  createNewProposal: () => void;
  generateProposalFromPrompt: (prompt: string) => void;
  generateProposalFromDraft: (draft: AIProposalDraft, conversation?: AIConversationState) => void;
  updateAIConversation: (conversation: AIConversationState) => void;
  selectProposal: (projectId: string) => void;
  deleteClientFolder: (clientKey: string) => void;
  deleteProject: (projectId: string) => void;
  deleteSavedVersion: (projectId: string, versionId: string) => void;
  updateClientFolderName: (folderName: string) => void;
  updateProjectFields: (fields: Partial<Pick<ProjectRecord, "projectName" | "clientName" | "areaSqFt" | "location" | "projectDurationMonths" | "proposalDate" | "taxRate" | "discountRate" | "notes">>) => void;
  updateBrandProfile: (fields: Partial<BrandProfile>) => void;
  selectConsultancyDiscipline: (discipline: DisciplineName) => void;
  unloadConsultancyDiscipline: (discipline: DisciplineName) => void;
  updateConsultancyTaxRate: (rate: number) => void;
  setConsultancyLocked: (discipline: DisciplineName, isLocked: boolean) => void;
  updateConsultancyRow: (discipline: DisciplineName, rowId: string, field: "phaseLabel" | "deliverable" | "rate" | "area", value: number | string) => void;
  addConsultancyRow: (discipline: DisciplineName) => void;
  removeConsultancyRow: (discipline: DisciplineName, rowId: string) => void;
  updateScopeSectionField: (
    field:
      | "sheetTitle"
      | "optimalLabel"
      | "bufferedLabel"
      | "totalLabel"
      | "exclusionsTitle"
      | "optimalExclusions"
      | "bufferedExclusions"
      | "note"
      | "gstTaxRate",
    value: number | string,
  ) => void;
  updateScopeRow: (
    rowId: string,
    field: "leftSerial" | "leftScope" | "leftSft" | "leftRate" | "rightSerial" | "rightScope" | "rightSft" | "rightRate",
    value: number | string,
  ) => void;
  loadStandardScopeGroup: (groupId: string) => void;
  unloadScopeGroup: (groupId: string) => void;
  setScopeGroupLocked: (groupId: string, isLocked: boolean) => void;
  addScopeRow: (groupId: string) => void;
  addScopeGroup: (groupName?: string) => void;
  removeScopeRowFromGroup: (groupId: string) => void;
  applyProjectAreaToScope: () => void;
  setScopePlanMode: (mode: ScopePlanMode) => void;
  saveSectionToPreview: (section: "consultancy" | "scope" | "execution") => void;
  showOnlyPreviewSection: (section: "consultancy" | "scope" | "execution") => void;
  saveAllSectionsToPreview: () => void;
  setProposalSectionVisibility: (section: keyof ProposalVersion["previewSections"], visible: boolean) => void;
  setProposalSectionLocked: (section: ProposalSectionKey, locked: boolean) => void;
  deleteProposalSection: (section: ProposalSectionKey) => void;
  restoreProposalSection: (section: ProposalSectionKey) => void;
  moveProposalSection: (section: ProposalSectionKey, direction: "up" | "down") => void;
  setExecutionPlan: (plan: ExecutionPlan) => void;
  setExecutionLocked: (isLocked: boolean) => void;
  setTotalProjectDurationDays: (days: number) => void;
  updateTimelineRow: (rowId: string, field: "activity" | "days" | "startDate" | "remarks", value: number | string) => void;
  addTimelineRow: () => void;
  removeTimelineRow: (rowId: string) => void;
  distributeTimelineDays: (totalDays: number) => void;
  importExecutionBudgetsFromScope: () => void;
  addExecutionBudgetPlan: (kind: "budget-a" | "budget-b") => void;
  removeExecutionBudgetPlan: (planId: string) => void;
  updateExecutionBudgetPlan: (planId: string, field: "title" | "optionLabel", value: string) => void;
  addExecutionBudgetRow: (planId: string) => void;
  updateExecutionBudgetRow: (
    planId: string,
    rowId: string,
    field: "description" | "quantity" | "rate" | "remarks",
    value: number | string,
  ) => void;
  removeExecutionBudgetRow: (planId: string, rowId: string) => void;
  savePaymentSchedule: (paymentSchedule: PaymentSchedule) => void;
  saveDraft: () => string;
  createNextVersion: () => void;
  restoreSavedVersion: (versionId: string) => void;
  setActiveVersion: (versionId: string) => void;
  registerDownload: (kind: DownloadKind, versionLabel: string, filename: string) => void;
  markFinalProposal: () => void;
  resetProject: () => void;
  importProjectData: (project: ProjectRecord) => void;
  syncVersionToDrive: () => Promise<void>;
}

function syncProjectVersionState(project: ProjectRecord): ProjectRecord {
  return {
    ...project,
    clientFolderName: project.clientName.trim(),
    currentDraftVersionId: project.draftVersion.id,
    activeVersionId: project.draftVersion.id,
    versions: project.savedVersions,
  };
}

const stableInitialTimestamp = "2026-01-01T00:00:00.000Z";
const stableInitialProposalDate = "2026-01-01";

function createBlankProject({ stable = false }: { stable?: boolean } = {}): ProjectRecord {
  const now = stable ? stableInitialTimestamp : new Date().toISOString();
  const blankScopeSection = createScopeSection(0, []);
  const draftVersion: ProposalVersion = {
    id: stable ? "version-initial" : createId("version"),
    versionLabel: "V1",
    createdAt: now,
    savedAt: null,
    savedBy: null,
    basedOnVersionId: null,
    isDraft: true,
    previewSections: createDefaultProposalSectionVisibility(),
    workspaceSections: createDefaultWorkspaceSections(),
    consultancySection: {
      disciplines: [],
      servicesSubtotal: 0,
      sstTaxRate: 15,
      sstTaxAmount: 0,
      servicesTotalWithTax: 0,
    },
    scopeSection: {
      ...blankScopeSection,
      sheetTitle: "",
      optimalExclusions: "",
      bufferedExclusions: "",
      note: "",
    },
    executionSection: createBlankExecutionSection(),
    paymentSchedule: createEmptyPaymentSchedule(),
  };
  const lastEditedAt = now;

  return {
    projectId: stable ? "project-initial" : createId("project"),
    projectName: "",
    clientName: "",
    clientFolderName: "",
    areaSqFt: 0,
    location: "",
    projectDurationMonths: 0,
    proposalDate: stable ? stableInitialProposalDate : new Date().toISOString().slice(0, 10),
    proposalStatus: "draft",
    currentDraftVersionId: draftVersion.id,
    activeVersionId: draftVersion.id,
    draftVersion,
    savedVersions: [],
    versions: [],
    downloads: [],
    taxRate: 15,
    discountRate: 0,
    notes: "",
    lastEditedAt,
    brandProfile: {
      companyName: "Molecule Work Place Solution",
      logoUrl: "/brand/molecule-workplace-solution.jpeg",
      preparedBy: "Molecule Proposal Desk",
      signatureName: "Molecule Work Place Solution",
      signatureTitle: "Design & Build Consultancy",
      footerText: "Confidential consultancy fee proposal prepared by Molecule Work Place Solution.",
    },
    aiConversation: buildInitialConversation({ stable }),
  };
}

function createInitialProject(): ProjectRecord {
  return createBlankProject({ stable: true });
}

function withTouchedProject(project: ProjectRecord, draftVersion: ProposalVersion): ProjectRecord {
  const syncedDraftVersion = recalculateDraftVersion(project, draftVersion);

  return syncProjectVersionState({
    ...project,
    draftVersion: syncedDraftVersion,
    lastEditedAt: new Date().toISOString(),
  });
}

function ensureDraft(project: ProjectRecord): ProjectRecord {
  if (project.draftVersion.isDraft) return project;

  return {
    ...project,
    proposalStatus: "draft" as const,
    draftVersion: {
      ...structuredClone(project.draftVersion),
      savedAt: null,
      isDraft: true,
    },
    lastEditedAt: new Date().toISOString(),
  };
}

function upsertProject(projects: ProjectRecord[], project: ProjectRecord) {
  const existingIndex = projects.findIndex((entry) => entry.projectId === project.projectId);
  if (existingIndex === -1) return [project, ...projects];

  return projects.map((entry, index) => (index === existingIndex ? project : entry));
}

function setActiveProject(projects: ProjectRecord[], project: ProjectRecord) {
  const syncedProject = syncProjectVersionState(project);
  return {
    project: syncedProject,
    activeProjectId: syncedProject.projectId,
    proposals: upsertProject(projects, syncedProject),
  };
}

function getProjectFolderName(project: Pick<ProjectRecord, "clientFolderName" | "clientName">) {
  return project.clientName?.trim() || "No client name";
}

function getProjectFolderKey(project: Pick<ProjectRecord, "clientFolderName" | "clientName">) {
  return getProjectFolderName(project).toLowerCase();
}

function syncDisciplineTotals(version: ProposalVersion, projectDurationMonths: number): ProposalVersion {
  return {
    ...version,
    consultancySection: {
      ...version.consultancySection,
      disciplines: version.consultancySection.disciplines.map((discipline) => ({
        ...discipline,
        rows: discipline.rows.map((row) => ({
          ...row,
          totalCost: calculateConsultancyRowTotal(
            row.rate,
            row.area,
            discipline.usesProjectDuration ? projectDurationMonths : 1,
          ),
        })),
        estimatedAmount: calculateConsultancyDisciplineTotal(
          discipline.rows,
          discipline.usesProjectDuration ? projectDurationMonths : 1,
        ),
      })),
    },
  };
}

function syncScopeTotals(version: ProposalVersion): ProposalVersion {
  return {
    ...version,
    scopeSection: {
      ...version.scopeSection,
      rows: syncScopeSheetRows(version.scopeSection.rows),
    },
  };
}

function syncTimeline(version: ProposalVersion): ProposalVersion {
  return {
    ...version,
    executionSection: {
      ...version.executionSection,
      timelineRows: version.executionSection.timelineRows.map((row) => ({
        ...row,
        endDate: calculateTimelineEndDate(row.startDate, row.days),
      })),
    },
  };
}

function appendDownload(project: ProjectRecord, kind: DownloadKind, versionLabel: string, filename: string) {
  const artifact: DownloadArtifact = {
    id: createId("download"),
    kind,
    versionLabel,
    filename,
    createdAt: new Date().toISOString(),
  };

  return {
    ...project,
    downloads: [
      artifact,
      ...project.downloads.filter((download) => !(download.kind === kind && download.versionLabel === versionLabel)),
    ].slice(0, 20),
  };
}

function normalizeProjectArea(project: ProjectRecord, areaSqFt: number) {
  const nextArea = Number.isFinite(areaSqFt) ? Math.max(0, areaSqFt) : 0;

  const draftVersion = {
    ...project.draftVersion,
    consultancySection: {
      ...project.draftVersion.consultancySection,
      disciplines: project.draftVersion.consultancySection.disciplines.map((discipline) => ({
        ...discipline,
        rows: discipline.rows.map((row) => ({
          ...row,
          area: discipline.inputLabel === "Area / SQ.FT Input" ? nextArea : row.area,
          totalCost: calculateConsultancyRowTotal(
            row.rate,
            discipline.inputLabel === "Area / SQ.FT Input" ? nextArea : row.area,
            discipline.usesProjectDuration ? project.projectDurationMonths : 1,
          ),
        })),
      })),
    },
    scopeSection: {
      ...project.draftVersion.scopeSection,
      rows: project.draftVersion.scopeSection.rows.map((row) =>
        row.kind === "line"
          ? {
              ...row,
              leftSft: row.leftSft !== null ? nextArea : row.leftSft,
              rightSft: row.rightSft !== null ? nextArea : row.rightSft,
            }
          : row,
      ),
    },
  };

  return syncScopeTotals(syncDisciplineTotals(draftVersion, project.projectDurationMonths));
}

function calculateBudgetPlanTotal(plan?: ExecutionBudgetPlan) {
  if (!plan) return 0;
  return plan.rows.reduce((sum, row) => sum + calculateConsultancyRowTotal(row.rate, row.quantity, 1), 0);
}

function hasMeaningfulBudgetRows(plan?: ExecutionBudgetPlan) {
  if (!plan) return false;

  return plan.rows.some(
    (row) =>
      row.quantity > 0 ||
      row.rate > 0 ||
      row.totalAmount > 0 ||
      (row.description.trim().length > 0 && row.description.trim() !== "New cost item"),
  );
}

function buildBudgetPlanFromScope(
  scopeSection: ProposalVersion["scopeSection"],
  kind: "budget-a" | "budget-b",
): ExecutionBudgetPlan {
  const plan = createExecutionBudgetPlan(kind);
  const useBuffered = kind === "budget-b";
  const rows = getScopeRowsForTotals(scopeSection.rows)
    .filter((row) => row.groupId && row.groupName)
    .map((row) => {
      const scopeName = (row.groupName || "Scope item").trim();
      const detail = (useBuffered ? row.rightScope : row.leftScope)?.trim();
      const description =
        detail && detail !== scopeName
          ? `${scopeName}: ${detail}`
          : scopeName;
      const quantity = useBuffered ? Number(row.rightSft ?? 0) : Number(row.leftSft ?? 0);
      const rate = useBuffered ? Number(row.rightRate ?? 0) : Number(row.leftRate ?? 0);

      return {
        id: createId("execution-budget-row"),
        description,
        quantity,
        rate,
        totalAmount: calculateConsultancyRowTotal(rate, quantity, 1),
        remarks: row.groupName ?? "",
      };
    });

  return {
    ...plan,
    rows: rows.length > 0 ? rows : plan.rows,
  };
}

function applyWorkspaceSectionLock(version: ProposalVersion, section: ProposalSectionKey, locked: boolean): ProposalVersion {
  const workspaceSections = {
    ...version.workspaceSections,
    [section]: {
      ...version.workspaceSections[section],
      locked,
    },
  };

  if (section === "consultancyFee") {
    return {
      ...version,
      workspaceSections,
      consultancySection: {
        ...version.consultancySection,
        disciplines: version.consultancySection.disciplines.map((discipline) => ({
          ...discipline,
          isLocked: locked,
        })),
      },
    };
  }

  if (["workScope", "negativeList", "optimalList", "bufferedOptimalList"].includes(section)) {
    const groupIds = Array.from(
      new Set(version.scopeSection.rows.map((row) => row.groupId).filter((row): row is string => Boolean(row))),
    );

    return {
      ...version,
      workspaceSections,
      scopeSection: {
        ...version.scopeSection,
        lockedGroupIds: locked ? groupIds : [],
      },
    };
  }

  return {
    ...version,
    workspaceSections,
    executionSection: {
      ...version.executionSection,
      isLocked: locked,
    },
  };
}

function lockGeneratedProposal(version: ProposalVersion): ProposalVersion {
  return proposalSectionOrder.reduce(
    (currentVersion, section) => applyWorkspaceSectionLock(currentVersion, section, true),
    version,
  );
}

function swapWorkspaceSectionOrder(
  workspaceSections: ProposalVersion["workspaceSections"],
  section: ProposalSectionKey,
  direction: "up" | "down",
) {
  const entries = Object.entries(workspaceSections).sort(([, left], [, right]) => left.order - right.order) as Array<
    [ProposalSectionKey, ProposalVersion["workspaceSections"][ProposalSectionKey]]
  >;
  const index = entries.findIndex(([key]) => key === section);
  const swapIndex = direction === "up" ? index - 1 : index + 1;

  if (index < 0 || swapIndex < 0 || swapIndex >= entries.length) {
    return workspaceSections;
  }

  const currentOrder = entries[index][1].order;
  const nextOrder = entries[swapIndex][1].order;

  return {
    ...workspaceSections,
    [entries[index][0]]: {
      ...workspaceSections[entries[index][0]],
      order: nextOrder,
    },
    [entries[swapIndex][0]]: {
      ...workspaceSections[entries[swapIndex][0]],
      order: currentOrder,
    },
  };
}

function hydrateDraftVersion(project: ProjectRecord, version: ProposalVersion): ProposalVersion {
  const areaSqFt = project.areaSqFt > 0 ? project.areaSqFt : 5000;
  const executionSection = version.executionSection ?? createBlankExecutionSection();
  const nextConsultancySection = {
    ...version.consultancySection,
    servicesSubtotal: version.consultancySection.servicesSubtotal ?? 0,
    sstTaxRate: version.consultancySection.sstTaxRate ?? 15,
    sstTaxAmount: version.consultancySection.sstTaxAmount ?? 0,
    servicesTotalWithTax: version.consultancySection.servicesTotalWithTax ?? 0,
  };
  const nextScopeSection =
    version.scopeSection.rows.length > 0 || version.scopeSection.lockedGroupIds.length === 0
      ? {
          ...version.scopeSection,
          gstTaxRate: version.scopeSection.gstTaxRate ?? 18,
          planANetTotal: version.scopeSection.planANetTotal ?? 0,
          planATaxAmount: version.scopeSection.planATaxAmount ?? 0,
          planATotalWithTax: version.scopeSection.planATotalWithTax ?? 0,
          planBNetTotal: version.scopeSection.planBNetTotal ?? 0,
          planBTaxAmount: version.scopeSection.planBTaxAmount ?? 0,
          planBTotalWithTax: version.scopeSection.planBTotalWithTax ?? 0,
        }
      : createScopeSection(areaSqFt);
  const hasScopeRows = nextScopeSection.rows.length > 0;
  const nextTimelineRows =
    executionSection.timelineRows?.length > 0
      ? executionSection.timelineRows
      : executionSection.totalProjectDurationDays > 0
        ? createDistributedTimelineRows(executionSection.totalProjectDurationDays, project.proposalDate)
        : executionSection.selectedPlan
          ? hasScopeRows
            ? createTimelineRows(project.proposalDate)
            : []
          : [];
  const consultancyTotals = calculateConsultancyTotals(
    nextConsultancySection,
    project.taxRate,
    project.discountRate,
    project.projectDurationMonths,
  );
  const scopeTotals = calculateScopeTotals(nextScopeSection);
  const selectedPlan: ExecutionPlan = executionSection.selectedPlan ?? null;
  const normalizedExistingPlans = (executionSection.budgetPlans ?? []).map((plan) => ({
    ...plan,
    rows: plan.rows.map((row) => ({
      ...row,
      totalAmount: calculateConsultancyRowTotal(row.rate, row.quantity, 1),
    })),
  }));
  const customPlans = normalizedExistingPlans.filter((plan) => plan.key === "custom");
  const budgetPlans = hasScopeRows
    ? ([
        ["budget-a", buildBudgetPlanFromScope(nextScopeSection, "budget-a")],
        ["budget-b", buildBudgetPlanFromScope(nextScopeSection, "budget-b")],
      ] as const).map(([key, fallbackPlan]) => {
        const existingPlan = normalizedExistingPlans.find((plan) => plan.key === key);
        return existingPlan && hasMeaningfulBudgetRows(existingPlan) ? existingPlan : fallbackPlan;
      }).concat(customPlans)
    : normalizedExistingPlans;
  const budgetATotal = calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-a"));
  const budgetBTotal = calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-b"));
  const nextVersionForPreview = {
    ...version,
    scopeSection: nextScopeSection,
    executionSection: {
      ...executionSection,
      timelineRows: nextTimelineRows,
    },
    paymentSchedule: version.paymentSchedule ?? createEmptyPaymentSchedule(),
  };
  const previewSections = migrateProposalSectionVisibility(version.previewSections, project, nextVersionForPreview);
  const workspaceSections = migrateWorkspaceSections(version.workspaceSections, previewSections);
  const syncedPreviewSections = syncPreviewSectionsFromWorkspaceSections(workspaceSections, previewSections);
  const proposalGrandTotal = calculateProposalGrandTotal(project, {
    ...nextVersionForPreview,
    previewSections: syncedPreviewSections,
  });
  const paymentSchedule = syncPaymentScheduleAmounts(
    nextVersionForPreview.paymentSchedule ?? createEmptyPaymentSchedule(),
    proposalGrandTotal,
  );

  return {
    ...version,
    previewSections: syncedPreviewSections,
    workspaceSections,
    consultancySection: {
      ...nextConsultancySection,
      servicesSubtotal: consultancyTotals.servicesSubtotal,
      sstTaxRate: consultancyTotals.sstRate,
      sstTaxAmount: consultancyTotals.sstAmount,
      servicesTotalWithTax: consultancyTotals.servicesTotalWithTax,
    },
    scopeSection: {
      ...nextScopeSection,
      gstTaxRate: scopeTotals.gstRate,
      planANetTotal: scopeTotals.planANetTotal,
      planATaxAmount: scopeTotals.planATaxAmount,
      planATotalWithTax: scopeTotals.planATotalWithTax,
      planBNetTotal: scopeTotals.planBNetTotal,
      planBTaxAmount: scopeTotals.planBTaxAmount,
      planBTotalWithTax: scopeTotals.planBTotalWithTax,
    },
    executionSection: {
      ...executionSection,
      importedConsultancyFee: consultancyTotals.servicesTotalWithTax,
      importedOptimalCost: budgetATotal || scopeTotals.optimalGrandTotal,
      importedBufferedCost: budgetBTotal || scopeTotals.bufferedGrandTotal,
      selectedPlan,
      totalProjectDurationDays: executionSection.totalProjectDurationDays ?? nextTimelineRows.reduce((sum, row) => sum + row.days, 0),
      timelineRows: nextTimelineRows,
      budgetPlans,
      importedAt: executionSection.importedAt ?? new Date().toISOString(),
    },
    paymentSchedule: {
      ...paymentSchedule,
      updatedAt: paymentSchedule.updatedAt ?? version.paymentSchedule?.updatedAt ?? null,
    },
  };
}

function recalculateDraftVersion(project: ProjectRecord, draftVersion: ProposalVersion) {
  const withDisciplines = syncDisciplineTotals(draftVersion, project.projectDurationMonths);
  const withScope = syncScopeTotals(withDisciplines);
  const withTimeline = syncTimeline(withScope);
  return hydrateDraftVersion(project, withTimeline);
}

function normalizeAIConversation(conversation?: Partial<AIConversationState> | null): AIConversationState {
  const initialConversation = buildInitialConversation();
  const draft = conversation?.draft;

  return {
    ...initialConversation,
    ...conversation,
    messages:
      Array.isArray(conversation?.messages) && conversation.messages.length > 0
        ? conversation.messages.map((message, index) => ({
            id: typeof message?.id === "string" && message.id.trim() ? message.id : createId(`ai-message-${index + 1}`),
            role: message?.role === "user" ? "user" : "assistant",
            content: typeof message?.content === "string" ? message.content : "",
            createdAt:
              typeof message?.createdAt === "string" && message.createdAt.trim()
                ? message.createdAt
                : new Date().toISOString(),
            quickReplies: Array.isArray(message?.quickReplies)
              ? message.quickReplies.filter((reply): reply is string => typeof reply === "string" && reply.trim().length > 0)
              : undefined,
          }))
        : initialConversation.messages,
    combinedPrompt: typeof conversation?.combinedPrompt === "string" ? conversation.combinedPrompt : "",
    draft: withDraftSummary({
      ...initialConversation.draft,
      ...draft,
      clientName: typeof draft?.clientName === "string" ? draft.clientName : initialConversation.draft.clientName,
      projectName: typeof draft?.projectName === "string" ? draft.projectName : initialConversation.draft.projectName,
      areaSqFt: typeof draft?.areaSqFt === "number" ? draft.areaSqFt : initialConversation.draft.areaSqFt,
      location: typeof draft?.location === "string" ? draft.location : initialConversation.draft.location,
      deliverables: Array.isArray(draft?.deliverables) ? draft.deliverables : initialConversation.draft.deliverables,
      scopeGroupIds: Array.isArray(draft?.scopeGroupIds) ? draft.scopeGroupIds : initialConversation.draft.scopeGroupIds,
      executionPlan: typeof draft?.executionPlan === "string" ? draft.executionPlan : initialConversation.draft.executionPlan,
      selectedPlan:
        draft?.selectedPlan === "optimal" || draft?.selectedPlan === "buffered" || draft?.selectedPlan === "both"
          ? draft.selectedPlan
          : initialConversation.draft.selectedPlan,
      timelineDays: typeof draft?.timelineDays === "number" ? draft.timelineDays : initialConversation.draft.timelineDays,
      notes: typeof draft?.notes === "string" ? draft.notes : initialConversation.draft.notes,
      includeLandscape:
        typeof draft?.includeLandscape === "boolean" || draft?.includeLandscape === null
          ? draft.includeLandscape
          : initialConversation.draft.includeLandscape,
      summary: typeof draft?.summary === "string" ? draft.summary : initialConversation.draft.summary,
    }),
    missingFields: Array.isArray(conversation?.missingFields)
      ? conversation.missingFields
      : initialConversation.missingFields,
    readyToGenerate: Boolean(conversation?.readyToGenerate),
    status:
      conversation?.status === "collecting" || conversation?.status === "ready" || conversation?.status === "idle"
        ? conversation.status
        : initialConversation.status,
    lastGeneratedAt:
      typeof conversation?.lastGeneratedAt === "string" || conversation?.lastGeneratedAt === null
        ? conversation.lastGeneratedAt
        : initialConversation.lastGeneratedAt,
  };
}

function hydrateProject(project?: Partial<ProjectRecord> | null): ProjectRecord {
  const initialProject = createInitialProject();
  const nextProject = {
    ...initialProject,
    ...project,
    brandProfile: {
      ...initialProject.brandProfile,
      ...project?.brandProfile,
    },
    downloads: Array.isArray(project?.downloads) ? project.downloads : initialProject.downloads,
    savedVersions: Array.isArray(project?.savedVersions)
      ? project.savedVersions
      : Array.isArray(project?.versions)
        ? project.versions
        : initialProject.savedVersions,
  } as ProjectRecord;
  const savedVersions = nextProject.savedVersions.map((version) => hydrateDraftVersion(nextProject, version));

  return syncProjectVersionState({
    ...nextProject,
    activeVersionId: nextProject.activeVersionId ?? nextProject.currentDraftVersionId ?? nextProject.draftVersion.id,
    draftVersion: hydrateDraftVersion(nextProject, nextProject.draftVersion),
    savedVersions,
    versions: savedVersions,
    aiConversation: normalizeAIConversation(nextProject.aiConversation),
  });
}

export const useProposalStore = create<ProposalStore>()((set, get) => ({
      ...(() => {
        const project = createInitialProject();
        return {
          project,
          proposals: [project],
          activeProjectId: project.projectId,
          driveSyncStatus: {
            isSyncing: false,
            lastMessage: "",
            lastMessageAt: 0,
          },
        };
      })(),
      createNewProposal: () =>
        set((state) => {
          const currentProjects = upsertProject(state.proposals, state.project);
          const project = createBlankProject();

          return setActiveProject(currentProjects, project);
        }),
      generateProposalFromDraft: (draft, conversation) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const currentProjects = upsertProject(state.proposals, project);
          const preparedProject: ProjectRecord = {
            ...project,
            projectName: draft.projectName || project.projectName || "AI Generated Proposal",
            clientName: draft.clientName || project.clientName || "Generated Client",
            clientFolderName: (draft.clientName || project.clientName || "Generated Client").trim(),
            areaSqFt: draft.areaSqFt > 0 ? draft.areaSqFt : project.areaSqFt || 5000,
            location: draft.location || project.location || "Location pending",
            projectDurationMonths: Math.max(1, Math.round((draft.timelineDays || 150) / 30)),
            notes: draft.notes,
            proposalStatus: "draft",
            aiConversation: conversation
              ? {
                  ...conversation,
                  draft,
                  readyToGenerate: true,
                  status: "ready",
                  lastGeneratedAt: new Date().toISOString(),
                }
              : project.aiConversation,
          };
          const generatedDraft = lockGeneratedProposal(buildGeneratedDraftVersionFromDraft(preparedProject, draft));
          const activeDraft: ProposalVersion = {
            ...generatedDraft,
            id: project.draftVersion.id,
            versionLabel: project.draftVersion.versionLabel,
            createdAt: project.draftVersion.createdAt,
            savedAt: null,
            savedBy: null,
            basedOnVersionId: project.draftVersion.basedOnVersionId,
            isDraft: true,
          };

          return setActiveProject(currentProjects, withTouchedProject(preparedProject, activeDraft));
        }),
      generateProposalFromPrompt: (prompt) =>
        set((state) => {
          const currentProjects = upsertProject(state.proposals, state.project);
          const parsed = parseProposalPrompt(prompt);
          const baseProject = createBlankProject();
          const preparedProject: ProjectRecord = {
            ...baseProject,
            projectName: parsed.projectName || "AI Generated Proposal",
            clientName: parsed.clientName || "Generated Client",
            clientFolderName: parsed.clientName || "Generated Client",
              areaSqFt: parsed.areaSqFt > 0 ? parsed.areaSqFt : 5000,
              location: parsed.location || "Location pending",
              projectDurationMonths: Math.max(1, Math.round(parsed.timelineDays / 30)),
              notes: parsed.notes,
              aiConversation: {
                ...state.project.aiConversation,
                combinedPrompt: prompt,
                draft: parsed,
                readyToGenerate: true,
                status: "ready",
                lastGeneratedAt: new Date().toISOString(),
              },
            };
            const generatedDraft = lockGeneratedProposal(buildGeneratedDraftVersion(preparedProject, prompt));

            return setActiveProject(currentProjects, withTouchedProject(preparedProject, generatedDraft));
          }),
        updateAIConversation: (conversation) =>
          set((state) =>
            setActiveProject(state.proposals, {
              ...state.project,
              aiConversation: conversation,
              lastEditedAt: new Date().toISOString(),
            }),
          ),
          selectProposal: (projectId) =>
        set((state) => {
          const currentProjects = upsertProject(state.proposals, state.project);
          const project = currentProjects.find((entry) => entry.projectId === projectId) ?? state.project;

          return setActiveProject(currentProjects, project);
        }),
      deleteClientFolder: (clientKey) =>
        set((state) => {
          const normalizedKey = clientKey.trim().toLowerCase();
          const currentProjects = upsertProject(state.proposals, state.project);
          const remainingProjects = currentProjects.filter((entry) => {
            const nextKey = getProjectFolderKey(entry);
            return nextKey !== normalizedKey;
          });

          if (remainingProjects.length === 0) {
            const project = createBlankProject();
            return {
              project,
              proposals: [project],
              activeProjectId: project.projectId,
            };
          }

          const nextProject =
            remainingProjects.find((entry) => entry.projectId === state.activeProjectId) ??
            remainingProjects[0];

          return {
            project: nextProject,
            proposals: remainingProjects,
            activeProjectId: nextProject.projectId,
          };
        }),
      deleteProject: (projectId) =>
        set((state) => {
          const currentProjects = upsertProject(state.proposals, state.project);
          const remainingProjects = currentProjects.filter((entry) => entry.projectId !== projectId);

          if (remainingProjects.length === 0) {
            const project = createBlankProject();
            return {
              project,
              proposals: [project],
              activeProjectId: project.projectId,
            };
          }

          const nextProject =
            remainingProjects.find((entry) => entry.projectId === state.activeProjectId && entry.projectId !== projectId) ??
            remainingProjects[0];

          return {
            project: nextProject,
            proposals: remainingProjects,
            activeProjectId: nextProject.projectId,
          };
        }),
      deleteSavedVersion: (projectId, versionId) =>
        set((state) => {
          const currentProjects = upsertProject(state.proposals, state.project);
          const targetProject = currentProjects.find((entry) => entry.projectId === projectId);
          if (!targetProject) return state;

          const remainingSavedVersions = targetProject.savedVersions.filter((version) => version.id !== versionId);
          const nextDraftVersion =
            targetProject.draftVersion.id === versionId
              ? remainingSavedVersions[0] ?? createBlankProject().draftVersion
              : targetProject.draftVersion;

          const nextProject = hydrateProject({
            ...targetProject,
            draftVersion: nextDraftVersion,
            savedVersions: remainingSavedVersions,
            versions: remainingSavedVersions,
            proposalStatus: remainingSavedVersions.length > 0 ? targetProject.proposalStatus : "draft",
            lastEditedAt: new Date().toISOString(),
          });

          const proposals = currentProjects.map((entry) =>
            entry.projectId === projectId ? nextProject : entry,
          );

          const activeProject = state.activeProjectId === projectId ? nextProject : state.project;

          return {
            project: activeProject,
            proposals,
            activeProjectId: state.activeProjectId === projectId ? nextProject.projectId : state.activeProjectId,
          };
        }),
      updateClientFolderName: (folderName) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const nextProject = {
            ...project,
            clientName: folderName.trim(),
            clientFolderName: folderName.trim(),
            proposalStatus: "draft" as ProjectRecord["proposalStatus"],
          };

          return setActiveProject(state.proposals, withTouchedProject(nextProject, nextProject.draftVersion));
        }),
      updateProjectFields: (fields) =>
        set((state) => {
          const draftVersionSource = ensureDraft(state.project).draftVersion;
          const nextArea = fields.areaSqFt ?? state.project.areaSqFt;
          let draftVersion = draftVersionSource;

          if (fields.areaSqFt !== undefined && fields.areaSqFt !== state.project.areaSqFt) {
            draftVersion = normalizeProjectArea(state.project, Number(nextArea));
          }
          if (
            fields.projectDurationMonths !== undefined &&
            fields.projectDurationMonths !== state.project.projectDurationMonths
          ) {
            draftVersion = syncDisciplineTotals(draftVersion, Number(fields.projectDurationMonths || state.project.projectDurationMonths));
          }

          const nextProject = {
            ...ensureDraft(state.project),
            ...fields,
            areaSqFt: Number(nextArea),
            clientFolderName: (fields.clientName ?? state.project.clientName).trim(),
            proposalStatus: "draft" as ProjectRecord["proposalStatus"],
          };

          return setActiveProject(state.proposals, withTouchedProject(nextProject, draftVersion));
        }),
      updateBrandProfile: (fields) =>
        set((state) => {
          const project = ensureDraft(state.project);
          return setActiveProject(state.proposals, {
            ...withTouchedProject(project, project.draftVersion),
            brandProfile: {
              ...project.brandProfile,
              ...fields,
            },
          });
        }),
      selectConsultancyDiscipline: (discipline) =>
        set((state) => {
          const project = ensureDraft(state.project);
          if (project.draftVersion.consultancySection.disciplines.some((item) => item.name === discipline)) {
            return setActiveProject(state.proposals, project);
          }

          const draftVersion = syncDisciplineTotals({
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: [
                ...project.draftVersion.consultancySection.disciplines,
                createConsultancyDiscipline(discipline, project.areaSqFt),
              ],
            },
          }, project.projectDurationMonths);

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      unloadConsultancyDiscipline: (discipline) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = {
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: project.draftVersion.consultancySection.disciplines.filter((item) => item.name !== discipline),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      updateConsultancyTaxRate: (rate) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = {
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              sstTaxRate: Math.max(0, Number(rate) || 0),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setConsultancyLocked: (discipline, isLocked) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = {
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: project.draftVersion.consultancySection.disciplines.map((item) =>
                item.name === discipline ? { ...item, isLocked } : item,
              ),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      updateConsultancyRow: (discipline, rowId, field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = syncDisciplineTotals({
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: project.draftVersion.consultancySection.disciplines.map((item) =>
                item.name === discipline
                  ? {
                      ...item,
                      rows: item.rows.map((row) =>
                        row.id === rowId
                          ? {
                              ...row,
                              [field]:
                                field === "phaseLabel" || field === "deliverable" ? String(value) : Number(value),
                              totalCost: calculateConsultancyRowTotal(
                                field === "rate" ? Number(value) : row.rate,
                                field === "area" ? Number(value) : row.area,
                                item.usesProjectDuration ? project.projectDurationMonths : 1,
                              ),
                            }
                          : row,
                      ),
                    }
                  : item,
              ),
            },
          }, project.projectDurationMonths);

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addConsultancyRow: (discipline) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const target = project.draftVersion.consultancySection.disciplines.find((item) => item.name === discipline);
          if (!target) return setActiveProject(state.proposals, project);

          const draftVersion = syncDisciplineTotals({
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: project.draftVersion.consultancySection.disciplines.map((item) =>
                item.name === discipline
                  ? {
                      ...item,
                      rows: [
                        ...item.rows,
                        {
                          id: createId("consultancy-row"),
                          phaseLabel: String(item.rows.length + 1),
                          deliverable: "New deliverable",
                          rate: 0,
                          area: item.inputLabel === "Area / SQ.FT Input" ? project.areaSqFt : 0,
                          totalCost: 0,
                        },
                      ],
                    }
                  : item,
              ),
            },
          }, project.projectDurationMonths);

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      removeConsultancyRow: (discipline, rowId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = syncDisciplineTotals({
            ...project.draftVersion,
            consultancySection: {
              ...project.draftVersion.consultancySection,
              disciplines: project.draftVersion.consultancySection.disciplines.map((item) =>
                item.name === discipline
                  ? {
                      ...item,
                      rows: item.rows.filter((row) => row.id !== rowId),
                    }
                  : item,
              ),
            },
          }, project.projectDurationMonths);

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      updateScopeSectionField: (field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = {
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              [field]: field === "gstTaxRate" ? Math.max(0, Number(value) || 0) : String(value),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      updateScopeRow: (rowId, field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: project.draftVersion.scopeSection.rows.map((row) =>
                row.id === rowId
                  ? {
                      ...row,
                      [field]:
                        field === "leftSerial" || field === "leftScope" || field === "rightSerial" || field === "rightScope"
                          ? String(value)
                          : value === ""
                            ? null
                            : Number(value),
                    }
                  : row,
              ),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      loadStandardScopeGroup: (groupId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const alreadyLoaded = project.draftVersion.scopeSection.rows.some((row) => row.groupId === groupId);
          if (alreadyLoaded) {
            return setActiveProject(state.proposals, project);
          }

          const standardRows = createStandardScopeGroupRows(groupId, project.areaSqFt);
          if (standardRows.length === 0) {
            return setActiveProject(state.proposals, project);
          }

          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: [...project.draftVersion.scopeSection.rows, ...standardRows],
              lockedGroupIds: Array.from(new Set([...project.draftVersion.scopeSection.lockedGroupIds, groupId])),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      unloadScopeGroup: (groupId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const nextRows = project.draftVersion.scopeSection.rows.filter((row) => row.groupId !== groupId);

          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: nextRows,
              lockedGroupIds: project.draftVersion.scopeSection.lockedGroupIds.filter((id) => id !== groupId),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setScopeGroupLocked: (groupId, isLocked) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const lockedGroupIds = isLocked
            ? Array.from(new Set([...project.draftVersion.scopeSection.lockedGroupIds, groupId]))
            : project.draftVersion.scopeSection.lockedGroupIds.filter((id) => id !== groupId);

          const draftVersion = {
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              lockedGroupIds,
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addScopeRow: (groupId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const rows = project.draftVersion.scopeSection.rows;
          let insertAfterIndex = -1;
          let groupName: string | null = null;

          rows.forEach((row, index) => {
            if (row.groupId === groupId) {
              if (row.kind === "groupHeader") {
                groupName = row.groupName ?? null;
                insertAfterIndex = index;
              }
              if (row.kind === "line") {
                insertAfterIndex = index;
              }
            }
          });

          if (!groupName || insertAfterIndex === -1) {
            return setActiveProject(state.proposals, project);
          }

          const newRow = {
            id: createId("scope-sheet-row"),
            kind: "line" as const,
            groupId,
            groupName,
            leftSerial: "",
            leftScope: "New scope item",
            leftSft: null,
            leftRate: null,
            leftAmount: null,
            rightSerial: "",
            rightScope: "",
            rightSft: null,
            rightRate: null,
            rightAmount: null,
          };

          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: [
                ...rows.slice(0, insertAfterIndex + 1),
                newRow,
                ...rows.slice(insertAfterIndex + 1),
              ],
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addScopeGroup: (groupName = "New Category") =>
        set((state) => {
          const project = ensureDraft(state.project);
          const rows = project.draftVersion.scopeSection.rows;

          // generate a simple group id based on the name
          const gid = createId("scope-group");
          const groupSerial = String(
            rows.filter((r) => r.kind === "groupHeader").length + 1,
          );

          const headerRow = {
            id: createId("scope-sheet-row"),
            kind: "groupHeader" as const,
            groupId: gid,
            groupName: groupName,
            leftSerial: groupSerial,
            leftScope: groupName,
            leftSft: null,
            leftRate: null,
            leftValueRowSpan: null,
            leftAmount: null,
            rightSerial: groupSerial,
            rightScope: groupName,
            rightSft: null,
            rightRate: null,
            rightValueRowSpan: null,
            rightAmount: null,
          };

          const lineRow = {
            id: createId("scope-sheet-row"),
            kind: "line" as const,
            groupId: gid,
            groupName,
            leftSerial: "i",
            leftScope: "New scope item",
            leftSft: null,
            leftRate: null,
            leftValueRowSpan: null,
            leftAmount: null,
            rightSerial: "i",
            rightScope: "New scope item",
            rightSft: null,
            rightRate: null,
            rightValueRowSpan: null,
            rightAmount: null,
          };

          const draftVersion = {
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: [...rows, headerRow, lineRow],
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, syncScopeTotals(draftVersion)));
        }),
      removeScopeRowFromGroup: (groupId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const rows = project.draftVersion.scopeSection.rows;
          const removeIndex = rows.reduce((lastIndex, row, index) => {
            if (row.groupId === groupId && row.kind === "line") {
              return index;
            }
            return lastIndex;
          }, -1);

          if (removeIndex === -1) {
            return setActiveProject(state.proposals, project);
          }

          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: rows.filter((_, index) => index !== removeIndex),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      applyProjectAreaToScope: () =>
        set((state) => {
          const project = ensureDraft(state.project);
          const areaSqFt = project.areaSqFt > 0 ? project.areaSqFt : 0;
          const draftVersion = syncScopeTotals({
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              rows: project.draftVersion.scopeSection.rows.map((row) =>
                row.kind === "line"
                  ? {
                      ...row,
                      leftSft: row.leftSft !== null ? areaSqFt : row.leftSft,
                      rightSft: row.rightSft !== null ? areaSqFt : row.rightSft,
                    }
                  : row,
              ),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setScopePlanMode: (mode) =>
        set((state) => {
          const project = ensureDraft(state.project);
          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            scopeSection: {
              ...project.draftVersion.scopeSection,
              planMode: mode,
            },
          }));
        }),
      saveSectionToPreview: (section) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const targetSections = getModuleProposalSections(section);
          const draftVersion = {
            ...project.draftVersion,
            previewSections: {
              ...project.draftVersion.previewSections,
              ...targetSections.reduce((acc, key) => {
                acc[key] = true;
                return acc;
              }, {} as ProposalVersion["previewSections"]),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      showOnlyPreviewSection: (section) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const targetSections = getModuleProposalSections(section);
          const draftVersion = {
            ...project.draftVersion,
            previewSections: {
              ...createDefaultProposalSectionVisibility(),
              ...targetSections.reduce((acc, key) => {
                acc[key] = true;
                return acc;
              }, {} as ProposalVersion["previewSections"]),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      saveAllSectionsToPreview: () =>
        set((state) => {
          const project = ensureDraft(state.project);
          const availableSections = getAvailableProposalSections(project, project.draftVersion);
          const previewSections = availableSections.reduce((acc, key) => {
            const stateForSection = project.draftVersion.workspaceSections[key];
            acc[key] = !stateForSection.hidden && !stateForSection.deleted;
            return acc;
          }, createDefaultProposalSectionVisibility());
          const draftVersion = {
            ...project.draftVersion,
            previewSections,
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setProposalSectionVisibility: (section, visible) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const workspaceSections = {
            ...project.draftVersion.workspaceSections,
            [section]: {
              ...project.draftVersion.workspaceSections[section],
              hidden: !visible,
              deleted: visible ? false : project.draftVersion.workspaceSections[section].deleted,
            },
          };
          const draftVersion = {
            ...project.draftVersion,
            workspaceSections,
            previewSections: syncPreviewSectionsFromWorkspaceSections(workspaceSections, {
              ...project.draftVersion.previewSections,
              [section]: visible,
            }),
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setProposalSectionLocked: (section, locked) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = applyWorkspaceSectionLock(project.draftVersion, section, locked);
          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      deleteProposalSection: (section) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const workspaceSections = {
            ...project.draftVersion.workspaceSections,
            [section]: {
              ...project.draftVersion.workspaceSections[section],
              hidden: true,
              deleted: true,
            },
          };
          const draftVersion = {
            ...project.draftVersion,
            workspaceSections,
            previewSections: syncPreviewSectionsFromWorkspaceSections(workspaceSections, {
              ...project.draftVersion.previewSections,
              [section]: false,
            }),
          };
          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      restoreProposalSection: (section) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const workspaceSections = {
            ...project.draftVersion.workspaceSections,
            [section]: {
              ...project.draftVersion.workspaceSections[section],
              hidden: false,
              deleted: false,
            },
          };
          const draftVersion = {
            ...project.draftVersion,
            workspaceSections,
            previewSections: syncPreviewSectionsFromWorkspaceSections(workspaceSections, {
              ...project.draftVersion.previewSections,
              [section]: true,
            }),
          };
          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      moveProposalSection: (section, direction) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const workspaceSections = swapWorkspaceSectionOrder(project.draftVersion.workspaceSections, section, direction);
          const draftVersion = {
            ...project.draftVersion,
            workspaceSections,
          };
          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      setExecutionPlan: (plan) =>
        set((state) => {
          const project = ensureDraft(state.project);
          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              selectedPlan: plan,
            },
          }));
        }),
      setExecutionLocked: (isLocked) =>
        set((state) => {
          const project = ensureDraft(state.project);
          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              isLocked,
            },
          }));
        }),
      setTotalProjectDurationDays: (days) =>
        set((state) => {
          const project = ensureDraft(state.project);
          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              totalProjectDurationDays: Math.max(0, Math.round(Number(days) || 0)),
            },
          }));
        }),
      updateTimelineRow: (rowId, field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const draftVersion = syncTimeline({
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              timelineRows: project.draftVersion.executionSection.timelineRows.map((row) =>
                row.id === rowId
                  ? {
                      ...row,
                      [field]: field === "activity" || field === "remarks" || field === "startDate" ? value : Number(value),
                    }
                  : row,
              ),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addTimelineRow: () =>
        set((state) => {
          const project = ensureDraft(state.project);
          const timelineRows = project.draftVersion.executionSection.timelineRows;
          const lastRow = timelineRows.at(-1);
          const startDate = lastRow?.endDate ?? project.proposalDate;
          const nextActivity = `Custom Activity ${timelineRows.length + 1}`;
          const nextRow = {
            id: createId("timeline-row"),
            activity: nextActivity,
            days: 0,
            startDate,
            endDate: calculateTimelineEndDate(startDate, 0),
            remarks: "",
          };
          const draftVersion = syncTimeline({
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              timelineRows: [...timelineRows, nextRow],
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      removeTimelineRow: (rowId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const timelineRows = project.draftVersion.executionSection.timelineRows;
          if (timelineRows.length <= 1) {
            return setActiveProject(state.proposals, project);
          }

          const nextRows = timelineRows.filter((row) => row.id !== rowId);
          const draftVersion = syncTimeline({
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              timelineRows: nextRows,
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      distributeTimelineDays: (totalDays) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const timelineRows = project.draftVersion.executionSection.timelineRows;
          if (timelineRows.length === 0) {
            return setActiveProject(state.proposals, project);
          }

          const safeTotalDays = Math.max(0, Math.round(totalDays));
          const distributedRows = createDistributedTimelineRows(
            safeTotalDays,
            timelineRows[0]?.startDate || project.proposalDate,
          );

          const draftVersion = syncTimeline({
            ...project.draftVersion,
            executionSection: {
              ...project.draftVersion.executionSection,
              totalProjectDurationDays: safeTotalDays,
              timelineRows: timelineRows.map((row, index) => ({
                ...row,
                activity: row.activity || standardTimelineActivities[index] || `Activity ${index + 1}`,
                days: distributedRows[index]?.days ?? row.days,
                startDate: distributedRows[index]?.startDate ?? row.startDate,
              })),
            },
          });

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      importExecutionBudgetsFromScope: () =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const scopeSection = project.draftVersion.scopeSection;
          const customPlans = executionSection.budgetPlans.filter((item) => item.key === "custom");
          const budgetAPlan = buildBudgetPlanFromScope(scopeSection, "budget-a");
          const budgetBPlan = buildBudgetPlanFromScope(scopeSection, "budget-b");
          const budgetPlans = [budgetAPlan, budgetBPlan, ...customPlans];
          const draftVersion = {
            ...project.draftVersion,
            executionSection: {
              ...executionSection,
              budgetPlans,
              importedOptimalCost: calculateBudgetPlanTotal(budgetAPlan),
              importedBufferedCost: calculateBudgetPlanTotal(budgetBPlan),
              importedAt: new Date().toISOString(),
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addExecutionBudgetPlan: (kind) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          if (executionSection.budgetPlans.some((item) => item.key === kind)) {
            return setActiveProject(state.proposals, project);
          }

          const nextPlan = buildBudgetPlanFromScope(project.draftVersion.scopeSection, kind);
          const budgetPlans = [...executionSection.budgetPlans, nextPlan];
          const nextExecutionSection = {
            ...executionSection,
            budgetPlans,
            importedOptimalCost:
              calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-a")) || executionSection.importedOptimalCost,
            importedBufferedCost:
              calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-b")) || executionSection.importedBufferedCost,
          };
          const draftVersion = {
            ...project.draftVersion,
            executionSection: nextExecutionSection,
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      removeExecutionBudgetPlan: (planId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const budgetPlans = executionSection.budgetPlans.filter((item) => item.id !== planId);
          const draftVersion = {
            ...project.draftVersion,
            executionSection: {
              ...executionSection,
              budgetPlans,
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      updateExecutionBudgetPlan: (planId, field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const budgetPlans = executionSection.budgetPlans.map((item) =>
            item.id === planId ? { ...item, [field]: value } : item,
          );
          const draftVersion = {
            ...project.draftVersion,
            executionSection: {
              ...executionSection,
              budgetPlans,
            },
          };

          return setActiveProject(state.proposals, withTouchedProject(project, draftVersion));
        }),
      addExecutionBudgetRow: (planId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const budgetPlans = executionSection.budgetPlans.map((item) =>
            item.id === planId
              ? {
                  ...item,
                  rows: [
                    ...item.rows,
                    {
                      id: createId("execution-budget-row"),
                      description: "New cost item",
                      quantity: 0,
                      rate: 0,
                      totalAmount: 0,
                      remarks: "",
                    },
                  ],
                }
              : item,
          );
          const nextExecutionSection = {
            ...executionSection,
            budgetPlans,
            importedOptimalCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-a")) || executionSection.importedOptimalCost,
            importedBufferedCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-b")) || executionSection.importedBufferedCost,
          };

          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: nextExecutionSection,
          }));
        }),
      updateExecutionBudgetRow: (planId, rowId, field, value) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const budgetPlans = executionSection.budgetPlans.map((item) =>
            item.id === planId
              ? {
                  ...item,
                  rows: item.rows.map((row) => {
                    if (row.id !== rowId) return row;

                    const nextRow = {
                      ...row,
                      [field]: field === "description" || field === "remarks" ? String(value) : Number(value),
                    };

                    return {
                      ...nextRow,
                      totalAmount: calculateConsultancyRowTotal(nextRow.rate, nextRow.quantity, 1),
                    };
                  }),
                }
              : item,
          );
          const nextExecutionSection = {
            ...executionSection,
            budgetPlans,
            importedOptimalCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-a")) || 0,
            importedBufferedCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-b")) || 0,
          };

          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: nextExecutionSection,
          }));
        }),
      removeExecutionBudgetRow: (planId, rowId) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const executionSection = project.draftVersion.executionSection;
          const budgetPlans = executionSection.budgetPlans.map((item) =>
            item.id === planId
              ? {
                  ...item,
                  rows: item.rows.length <= 1 ? item.rows : item.rows.filter((row) => row.id !== rowId),
                }
              : item,
          );
          const nextExecutionSection = {
            ...executionSection,
            budgetPlans,
            importedOptimalCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-a")) || 0,
            importedBufferedCost: calculateBudgetPlanTotal(budgetPlans.find((item) => item.key === "budget-b")) || 0,
          };

          return setActiveProject(state.proposals, withTouchedProject(project, {
            ...project.draftVersion,
            executionSection: nextExecutionSection,
          }));
        }),
      savePaymentSchedule: (paymentSchedule) =>
        set((state) => {
          const project = ensureDraft(state.project);
          const proposalGrandTotal = calculateProposalGrandTotal(project, project.draftVersion);
          const nextPaymentSchedule = syncPaymentScheduleAmounts(
            {
              ...paymentSchedule,
              enabled: paymentSchedule.enabled || paymentSchedule.rows.length > 0,
              updatedAt: new Date().toISOString(),
            },
            proposalGrandTotal,
          );

          return setActiveProject(
            state.proposals,
            withTouchedProject(project, {
              ...project.draftVersion,
              paymentSchedule: nextPaymentSchedule,
              previewSections: {
                ...project.draftVersion.previewSections,
                paymentSchedule: nextPaymentSchedule.enabled,
              },
            }),
          );
        }),
      saveDraft: () => {
        const { project } = get();
        const syncedDraftVersion = recalculateDraftVersion(project, project.draftVersion);
        const snapshot: ProposalVersion = {
          ...structuredClone(syncedDraftVersion),
          isDraft: false,
          savedAt: new Date().toISOString(),
          savedBy: project.brandProfile.preparedBy || "MOCPO Operator",
        };
        const fileName = createFileName(project.projectName, snapshot.versionLabel, "proposal.json");

        const nextProject = appendDownload(
          {
            ...project,
            proposalStatus: "saved",
            currentDraftVersionId: snapshot.id,
            draftVersion: snapshot,
            savedVersions: [snapshot, ...project.savedVersions.filter((version) => version.versionLabel !== snapshot.versionLabel)],
            lastEditedAt: new Date().toISOString(),
          },
          "json",
          snapshot.versionLabel,
          fileName,
        );

        set((state) => setActiveProject(state.proposals, nextProject));

        return snapshot.versionLabel;
      },
      createNextVersion: () =>
        set((state) => {
          const syncedDraftVersion = recalculateDraftVersion(state.project, state.project.draftVersion);
          const now = new Date().toISOString();
          const nextVersionLabel = getNextVersionLabel([state.project.draftVersion, ...state.project.savedVersions]);
          const sourceVersion =
            state.project.savedVersions.find((version) => version.versionLabel === syncedDraftVersion.versionLabel) ??
            syncedDraftVersion;
          const nextVersion: ProposalVersion = {
            ...structuredClone(syncedDraftVersion),
            id: createId("version"),
            versionLabel: nextVersionLabel,
            createdAt: now,
            savedAt: null,
            savedBy: null,
            basedOnVersionId: sourceVersion.id,
            isDraft: true,
          };

          return setActiveProject(
            state.proposals,
            withTouchedProject(
              {
                ...state.project,
                proposalStatus: "draft",
              },
              nextVersion,
            ),
          );
        }),
      restoreSavedVersion: (versionId) =>
        set((state) => {
          const version = state.project.savedVersions.find((entry) => entry.id === versionId);
          if (!version) return state;

          const draftVersion: ProposalVersion = {
            ...structuredClone(version),
            id: createId("version"),
            versionLabel: getNextVersionLabel([state.project.draftVersion, ...state.project.savedVersions]),
            createdAt: new Date().toISOString(),
            savedAt: null,
            savedBy: null,
            basedOnVersionId: version.id,
            isDraft: true,
          };

          return setActiveProject(
            state.proposals,
            withTouchedProject(
              {
                ...state.project,
                proposalStatus: "draft",
              },
              draftVersion,
            ),
          );
        }),
      registerDownload: (kind, versionLabel, filename) =>
        set((state) => setActiveProject(state.proposals, appendDownload(state.project, kind, versionLabel, filename))),
      setActiveVersion: (versionId) =>
        set((state) => {
          const targetVersion = state.project.savedVersions.find((v) => v.id === versionId);
          if (!targetVersion) return state;

          const activeDraft: ProposalVersion = {
            ...structuredClone(targetVersion),
            id: createId("version"),
            versionLabel: getNextVersionLabel([state.project.draftVersion, ...state.project.savedVersions]),
            createdAt: new Date().toISOString(),
            savedAt: null,
            savedBy: null,
            basedOnVersionId: targetVersion.id,
            isDraft: true,
          };

          return setActiveProject(
            state.proposals,
            withTouchedProject(
              {
                ...state.project,
                proposalStatus: "draft",
              },
              activeDraft,
            ),
          );
        }),
      markFinalProposal: () =>
        set((state) =>
          setActiveProject(state.proposals, {
            ...state.project,
            proposalStatus: "final",
            lastEditedAt: new Date().toISOString(),
          }),
        ),
      resetProject: () =>
        set((state) => {
          const project = createInitialProject();
          return setActiveProject(state.proposals, project);
        }),
      importProjectData: (project) =>
        set((state) =>
          setActiveProject(state.proposals, hydrateProject({
            ...project,
            lastEditedAt: new Date().toISOString(),
          })),
        ),
      syncVersionToDrive: async () => {
        const state = get();
        const project = state.project;
        const version = project.draftVersion;

        set((s) => ({
          ...s,
          driveSyncStatus: {
            isSyncing: true,
            lastMessage: "Syncing PDF and XLSX to Drive...",
            lastMessageAt: Date.now(),
          },
        }));

        try {
          const result = await saveVersionToDrive({
            project,
            version,
          });

          set((s) => ({
            ...s,
            driveSyncStatus: {
              isSyncing: false,
              lastMessage: result.success
                ? result.message
                : result.mongoSaved
                  ? `Saved to MongoDB. Drive sync failed: ${result.message}`
                  : `Saved locally. Drive sync failed: ${result.message}`,
              lastMessageAt: Date.now(),
            },
          }));
        } catch (error) {
          set((s) => ({
            ...s,
            driveSyncStatus: {
              isSyncing: false,
              lastMessage: `Saved locally. Drive sync failed: ${error instanceof Error ? error.message : "Unknown error"}`,
              lastMessageAt: Date.now(),
            },
          }));
        }
      },    }));


export const proposalSeedMetadata = {
  standardDisciplines: standardDisciplineOrder,
  createTimelineRows,
  calculateConsultancyTotals,
  calculateScopeTotals,
  calculateFinalEstimate,
};





